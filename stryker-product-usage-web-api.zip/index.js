require('newrelic');
require('dotenv/config');
const fs = require('fs');
const http = require('http');
const https = require('https');
const express = require('express');
const winston = require('winston');
const api = require('./api');
const websockets = require('./api/websockets');
const { ENVIRONMENT, AZURE } = require('./api/config');
const { azureStorageClient } = require('./api/services/AzureStorageClient');
const { listenForFlushRequest } = require('./api/middleware/cache');
const throng = require('throng');
const scheduler = require('node-schedule');

// Server-wide settings
winston.level = process.env.WINSTON_LEVEL || 'debug';
const WORKERS = process.env.WEB_CONCURRENCY || 1;
const dev = process.env.NODE_ENV !== 'production';
const port = process.env.PORT || 3001;

// Scaffold the server
async function startServer() {
  let createServer = http.createServer;
  // Web API + Web Sockets Servers
  const app = await api(express());

  // Setup WebSockets
  let server;
  if (
    process.env.AUTH_ADFS_ENABLED === 'true' &&
    ENVIRONMENT.IS_LOCAL_DEVELOPMENT
  ) {
    createServer = https.createServer;
    server = createServer({
      key: fs.readFileSync('./certs/localhost.key'),
      cert: fs.readFileSync('./certs/localhost.cert'),
      requestCert: false,
      rejectUnauthorized: false
    });
  } else {
    server = createServer();
  }

  // azureClient
  await azureStorageClient.connect();
  azureStorageClient.on('error', err => {
    console.log(err);
    process.exit(1);
  });

  await websockets(server);

  // Mount Express
  server.on('request', app);
  server.listen(port, err => {
    if (err) throw err;
    winston.info(`> Ready on http://localhost:${port}`);
  });
}

throng({
  master: function() {
    listenForFlushRequest();
  },
  workers: WORKERS,
  lifetime: Infinity
}, startServer);