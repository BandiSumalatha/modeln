require('dotenv').config();
const streamifier = require('streamifier');
const amqp = require('amqplib');
const { AMQP, AZURE } = require('./api/config');
const winston = require('winston');
const { Promise } = require('bluebird');
const { gzip } = require('node-gzip');
const axios = require('axios');
const toArray = require('stream-to-array');
const util = require('util');
const moment = require('moment');
const { Duplex } = require('stream');
const sharp = require('sharp');
const fetch = require('node-fetch');
const { retrieveDiffParts } = require('./api/services/retrieveDiffParts');
const { BlobServiceClient } = require('@azure/storage-blob');

const { getConnection } = require('./api/services/jsforce');
const {
  getImageUrl,
  deleteImageBlob
} = require('./api/services/blobImageUpload');
const {
  dequeueImageSync,
  dequeueDeleteRequest,
  dequeueThumbnailCreationSync,
  dequeueBuildCache
} = require('./api/services/cloudAMQP');
const { upsertSFObject } = require('./api/services/salesforce');
const { azureStorageClient } = require('./api/services/AzureStorageClient');
const { herokuConnectClient } = require('./api/services/knex');

const timeout = (prom, time, exception) => {
	let timer;
	return Promise.race([
		prom,
		new Promise((_r, rej) => timer = setTimeout(rej, time, exception))
	]).finally(() => clearTimeout(timer));
};

const getUploadImageCounter = ({
  accountnumber,
  accountname,
  surgeon_erp_code__c,
  contactname,
  index
}) => {
  const currentMoment = moment();
  let title = `${currentMoment.date()}${currentMoment.month() +
    1}${currentMoment.year()}`;
  if (accountnumber) {
    title = `${title}_${accountnumber}`;
  }
  if (accountname) {
    title = `${title}_${accountname}`;
  }
  if (surgeon_erp_code__c) {
    title = `${title}_${surgeon_erp_code__c}`;
  }
  if (contactname) {
    title = `${title}_${contactname}`;
  }
  title = `${title}_Image${index + 1}`;
  return title;
};

const getImageBuffer = async azure_image_url => {
  const imageUrl = await getImageUrl(azure_image_url);
  const imageBinary = await axios({
    method: 'get',
    url: imageUrl,
    responseType: 'stream'
  });

  const parts = await toArray(imageBinary.data);
  const buffers = parts.map(
    part => (util.isBuffer(part) ? part : Buffer.from(part))
  );
  return Buffer.concat(buffers);
};

const getContentType = ext => {
  switch (ext.toLowerCase()) {
    case 'jpg':
    case 'jpeg':
    case '':
      return 'image/jpeg';
    case 'png':
      return 'image/png';
  }
};

const pushAttachmentId = async (
  attachment_id,
  azure_image_url,
  thumbnail_url,
  attachment_name
) => {
  try {
    const result = await upsertSFObject(
      'salesforce.case_images',
      {
        attachment_id,
        azure_image_url,
        thumbnail_url,
        created_at: new Date(),
        updated_at: new Date(),
        attachment_name
      },
      'azure_image_url'
    );
    return result;
  } catch (e) {
    winston.error(`pushAttachmentId error: ${e}`);
    return e;
  }
};

start = async () => {
  await dequeueImageSync(processImageSync);
  await dequeueDeleteRequest(processDeleteRequest);
  await dequeueThumbnailCreationSync(processThumbnailCreationSync);
  await dequeueBuildCache(processBuildCache);

  const setsCompleted = async () => {
    try {
      winston.info('Processing queued sets.');
      const oldestTime = moment().subtract(2, 'hours');

      // handle cases currently in the queue to makr with completed sets

      // get list of cases to process
      const processed = (await herokuConnectClient('queued_sets')
        .withSchema('repsuite')
        .select('id')
        .where('queued', '>', oldestTime)
        .orderBy('queued')
        .limit(5)).map(x => x.id);

      const toDelete = [];

      // update cases to mark sets as complete
      // only mark cases where:
      //
      //  * is_set_complete is not already true
      //  * hasn't been modified for 15 seconds
      //  * doesn't have data changes pending
      //
      // we're looking for the case to be stable
      (await herokuConnectClient('cases__c')
        .withSchema('salesforce')
        .where(function() { 
          this.whereIn('sfid', processed).orWhereIn('external_id__c', processed);
        })
        .where(function () {
          this.where('is_set_complete__c', false).orWhereNull('is_set_complete__c');
        })
        .where(function() {
          this.where('lastmodifieddate', '<', moment().subtract(15, 'seconds')).orWhereNull('lastmodifieddate');
        })
        .whereNotExists(function() {
          this
            .select('id')
            .from('_trigger_log')
            .withSchema('salesforce')
            .whereIn('_trigger_log.state', ['PENDING', 'NEW'])
            .whereRaw('cases__c.id = _trigger_log.record_id');
        })
        .update({
          is_set_complete__c: true
        }, ['sfid', 'external_id__c'])).forEach(x => {
          // record which records met the conditions and
          // were updated
          if (x.sfid) toDelete.push(x.sfid);
          if (x.external_id__c) toDelete.push(x.external_id__c);
        });

      // remove any processed cases from the queue
      await herokuConnectClient('queued_sets')
        .withSchema('repsuite')
        .whereIn('id', toDelete)
        .del();

      winston.info('Processed queued sets.');

      // try to recover if is_sets_complete__c was never set to true
      const toDeleteExpired = [];
      const toRequeue = [];

      // find sets that timed out waiting for is_sets_complete__c to reset
      const expired = (await herokuConnectClient('queued_sets')
        .withSchema('repsuite')
        .select('id')
        .where('queued', '<=', oldestTime)
        .orderBy('queued')
        .limit(1)).map(x => x.id);

      // update cases to mark sets as NOT complete
      // only mark cases where:
      //
      //  * hasn't been modified for 15 seconds
      //  * doesn't have data changes pending
      //
      // we're looking for the case to be stable
      (await herokuConnectClient('cases__c')
        .withSchema('salesforce')
        .where(function() { 
          this.whereIn('sfid', expired).orWhereIn('external_id__c', expired);
        })
        .where(function() {
          this.where('lastmodifieddate', '<', moment().subtract(15, 'seconds')).orWhereNull('lastmodifieddate');
        })
        .whereNotExists(function() {
          this
            .select('id')
            .from('_trigger_log')
            .withSchema('salesforce')
            .whereIn('_trigger_log.state', ['PENDING', 'NEW'])
            .whereRaw('cases__c.id = _trigger_log.record_id');
        })
        .update({
          is_set_complete__c: false
        }, ['sfid', 'external_id__c'])).forEach(x => {
          // record which records met the conditions and
          // were updated
          let requeued = false;
          if (x.sfid) {
            toDeleteExpired.push(x.sfid);
            toRequeue.push(x.sfid);
            requeued = true;
          }
          if (x.external_id__c) {
            toDeleteExpired.push(x.external_id__c);
            if (!requeued) {
              toRequeue.push(x.external_id__c);
            }
            requeued = true;
          }
        });

      // remove any processed cases from the queue
      await herokuConnectClient('queued_sets')
        .withSchema('repsuite')
        .whereIn('id', toDeleteExpired)
        .del();

      // requeue ids that have been reset
      toRequeue.forEach(async id => {
        await herokuConnectClient('queued_sets')
          .withSchema('repsuite')
          .insert({ 
            id,
            queued: new Date()
          });
      });
      winston.info('Processed expired queued sets.');      
    } catch (err) {
      console.log('Problem updating sets!', err);
    }

    setTimeout(async () => {
      await setsCompleted();    
    }, 2500);
    winston.info('Scheduled next queued sets processing task.');
  };

  setTimeout(async () => {
    await setsCompleted();    
  }, 2500);
};

const processThumbnailCreationSync = channel => async msg => {
  try {
    if (msg !== null) {
      winston.info('Processing thumbnail.');
      // azureClient
      await azureStorageClient.connect();
      azureStorageClient.on('error', err => {
        winston.error(`processThumbnailCreationSync error: ${err}`);
        process.exit(1);
      });
      const {
        content,
        properties: { correlationId, replyTo }
      } = msg;
      const newStream = new Duplex();
      const fileName = content.toString();
      const blobNameThumbnail = `thumbnail-${fileName.slice(
        fileName.lastIndexOf('/') + 1
      )}`;
      const response = await timeout(fetch(content.toString()), 30 * 60 * 1000, new Symbol());
      const aB = await response.arrayBuffer();
      const buffer = Buffer.from(aB);
      const newBuffer = await sharp(buffer)
        .resize(320, 240)
        .toBuffer();

      newStream.push(newBuffer);
      newStream.push(null);
      const { imageUrl } = await timeout(azureStorageClient.uploadBlobToAzure(
        newStream,
        blobNameThumbnail
      ), 30 * 60 * 1000, new Symbol());
      channel.sendToQueue(replyTo, Buffer.from(imageUrl), {
        correlationId,
        imageUrl
      });
      channel.ack(msg);
      winston.info(`Processed thumbnail ${blobNameThumbnail}.`);
    }
  } catch (err) {
    winston.error(`processThumbnailCreationSync error: ${err}`);
    channel.reject(msg, false);
  }
};

const processDeleteRequest = channel => async msg => {
  try {
    await azureStorageClient.connect();
    if (msg !== null) {
      winston.info('Processing image delete.');
      const attachmentsRaw = msg.content.toString();
      const { attachments } = JSON.parse(attachmentsRaw);
      const attachArray = [];
      const contentArray = [];
      const imageIdArray = [];
      attachments.forEach(function (a) {
        imageIdArray.push(a.azure_image_url);
        if (a.thumbnail_url) {
          imageIdArray.push(a.thumbnail_url);
        }
      });

      attachments.forEach(function (a) {
        if (a.attachment_id && a.attachment_id.startsWith('00P')) {
          attachArray.push(a.attachment_id);
        } else if (a.attachment_id) {
          contentArray.push(a.attachment_id);
        }
      });
      deleteImageBlob(imageIdArray);
      const conn = await getConnection();
      if (attachArray.length > 0) {
        await conn.sobject('Attachment').del(attachArray);
      }
      if (contentArray.length > 0) {
        const path = `/services/apexrest/ContentDocumentIdSet`;
        await conn.requestPost(path, { ContentIdList: contentArray });
      }
      winston.info(`Processed images for ${case_sfid}/${caseExternalId}.`);
    }
    channel.ack(msg);
    winston.info('Processed image delete.');
  } catch (err) {
    winston.error(`processDeleteRequest error: ${err}`);
    channel.reject(msg, false);
  }
};

const processImageSync = channel => async msg => {
  try {
    const caseIdObject = JSON.parse(msg.content.toString());
    let { imagesToCount, caseExternalId, case_sfid } = caseIdObject;
    winston.info(`Processing images for ${case_sfid}/${caseExternalId}.`);
    const query = herokuConnectClient('case_images')
      .withSchema('salesforce')
      .select(
        'case_images.id',
        'case_images.azure_image_url',
        'case_images.thumbnail_url',
        'case_images.attachment_name',
        'case_images.attachment_id',
        'cases__c.sfid as caseId',
        'account.accountnumber',
        'account.name as accountname',
        'contact.surgeon_erp_code__c',
        'contact.name as contactname',
        'case_images.signature_by'
      );
    if (caseExternalId) {
      query.where('case_images.case_external_id', caseExternalId);
    } else {
      query.where('case_images.case_sfid', case_sfid);
    }

    query
      .whereNotNull('case_images.azure_image_url')
      // .whereNull('case_images.attachment_id')
      .leftJoin('cases__c ', function () {
        this.on(
          'cases__c.external_id__c',
          '=',
          'case_images.case_external_id'
        ).orOn('cases__c.sfid', '=', 'case_images.case_sfid');
      })
      .leftJoin('account', function () {
        this.on('cases__c.hospitalid__c', '=', 'account.sfid');
      })
      .leftJoin('contact', function () {
        this.on('cases__c.hospital_staffid__c', 'contact.sfid');
      });
    let images = await query;
    const attachedImages = images.filter(image => image.attachment_name);

    let indexString = '0';
    if (attachedImages.length > 0) {
      const attachmentName =
        attachedImages[attachedImages.length - 1].attachment_name;
      indexString = attachmentName.substring(
        attachmentName.lastIndexOf('_Image') + 6
      );
    }
    images = images.filter(image => {
      return (
        !image.attachment_id && imagesToCount.includes(image.azure_image_url)
      );
    });
    const index = indexString === '0' ? 0 : (isNaN(parseInt(indexString, 10)) ? 0 : parseInt(indexString, 10));

    images = images.map((img, imgIndex) => ({
      ...img,
      index: index + imgIndex
    }));

    if (images !== null) {
      images.map(async imageRaw => {
        const {
          caseId,
          signature_by,
          azure_image_url,
          thumbnail_url,
          accountnumber,
          accountname,
          surgeon_erp_code__c,
          contactname,
          index
        } = imageRaw;

        const imageBuffer = await getImageBuffer(azure_image_url);
        const conn = await getConnection();
        if (signature_by) {
          const ret = await timeout(conn.sobject('Attachment').create({
            ParentId: caseId,
            Name: signature_by,
            ContentType: getContentType(azure_image_url.split('.').pop()),
            Body: new Buffer(imageBuffer, 'binary').toString('base64')
          }), 30 * 60 * 1000, new Symbol());
          if (ret.success)
            await timeout(pushAttachmentId(ret.id, azure_image_url, thumbnail_url), 30 * 60 * 1000, new Symbol());
        } else {
          const path = `/services/data/v40.0`;
          const attachment_name = getUploadImageCounter({
            accountnumber,
            accountname,
            surgeon_erp_code__c,
            contactname,
            index
          });
          const ret = await timeout(conn.requestPost(`${path}/composite/`, {
            allOrNone: true,
            compositeRequest: [
              {
                method: 'POST',
                url: `${path}/sobjects/ContentVersion`,
                referenceId: 'newFile',
                body: {
                  Title: attachment_name,
                  PathOnClient: azure_image_url,
                  VersionData: new Buffer(imageBuffer, 'binary').toString(
                    'base64'
                  ),
                  FirstPublishLocationId: caseId
                }
              }
            ]
          }), 30 * 60 * 1000, new Symbol());
          if (
            ret &&
            ret.compositeResponse.length > 0 &&
            ret.compositeResponse[0].body.success
          ) {
            const { id } = ret.compositeResponse[0].body;
            await timeout(pushAttachmentId(
              id,
              azure_image_url,
              thumbnail_url,
              attachment_name
            ), 30 * 60 * 1000, new Symbol());
          }
        }
      });

    }
    channel.ack(msg);
  } catch (ex) {
    winston.error(`processImageSync error: ${ex}`);
    channel.reject(msg, false);
  }
};

const processBuildCache = channel => async msg => {
  try {
    winston.info(`Rebuilding cache.`);
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.hospitals_mv');  
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.hospitals2_mv');
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.branches2_mv');  
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.branches3_mv');
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.surgeons_mv');  
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.surgeons2_mv'); 
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.users_mv');
    await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.salesreps_mv');

    await azureStorageClient.connect();
    if (msg !== null) {
      await retrieveDiffParts(true).then(function (result) {
        async function uploadPartsToAzureBlob() {
          // Create the BlobServiceClient object which will be used to create a container client
          const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
          // Get a reference to a container
          const containerClient = blobServiceClient.getContainerClient(AZURE.CACHE_CONTAINER_NAME);
          // Create a unique name for the blob
          const blobName = 'parts.json';
          // Get a block blob client
          const blockBlobClient = containerClient.getBlockBlobClient(blobName);
          // Upload result
          const blobOptions = { blobHTTPHeaders: { blobContentType: 'application/json; encoding=utf-8', blobContentEncoding: 'gzip' } };

          const compressedResults = await gzip(result);
          const stream = streamifier.createReadStream(compressedResults);

          const uploadBlobResponse = await blockBlobClient.uploadStream(stream, 8 * 1024 * 1024, 5, blobOptions);

          console.log("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
        }
        return uploadPartsToAzureBlob().then(() => console.log('Parts done')).catch((ex) => console.log(ex.message));
      });
      for (let i = 0; i <= 10; i++) {
        let from = moment().utc().startOf('day').subtract(i, 'day').toDate();
        await retrieveDiffParts(false, from).then(function (result) {
          async function uploadPartsDiffToAzureBlob() {
            // Create the BlobServiceClient object which will be used to create a container client
            const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
            // Get a reference to a container
            const containerClient = blobServiceClient.getContainerClient(AZURE.CACHE_CONTAINER_NAME);
            // Create a unique name for the blob
            const blobName = `parts.${moment(from).utc().format('YYYY-MM-DD')}.json`;
            // Get a block blob client
            const blockBlobClient = containerClient.getBlockBlobClient(blobName);
            // Upload result
            const blobOptions = { blobHTTPHeaders: { blobContentType: 'application/json; encoding=utf-8', blobContentEncoding: 'gzip' } };

            const compressedResults = await gzip(result);
            const stream = streamifier.createReadStream(compressedResults);

            const uploadBlobResponse = await blockBlobClient.uploadStream(stream, 8 * 1024 * 1024, 5, blobOptions);
            console.log("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
          }
          return uploadPartsDiffToAzureBlob().then(() => console.log(`Parts ${from} done.`)).catch((ex) => console.log(ex.message));
        });
      }

      async function queryDivisions() {
        return herokuConnectClient.raw(`
          select distinct division from (
            select distinct division from repsuite.users_mv
            union
            select distinct unnest(string_to_array(divisions, ';')) as division from repsuite.users_mv
          ) divisions where division is not null`);
      }

      async function populateProcedures() {

        let divisions = await queryDivisions();

        for (const divisionObj of divisions.rows) {

          let division = divisionObj.division;

          let query = herokuConnectClient
            .withSchema('salesforce')
            .select()
            .distinct([
              'procedure__c.sfid as id',
              'procedure__c.name as label',
              'procedure__c.division__c as division'
            ])
            .from('procedure__c')
            .andWhere('isactive__c', true)
            .orderBy('procedure__c.name', 'asc');

          if (division == 'Spine') {
            query = query.where('division__c', division);
          }
          else {
            query = query.where('division__c', 'Ortho');
          }

          let ids = new Set();
          let procedures = await query || [];

          procedures = procedures.filter(obj => {
            if (!ids.has(obj.id)) {
              ids.add(obj.id);
              return true;
            }
            return false;
          });

          let result = JSON.stringify(procedures);

          // Create the BlobServiceClient object which will be used to create a container client
          const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
          // Get a reference to a container
          const containerClient = blobServiceClient.getContainerClient(AZURE.CACHE_CONTAINER_NAME);
          // Create a unique name for the blob
          const blobName = `procedure-${division}.json`;
          // Get a block blob client
          const blockBlobClient = containerClient.getBlockBlobClient(blobName);
          // Upload result
          const blobOptions = { blobHTTPHeaders: { blobContentType: 'application/json; encoding=utf-8', blobContentEncoding: 'gzip' } };

          const compressedResults = await gzip(result);
          const stream = streamifier.createReadStream(compressedResults);

          const uploadBlobResponse = await blockBlobClient.uploadStream(stream, 8 * 1024 * 1024, 5, blobOptions);
          console.log("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
        }
      }

      populateProcedures();

      function convertToJson(query, resolve, reject) {
        const stream = query.stream();
        let data = [];
        let json = '';

        stream.on('data', function (chunk) {
          data.push(chunk);
          if (data.length == 100) {
            let parsed = JSON.stringify(data);
            parsed = parsed.substring(1);
            parsed = parsed.substring(0, parsed.length - 1);
            json += ',' + parsed;
            data = [];
          }
        });

        stream.on('end', function () {
          if (data.length > 0) {
            let parsed = JSON.stringify(data);
            parsed = parsed.substring(1);
            parsed = parsed.substring(0, parsed.length - 1);
            json += ',' + parsed;
          }
          resolve(json.substring(1));
        });

        stream.on('error', function (err) {
          console.log(err.stack);
          reject(err);
        });
      }

      async function queryBranches() {
        return herokuConnectClient
          .withSchema('repsuite')
          .select('branchID')
          .from('branches2_mv');
      }

      async function populateBranchSets() {

        let branches = await queryBranches();

        for (const branch of branches) {

          let branchId = branch.branchID;

          const query = herokuConnectClient
            .withSchema('salesforce')
            .distinct([
              'pc.name AS catalog_category',
              'ps.productsystemname__c AS catalog_item_name',
              'ps.sfid AS catalog_item_sfid',
              'pspc.procedure__c AS procedure_id',
              'ps.id',
              'ps.sfid as set_id',
              'ps.productsystemname__c as set_name',
              'mainBranch.sfid as main_branch_id',
              'inv_location.userid__c as inv_location_user_id',
              'inv_location.branchid__c as sub_branch_id'
            ])
            .select()
            .from('product_system_procedure_category__c AS pspc')
            .innerJoin('product_system__c AS ps', 'ps.sfid', 'pspc.product_system__c')
            .innerJoin(
              'procedure_category__c AS pc',
              'pc.sfid',
              'pspc.procedure_category__c'
            )
            .innerJoin('branch__c as branch', 'branch.sfid', 'pspc.branchid__c')
            .innerJoin(
              'branch__c as mainBranch',
              'mainBranch.sfid',
              'branch.main_branch__c'
            )
            .innerJoin(
              'invlocation__c as inv_location',
              'inv_location.branchid__c',
              'pspc.branchid__c'
            )
            .innerJoin('procedure__c AS p', 'p.sfid', 'pc.procedure__c')
            .where('pspc.isactive__c', true)
            .where('branch.isactive__c', '1')
            .where('mainBranch.isactive__c', '1')
            .where('pc.isactive__c', true)
            .where('p.isactive__c', true)
            .where('branch.sfid', branchId);

          let result = await new Promise((resolve, reject) => { convertToJson(query, resolve, reject); });
          result = '[' + result + ']';

          // Create the BlobServiceClient object which will be used to create a container client
          const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
          // Get a reference to a container
          const containerClient = blobServiceClient.getContainerClient(AZURE.CACHE_CONTAINER_NAME);
          // Create a unique name for the blob
          const blobName = `sets-branch-${branchId}.json`;
          // Get a block blob client
          const blockBlobClient = containerClient.getBlockBlobClient(blobName);
          // Upload result
          const blobOptions = { blobHTTPHeaders: { blobContentType: 'application/json; encoding=utf-8', blobContentEncoding: 'gzip' } };

          const compressedResults = await gzip(result);
          const stream = streamifier.createReadStream(compressedResults);

          const uploadBlobResponse = await blockBlobClient.uploadStream(stream, 8 * 1024 * 1024, 5, blobOptions);
          console.log("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
        }
      }

      populateBranchSets();

      async function populateUserSets() {

        let branches = await queryBranches();

        for (const branch of branches) {

          let branchId = branch.branchID;

          const query = herokuConnectClient
            .withSchema('salesforce')
            .distinct([
              'pc.name AS catalog_category',
              'ps.productsystemname__c AS catalog_item_name',
              'ps.sfid AS catalog_item_sfid',
              'pspc.procedure__c as procedure_id',
              'ps.id',
              'ps.sfid as set_id',
              'ps.productsystemname__c as set_name',
              'pspc.branchid__c as pspc_branchid',
              'pc.branchid__c as pc_branchid'
            ])
            .select()
            .from('product_system_procedure_category__c AS pspc')
            .innerJoin('product_system__c AS ps', 'ps.sfid', 'pspc.product_system__c')
            .innerJoin(
              'procedure_category__c AS pc',
              'pc.sfid',
              'pspc.procedure_category__c'
            )
            .innerJoin('procedure__c AS p', 'p.sfid', 'pc.procedure__c')
            .where('pspc.isactive__c', true)
            .where('pc.isactive__c', true)
            .where('p.isactive__c', true)
            .where(function () {
              this.where('pspc.branchid__c', branchId).orWhere('pc.branchid__c', branchId);
            });

          let result = await new Promise((resolve, reject) => { convertToJson(query, resolve, reject); });
          result = '[' + result + ']';

          console.log('result=' + result);

          // Create the BlobServiceClient object which will be used to create a container client
          const blobServiceClient = BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
          // Get a reference to a container
          const containerClient = blobServiceClient.getContainerClient(AZURE.CACHE_CONTAINER_NAME);
          // Create a unique name for the blob
          const blobName = `sets-users-${branchId}.json`;
          // Get a block blob client
          const blockBlobClient = containerClient.getBlockBlobClient(blobName);
          // Upload result
          const blobOptions = { blobHTTPHeaders: { blobContentType: 'application/json; encoding=utf-8', blobContentEncoding: 'gzip' } };

          const compressedResults = await gzip(result);
          const stream = streamifier.createReadStream(compressedResults);

          const uploadBlobResponse = await blockBlobClient.uploadStream(stream, 8 * 1024 * 1024, 5, blobOptions);
          console.log("Blob was uploaded successfully. requestId: ", uploadBlobResponse.requestId);
        }
      }

      populateUserSets();

      const CACHECONTROL_QUEUE_NAME = 'cachecontrol';
      const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
      const chnl = await conn.createChannel();

      await chnl.assertExchange(CACHECONTROL_QUEUE_NAME, 'fanout');
      await chnl.publish(CACHECONTROL_QUEUE_NAME, '', Buffer.from('flush'));

      await chnl.close();
      await conn.close();
    }
    channel.ack(msg);
    winston.info(`Rebuilt cache.`);
  } catch (ex) {
    winston.error(`processBuildCache error: ${ex}`);
    channel.reject(msg, false);
  }
};

start();