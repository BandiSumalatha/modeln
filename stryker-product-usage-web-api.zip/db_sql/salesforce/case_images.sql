-- -------------------------------------------------------------
-- TablePlus 3.5.0(308)
--
-- https://tableplus.com/
--
-- Database: druvf59a7mfp0
-- Generation Time: 2020-06-04 15:51:01.2710
-- -------------------------------------------------------------


-- This script only contains the table creation statements and does not fully represent the table in the database. It's still missing: indices, triggers. Do not use it as a backup.

-- Sequence and defined type
CREATE SEQUENCE IF NOT EXISTS salesforce.case_images_id_seq;

-- Table Definition
CREATE TABLE "salesforce"."case_images" (
    "id" int4 NOT NULL DEFAULT nextval('salesforce.case_images_id_seq'::regclass),
    "case_external_id" varchar(255),
    "case_sfid" varchar(255),
    "cloudinary_image_id" varchar(255),
    "attachment_name" varchar(255),
    "cloudinary_image_url" varchar(255),
    "signature_by" varchar(255),
    "attachment_id" varchar(255),
    "created_at" timestamptz NOT NULL,
    "updated_at" timestamptz NOT NULL,
    "azure_image_url" varchar(255),
    "thumbnail_url" varchar(255),
    PRIMARY KEY ("id")
);

ALTER TABLE salesforce.case_images
ADD CONSTRAINT azureimageurl_unique UNIQUE (azure_image_url);

