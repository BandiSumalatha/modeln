alter table salesforce.additional_surgery_fee__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.address__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.branch_user_hospital__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.caseaction_tracking__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.cases__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.casesusage__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.filter_presets alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.inventory_product_system__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.casesusage__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.patient_scan__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.preference_detail__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.procedure_category__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.product_lot__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.repsuiteapp_settings__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.surgeon_preference__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.surgery_case_procedure__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.surgical_case_products__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.surgical_case_sales_team__c alter column external_id__c 
set default public.uuid_generate_v4();
alter table salesforce.treatment_plan_request__c alter column external_id__c 
set default public.uuid_generate_v4();