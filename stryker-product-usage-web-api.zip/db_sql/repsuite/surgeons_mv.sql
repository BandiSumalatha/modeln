CREATE OR REPLACE VIEW repsuite.surgeons_v
 AS
 SELECT DISTINCT surgeons.branchid AS "branchID",
    surgeons.userid AS "userID",
    surgeons.surgeonid AS "surgeonID",
    COALESCE(surgeon.surgeon_erp_code__c::text || ' - '::text, ''::text) || surgeon.name::text AS "surgeonName"
   FROM ( SELECT branch.sfid AS branchid,
            'ALL'::character varying(18) AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = salesrep.sfid::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c = true AND salesrep.isactive = true
             JOIN salesforce.branch__c branch ON branch.branch_id__c::text = buh.webops_branch__c::text
        UNION
         SELECT branch.sfid AS branchid,
            salesrep.sfid AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = salesrep.sfid::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c = true AND salesrep.isactive = true
             JOIN salesforce.branch__c branch ON branch.branch_id__c::text = buh.webops_branch__c::text
        UNION
         SELECT mainbranch.sfid AS branchid,
            salesrep.sfid AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branchuserpod__c team ON team.userid__c::text = salesrep.sfid::text
             JOIN salesforce.branchuserpod__c teammate ON teammate.podid__c::text = team.podid__c::text
             JOIN salesforce.pod__c pod ON teammate.podid__c::text = pod.sfid::text
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = teammate.userid__c::text AND buh.branch_id__c::text = pod.branchid__c::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c IS TRUE AND salesrep.isactive = true
             JOIN salesforce.branch__c branch ON branch.branch_id__c::text = buh.webops_branch__c::text
             LEFT JOIN salesforce.branch__c mainbranch ON mainbranch.sfid::text = branch.sfid::text OR mainbranch.sfid::text = branch.main_branch__c::text) surgeons
     JOIN salesforce.contact surgeon ON surgeons.surgeonid::text = surgeon.sfid::text AND NOT surgeon.inactive__c = true;

CREATE MATERIALIZED VIEW repsuite.surgeons_mv
TABLESPACE pg_default
AS
 SELECT 
    surgeons_v."branchID",
    surgeons_v."userID",
    surgeons_v."surgeonID",
    surgeons_v."surgeonName"
   FROM repsuite.surgeons_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_surgeons_userid_branchid_surgeonid
    ON repsuite.surgeons_mv USING btree
    ("branchID" COLLATE pg_catalog."default", "userID" COLLATE pg_catalog."default", "surgeonID" COLLATE pg_catalog."default")
    TABLESPACE pg_default;