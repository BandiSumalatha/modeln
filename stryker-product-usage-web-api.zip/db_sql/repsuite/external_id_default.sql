alter table salesforce.caseaction_tracking__c alter column external_id__c 
set default public.uuid_generate_v4();

alter table salesforce.treatment_plan_request__c alter column external_id__c 
set default public.uuid_generate_v4();