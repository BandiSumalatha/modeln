CREATE OR REPLACE VIEW repsuite.users_v
 AS
 SELECT DISTINCT "user".sfid AS id,
    "user".firstname AS first_name,
    "user".lastname AS last_name,
    "user".federationidentifier AS email,
    "user".email AS sales_rep_email,
    "user".usertype,
    "user".division__c AS division,
    "user".multiselect_division__c AS divisions,
    "user".multiple_persona__c AS personas,
        CASE
            WHEN lower("user".multiple_persona__c::text) ~~ '%in-house%'::text OR lower("user".multiple_persona__c::text) ~~ '%csr%'::text OR lower("user".multiple_persona__c::text) ~~ '%branch op%'::text THEN array_to_string(( SELECT ARRAY( SELECT DISTINCT branches2_mv."branchID"
                       FROM repsuite.branches2_mv) AS "array"), ','::text)
            ELSE string_agg(DISTINCT branchjunction.sfid::text, ','::text)
        END AS "branchIds",
    string_agg(DISTINCT teammates.userid__c::text, ','::text) AS teammate_sfids
   FROM salesforce."user"
     LEFT JOIN salesforce.branchuserpod__c ON "user".sfid::text = branchuserpod__c.userid__c::text
     LEFT JOIN salesforce.pod__c ON branchuserpod__c.podid__c::text = pod__c.sfid::text
     LEFT JOIN salesforce.branchuserpod__c teammates ON pod__c.sfid::text = teammates.podid__c::text
     LEFT JOIN salesforce.branch_user_hospital__c teamlinks ON teammates.userid__c::text = teamlinks.user_id__c::text AND pod__c.branchid__c::text = teamlinks.branch_id__c::text OR teamlinks.user_id__c::text = "user".sfid::text
     LEFT JOIN salesforce.branch__c branchjunction ON branchjunction.branch_id__c::text = teamlinks.webops_branch__c::text
  WHERE "user".isactive = true AND (teamlinks.isactive__c = true OR teamlinks.isactive__c IS NULL) AND (branchjunction.isactive__c::text = '1'::text OR branchjunction.isactive__c IS NULL) AND "user".multiple_persona__c IS NOT NULL AND "user".federationidentifier IS NOT NULL
  GROUP BY "user".sfid, "user".firstname, "user".lastname, "user".federationidentifier, "user".email, "user".usertype, "user".division__c, "user".multiselect_division__c, "user".multiple_persona__c;

CREATE MATERIALIZED VIEW repsuite.users_mv
TABLESPACE pg_default
AS
 SELECT users_v.id,
    users_v.first_name,
    users_v.last_name,
    users_v.email,
    users_v.sales_rep_email,
    users_v.usertype,
    users_v.division,
    users_v.divisions,
    users_v.personas,
    users_v."branchIds",
    users_v.teammate_sfids
   FROM repsuite.users_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_users_mv_unq
    ON repsuite.users_mv USING btree
    (id COLLATE pg_catalog."default")
    TABLESPACE pg_default;