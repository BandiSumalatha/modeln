CREATE TABLE repsuite.rhsmapping (
  salesforce character varying(255) NULL,
  rhs character varying(255) NULL
);

INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee', 'TTK');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Femoral Component', 'TTK.FemoralComponent');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Femoral Component|CR', 'TTK.FemoralComponent.CR');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Femoral Component|PS', 'TTK.FemoralComponent.PS');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Insert Type', 'TTK.InsertType.');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Insert Type|CR', 'TTK.InsertType.CR');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Insert Type|CS (PCL Protect)', 'TTK.InsertType.CSPCLProtect');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Insert Type|PS', 'TTK.InsertType.PS');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Baseplate', 'TTK.Baseplate.');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Baseplate|Universal', 'TTK.Baseplate.Universal');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Triathlon Total Knee|Baseplate|Cruciform', 'TTK.Baseplate.Cruciform');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee', 'MCKPK');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Femoral Component', 'MCKPK.FemoralComponent');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Femoral Component|Medial Uni', 'MCKPK.FemoralComponent.MedialUni');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Femoral Component|Lateral Uni', 'MCKPK.FemoralComponent.LateralUni');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Femoral Component|Bicomp (Medial + PF)', 'MCKPK.FemoralComponent.Bicomp');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Femoral Component|Isolated PF', 'MCKPK.FemoralComponent.IsolatedPF');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Insert Type', 'MCKPK.InsertType');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Insert Type|Onlay', 'MCKPK.InsertType.Onlay');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Insert Type|None', 'MCKPK.InsertType.None');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Baseplate', 'MCKPK.Baseplate');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Baseplate|Onlay', 'MCKPK.Baseplate.Onlay');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('MCK Partial Knee|Baseplate|None', 'MCKPK.Baseplate.None');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip', 'TH');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Approach', 'TH.Approach');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Approach|Postero-Lateral', 'TH.Approach.PosteroLateral');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Approach|Antero-Lateral', 'TH.Approach.AnteroLateral');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Approach|Direct Anterior', 'TH.Approach.DirectAnterior');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Approach|Direct Superior', 'TH.Approach.DirectSuperior');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular', 'TH.AcetabularComponent');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident Hemi', 'TH.AcetabularComponent.TridentHemi');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident PSL', 'TH.AcetabularComponent.TridentPSL');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident Tritanium', 'TH.AcetabularComponent.TridentTitanium');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident II PSL', 'TH.AcetabularComponent.TridentIIPSL');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component', 'TH.FemoralComponent');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component|Accolade II', 'TH.FemoralComponent.AccoladeII');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component|Secur-Fit Advanced', 'TH.FemoralComponent.SecurFitAdvanced');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component|Anato', 'TH.FemoralComponent.Anato');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component|Exeter', 'TH.FemoralComponent.Exeter');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Femoral Component|Exeter US', 'TH.FemoralComponent.ExeterUS');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident II Hemi', 'TH.AcetabularComponent.TridentIIHemi');
INSERT INTO repsuite.rhsmapping (salesforce, rhs) VALUES ('Total Hip|Acetabular|Trident II Tritanium', 'TH.AcetabularComponent.TridentIITritanium');