CREATE OR REPLACE VIEW repsuite.branches_v
 AS
 SELECT DISTINCT branch__c.sfid AS "branchID",
    branch__c.name AS "branchName",
    branch__c.division__c AS "branchDivision",
    branch_user_hospital__c.operating_unit__c AS "operatingUnit"
   FROM salesforce.branch_user_hospital__c
     JOIN salesforce.branch__c ON branch_user_hospital__c.branch_id__c::text = branch__c.sfid::text AND branch_user_hospital__c.isactive__c = true;

CREATE MATERIALIZED VIEW repsuite.branches_mv
TABLESPACE pg_default
AS
 SELECT branches_v."branchID",
    branches_v."branchName",
    branches_v."branchDivision",
    branches_v."operatingUnit"
   FROM repsuite.branches_v
WITH DATA;