CREATE OR REPLACE VIEW repsuite.surgeons2_v
 AS
 SELECT DISTINCT surgeons.userid,
    surgeons.surgeonid,
    COALESCE(surgeon.surgeon_erp_code__c::text || ' - '::text, ''::text) || surgeon.name::text AS "surgeonName"
   FROM ( SELECT salesrep.sfid AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = salesrep.sfid::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c = true AND salesrep.isactive = true
        UNION
          SELECT 'ALL'::varchar(18) AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = salesrep.sfid::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c = true AND salesrep.isactive = true
        UNION
         SELECT salesrep.sfid AS userid,
            buh.contact_id__c AS surgeonid
           FROM salesforce."user" salesrep
             JOIN salesforce.branchuserpod__c team ON team.userid__c::text = salesrep.sfid::text
             JOIN salesforce.branchuserpod__c teammate ON teammate.podid__c::text = team.podid__c::text
             JOIN salesforce.pod__c pod on teammate.podid__c::text = pod.sfid
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = teammate.userid__c::text AND buh.branch_id__c::text = pod.branchid__c::text AND NOT buh.contact_id__c IS NULL AND buh.isactive__c IS TRUE AND salesrep.isactive = true) surgeons
     JOIN salesforce.contact surgeon ON surgeons.surgeonid::text = surgeon.sfid::text AND NOT surgeon.inactive__c = true;

CREATE MATERIALIZED VIEW repsuite.surgeons2_mv
TABLESPACE pg_default
AS
 SELECT surgeons2_v.userid,
    surgeons2_v.surgeonid,
    surgeons2_v."surgeonName"
   FROM repsuite.surgeons2_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_surgeons2_mv_userid_surgeonid
    ON repsuite.surgeons2_mv USING btree
    (userid COLLATE pg_catalog."default", surgeonid COLLATE pg_catalog."default")
    TABLESPACE pg_default;