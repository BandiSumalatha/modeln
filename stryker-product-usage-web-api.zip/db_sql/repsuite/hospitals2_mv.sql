-- View: repsuite.hospitals2_v

-- DROP VIEW repsuite.hospitals2_v;

CREATE OR REPLACE VIEW repsuite.hospitals2_v
 AS
 WITH hospitalsinner AS (
         SELECT salesrep.sfid AS userid,
            buh.hospital_id__c AS hospitalid,
            buh.webops_branch__c AS branchid,
            buh.branch_id__c AS fbranchid
           FROM salesforce."user" salesrep
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = salesrep.sfid::text AND NOT buh.hospital_id__c IS NULL AND buh.isactive__c = true AND salesrep.isactive = true
             JOIN salesforce.recordtype ON recordtype.sfid::text = buh.recordtypeid::text AND recordtype.name::text = 'Ortho'::text
        UNION
         SELECT salesrep.sfid AS userid,
            buh.hospital_id__c AS hospitalid,
            buh.webops_branch__c AS branchid,
            buh.branch_id__c AS fbranchid
           FROM salesforce."user" salesrep
             JOIN salesforce.branchuserpod__c team ON team.userid__c::text = salesrep.sfid::text
             JOIN salesforce.branchuserpod__c teammate ON teammate.podid__c::text = team.podid__c::text
             JOIN salesforce.pod__c teampod ON teammate.podid__c::text = teampod.sfid::text
             JOIN salesforce.branch_user_hospital__c buh ON buh.user_id__c::text = teammate.userid__c::text AND buh.branch_id__c::text = teampod.branchid__c::text AND NOT buh.hospital_id__c IS NULL AND buh.isactive__c IS TRUE AND salesrep.isactive = true
             JOIN salesforce.recordtype ON recordtype.sfid::text = buh.recordtypeid::text AND recordtype.name::text = 'Ortho'::text
        UNION
         SELECT DISTINCT 'ALL'::character varying(18) AS userid,
            buh.hospital_id__c AS hospitalid,
            buh.webops_branch__c AS branchid,
            buh.branch_id__c AS fbranchid
           FROM salesforce.branch_user_hospital__c buh
             JOIN salesforce.recordtype ON recordtype.sfid::text = buh.recordtypeid::text AND recordtype.name::text = 'Ortho'::text
          WHERE NOT buh.hospital_id__c IS NULL AND buh.isactive__c = true
        ), hospitals AS (
         SELECT hospitalsinner.userid,
            hospitalsinner.hospitalid,
            max(hospitalsinner.branchid::text) AS branchid,
            max(hospitalsinner.fbranchid::text) AS fbranchid
           FROM hospitalsinner
          GROUP BY hospitalsinner.userid, hospitalsinner.hospitalid
        )
 SELECT DISTINCT hospitals.userid,
    hospitals.hospitalid,
    COALESCE(hospital.accountnumber::text || ' - '::text, ''::text) || hospital.name::text AS "hospitalName",
    hospital.accountnumber AS "accountNo",
    COALESCE(subbranch.sfid, fbranch.sfid) AS "subBranch",
    COALESCE(subbranch.name, fbranch.name) AS "subBranchName",
    COALESCE(mainbranch.sfid, subbranch.sfid, fbranch.sfid) AS "mainBranch",
    COALESCE(mainbranch.name, subbranch.name, fbranch.name) AS "mainBranchName"
   FROM hospitals
     JOIN salesforce.account hospital ON hospital.sfid::text = hospitals.hospitalid::text AND hospital.active__c = true
     JOIN salesforce.branch__c subbranch ON subbranch.branch_id__c::text = hospitals.branchid
     LEFT JOIN salesforce.branch__c mainbranch ON mainbranch.sfid::text = subbranch.main_branch__c::text
     LEFT JOIN salesforce.branch__c fbranch ON fbranch.sfid::text = hospitals.fbranchid
  WHERE subbranch.division__c IS NOT NULL AND (fbranch.division__c IS NULL OR mainbranch.division__c IS NOT NULL OR fbranch.division__c IS NOT NULL);

CREATE MATERIALIZED VIEW repsuite.hospitals2_mv
TABLESPACE pg_default
AS
 SELECT hospitals2_v.userid,
    hospitals2_v.hospitalid,
    hospitals2_v."hospitalName",
    hospitals2_v."accountNo",
    hospitals2_v."subBranch",
    hospitals2_v."subBranchName",
    hospitals2_v."mainBranch",
    hospitals2_v."mainBranchName"
   FROM repsuite.hospitals2_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_hospitals2_mv_userid_hospitalid
    ON repsuite.hospitals2_mv USING btree
    (userid COLLATE pg_catalog."default", hospitalid COLLATE pg_catalog."default")
    TABLESPACE pg_default;