CREATE OR REPLACE VIEW repsuite.consignmentsets
 AS
 SELECT DISTINCT c.sfid AS case_sfid,
    c.external_id__c AS case_external_id,
    ipsc.name AS set_name,
    ipsc.kit_no__c,
    c.surgery_start_date_time__c AS surgery_date__c,
    c.name AS case_number__c,
    ipsc.status__c,
    productsystem.category__c,
    'Cases'::text AS inventory_type,
        CASE
            WHEN ipsc.kit_no__c IS NULL OR ipsc.kit_no__c::text = ''::text THEN ipsc.name::text
            ELSE concat(ipsc.kit_no__c, ' - ', ipsc.name)
        END AS label,
    prd.sfid AS product_sfid,
    prd.sfid AS part_id,
    prd.inventory_item_id_plain__c AS productoracleid,
    prd.gtin__c AS gtin,
    prd.catalog_number__c AS catalog_number,
    ipc.ipsid__c AS set_id,
    pbe.lot_serial_control_code__c,
    concat(prd.catalog_number__c, ' - ', prd.description__c) AS part_name,
    COALESCE(prd.description, p2.description) AS part_desc
   FROM salesforce.cases__c c
     JOIN salesforce.surgical_case_products__c scpc ON c.sfid::text = scpc.surgical_case__c::text
     JOIN salesforce.inventory_product_system__c ipsc ON scpc.ips_id__c::text = ipsc.sfid::text
     LEFT JOIN salesforce.product_sub_system__c productsubsystem ON ipsc.prosubsysid__c::text = productsubsystem.sfid::text
     LEFT JOIN salesforce.product_system__c productsystem ON productsubsystem.productsystemid__c::text = productsystem.sfid::text
     JOIN salesforce.invproductcomponent__c ipc ON ipc.ipsid__c::text = ipsc.sfid::text
     JOIN salesforce.product2 prd ON prd.sfid::text = ipc.product__c::text AND prd.is_obsolete_in_us__c = false AND prd.isactive = true
     JOIN salesforce.pricebookentry pbe ON pbe.product2id::text = prd.sfid::text AND pbe.lot_serial_control_code__c IS NOT NULL AND pbe.product2id IS NOT NULL
     LEFT JOIN salesforce.productsubsystemcomponents__c psc ON psc.sfid::text = ipc.productsubsyscompid__c::text
     LEFT JOIN salesforce.product2 p2 ON p2.sfid::text = psc.product__c::text;

CREATE OR REPLACE VIEW repsuite.consignmentsets_v
 AS
 WITH cases AS (
         SELECT cases__c.sfid,
            cases__c.surgery_start_date_time__c,
            cases__c.name,
            cases__c.kit_assigner__c
           FROM salesforce.cases__c
          WHERE NOT cases__c.status__c::text = 'Cancelled'::text AND NOT cases__c.status__c::text = 'Closed'::text AND NOT cases__c.status__c::text = 'Completed'::text
        ), pbe AS (
         SELECT pricebookentry.sfid,
            pricebookentry.product2id,
            pricebookentry.lot_serial_control_code__c
           FROM salesforce.pricebookentry
             JOIN salesforce.pricebook2 ON pricebookentry.pricebook2id::text = pricebook2.sfid::text
          WHERE (pricebook2.name::text = ANY (ARRAY['Spine Products'::character varying, 'Ortho Products'::character varying]::text[])) AND pricebookentry.lot_serial_control_code__c IS NOT NULL AND pricebookentry.product2id IS NOT NULL
        ), prd AS (
         SELECT product2.sfid,
            product2.inventory_item_id_plain__c,
            product2.gtin__c,
            product2.catalog_number__c,
            product2.description__c,
            product2.description
           FROM salesforce.product2
          WHERE (product2.product_status__c::text = ANY (ARRAY['Active'::character varying, 'Custom'::character varying, 'DSGN_INPRC'::character varying, 'DSGN_REL'::character varying, 'Hold'::character varying, 'PHASE_OUT'::character varying, 'LAUNCH'::character varying]::text[])) AND product2.is_obsolete_in_us__c = false AND product2.isactive = true
        )
 SELECT DISTINCT c.kit_assigner__c,
    ipsc.sfid AS set_id,
    ipsc.name AS set_name,
    ipsc.kit_no__c,
    c.surgery_start_date_time__c AS "Surgery_date__c",
    c.name AS "Case_Number__c",
    ipsc.status__c AS "Status__c",
    "productSystem".category__c AS "Category__c",
    'Cases'::text AS inventory_type,
        CASE
            WHEN ipsc.kit_no__c IS NULL OR ipsc.kit_no__c::text = ''::text THEN ipsc.name::text
            ELSE concat(ipsc.kit_no__c, ' - ', ipsc.name)
        END AS label,
    prd.sfid AS product_sfid,
    prd.sfid AS part_id,
    prd.inventory_item_id_plain__c AS "productOracleId",
    prd.gtin__c AS gtin,
    prd.catalog_number__c AS catalog_number,
    pbe.lot_serial_control_code__c,
        CASE
            WHEN pbe.lot_serial_control_code__c::text = '2'::text THEN true
            ELSE false
        END AS is_lot_controlled,
    concat(prd.catalog_number__c, ' - ', prd.description__c) AS part_name,
    COALESCE(prd.description, p2.description) AS part_desc
   FROM salesforce.invproductcomponent__c ipc
     JOIN prd ON prd.sfid::text = ipc.product__c::text
     JOIN pbe ON pbe.product2id::text = prd.sfid::text
     JOIN salesforce.inventory_product_system__c ipsc ON ipc.ipsid__c::text = ipsc.sfid::text
     JOIN salesforce.surgical_case_products__c scpc ON scpc.ips_id__c::text = ipsc.sfid::text
     JOIN cases c ON c.sfid::text = scpc.surgical_case__c::text
     LEFT JOIN salesforce.product_sub_system__c "productSubSystem" ON ipsc.prosubsysid__c::text = "productSubSystem".sfid::text
     LEFT JOIN salesforce.product_system__c "productSystem" ON "productSubSystem".productsystemid__c::text = "productSystem".sfid::text
     LEFT JOIN salesforce.productsubsystemcomponents__c psc ON psc.sfid::text = ipc.productsubsyscompid__c::text
     LEFT JOIN salesforce.product2 p2 ON p2.sfid::text = psc.product__c::text
  ORDER BY ipsc.sfid, c.name;