CREATE OR REPLACE VIEW repsuite.salesreps_v
 AS
 WITH buh_users AS (
         SELECT branch__c.sfid AS "branchID",
            "user".sfid AS "userID",
            "user".name AS "userName",
            "user".multiple_persona__c AS "multiplePersona",
            regexp_split_to_array("user".multiselect_division__c::text, '\;+'::text) AS divisions,
            regexp_split_to_array("user".multiple_persona__c::text, '\;+'::text) AS personas
           FROM salesforce.branch_user_hospital__c
             JOIN salesforce."user" ON branch_user_hospital__c.user_id__c::text = "user".sfid::text
             JOIN salesforce.branch__c ON branch_user_hospital__c.webops_branch__c::text = branch__c.branch_id__c::text AND (branch_user_hospital__c.branch_id__c::text = branch__c.main_branch__c::text OR branch_user_hospital__c.branch_id__c::text = branch__c.sfid::text)
          WHERE branch_user_hospital__c.isactive__c = true AND "user".isactive = true
        ), pod_users AS (
         SELECT DISTINCT teambranch.sfid AS "branchID",
            "user".sfid AS "userID",
            "user".name AS "userName",
            regexp_split_to_array("user".multiselect_division__c::text, '\;+'::text) AS divisions
           FROM salesforce."user"
             JOIN salesforce.branchuserpod__c pods ON pods.userid__c::text = "user".sfid::text
             JOIN salesforce.pod__c pod ON pod.sfid::text = pods.podid__c::text
             JOIN salesforce.branchuserpod__c teammates ON pods.podid__c::text = teammates.podid__c::text
             JOIN salesforce.branch_user_hospital__c teammatebranches ON teammates.userid__c::text = teammatebranches.user_id__c::text
             JOIN salesforce.branch__c teambranch ON teambranch.branch_id__c::text = teammatebranches.webops_branch__c::text
          WHERE pod.branchid__c IS NOT NULL AND teammatebranches.isactive__c = true AND teammatebranches.isactive__c = true AND "user".isactive = true
        ), filtered_pod_users AS (
         SELECT pod_users."branchID",
            pod_users."userID",
            pod_users."userName",
            pod_users.divisions
           FROM pod_users
        EXCEPT
         SELECT buh_users."branchID",
            buh_users."userID",
            buh_users."userName",
            buh_users.divisions
           FROM buh_users
        ), all_users AS (
         SELECT 'ALL'::character varying(18) AS "branchID",
            "user".sfid AS "userID",
            "user".name AS "userName",
            regexp_split_to_array("user".multiselect_division__c::text, '\;+'::text) AS divisions
           FROM salesforce."user"
          WHERE "user".multiple_persona__c::text ~~* '%csr%'::text OR "user".multiple_persona__c::text ~~* '%branch op%'::text OR "user".multiple_persona__c::text ~~* '%in-house%'::text AND "user".isactive = true
        ), combined AS (
         SELECT buh_users."branchID",
            buh_users."userID",
            buh_users."userName",
            buh_users."multiplePersona",
            buh_users.divisions,
            buh_users.personas
           FROM buh_users
        UNION
         SELECT filtered_pod_users."branchID",
            filtered_pod_users."userID",
            filtered_pod_users."userName",
            'Sales Associate'::character varying(4099) AS "multiplePersona",
            filtered_pod_users.divisions,
            ARRAY['Sales Associate'::text] AS personas
           FROM filtered_pod_users
        UNION
         SELECT all_users."branchID",
            all_users."userID",
            all_users."userName",
            'Sales Associate'::character varying(4099) AS "multiplePersona",
            all_users.divisions,
            ARRAY['Sales Associate'::text] AS personas
           FROM all_users
        )
 SELECT DISTINCT combined."branchID",
    combined."userID",
    combined."userName",
    combined."multiplePersona",
    combined.divisions,
    combined.personas
   FROM combined;

CREATE MATERIALIZED VIEW repsuite.salesreps_mv
TABLESPACE pg_default
AS
 SELECT salesreps_v."branchID",
    salesreps_v."userID",
    salesreps_v."userName",
    salesreps_v."multiplePersona",
    salesreps_v.divisions,
    salesreps_v.personas
   FROM repsuite.salesreps_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_salesreps_branchid_userid
    ON repsuite.salesreps_mv USING btree
    ("branchID" COLLATE pg_catalog."default", "userID" COLLATE pg_catalog."default")
    TABLESPACE pg_default;