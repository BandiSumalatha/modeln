create table repsuite.as1_catalog_mapping (
	catalognumber		varchar(255) NOT NULL,
	catalogdescription	varchar(255) NOT NULL,
	femoralcomponent	varchar(255) NOT NULL,
	inserttype		varchar(255) NOT NULL,
	baseplate		varchar(255) NOT NULL,
	active			boolean
);

create unique index as1_catalog_mapping_unq ON repsuite.as1_catalog_mapping(femoralcomponent, inserttype, baseplate);