CREATE OR REPLACE VIEW repsuite.branches2_v
 AS
 WITH mainbranches AS (
         SELECT DISTINCT branch__c.sfid AS "branchID",
            branch__c.name AS "branchName",
            branch__c.division__c AS "branchDivision",
            branch_user_hospital__c.operating_unit__c AS "operatingUnit",
            NULL::text AS "mainBranch"
           FROM salesforce.branch_user_hospital__c
             JOIN salesforce."user" ON branch_user_hospital__c.createdbyid::text = "user".sfid::text
             JOIN salesforce.branch__c ON branch_user_hospital__c.branch_id__c::text = branch__c.sfid::text AND branch_user_hospital__c.isactive__c = true AND (branch__c.isactive__c IS NULL OR branch__c.isactive__c::text = '1'::text) AND (lower(branch__c.division__c::text) ~~ '%trauma%'::text OR lower(branch__c.division__c::text) ~~ '%joint%'::text)
          WHERE lower("user".username::text) ~~ 'sfdc.icintegration@stryker.com%'::text OR lower(branch__c.name::text) ~~ '%mako r&d%'::text
        ), subbranches AS (
         SELECT DISTINCT branch__c.sfid AS "branchID",
            branch__c.name AS "branchName",
            concat(branch__c.division__c, ';', mainbranches."branchDivision") AS "branchDivision",
            mainbranches."operatingUnit",
            branch__c.main_branch__c AS "mainBranch"
           FROM salesforce.branch__c
             JOIN mainbranches ON branch__c.main_branch__c::text = mainbranches."branchID"::text
          WHERE NOT (branch__c.sfid::text IN ( SELECT mainbranches_1."branchID"
                   FROM mainbranches mainbranches_1))
        )
 SELECT mainbranches."branchID",
    mainbranches."branchName",
    mainbranches."branchDivision",
    mainbranches."operatingUnit",
    mainbranches."mainBranch"
   FROM mainbranches
UNION
 SELECT subbranches."branchID",
    subbranches."branchName",
    subbranches."branchDivision",
    subbranches."operatingUnit",
    subbranches."mainBranch"
   FROM subbranches;

CREATE MATERIALIZED VIEW repsuite.branches2_mv
TABLESPACE pg_default
AS
 SELECT branches2_v."branchID",
    branches2_v."branchName",
    branches2_v."branchDivision",
    branches2_v."operatingUnit",
    branches2_v."mainBranch"
   FROM repsuite.branches2_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_branches2_branchid
    ON repsuite.branches2_mv USING btree
    ("branchID" COLLATE pg_catalog."default")
    TABLESPACE pg_default;