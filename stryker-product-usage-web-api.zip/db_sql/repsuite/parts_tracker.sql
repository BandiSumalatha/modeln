-- -------------------------------------------------------------
-- TablePlus 3.5.0(308)
--
-- https://tableplus.com/
--
-- Database: druvf59a7mfp0
-- Generation Time: 2020-06-04 15:45:55.2030
-- -------------------------------------------------------------

-- Table Definition
CREATE TABLE "repsuite"."parts_tracker" (
    "part_name" text,
    "is_deleted" bool DEFAULT false,
    "last_modified" timestamp DEFAULT CURRENT_TIMESTAMP,
    "product_sfid" varchar(18)
);

