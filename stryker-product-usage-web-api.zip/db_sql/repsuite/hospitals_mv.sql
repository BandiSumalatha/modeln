CREATE OR REPLACE VIEW repsuite.hospitals_v
 AS
 SELECT DISTINCT branch_user_hospital__c.branch_id__c AS "branchID",
    account.sfid AS "hospitalId",
    COALESCE(account.accountnumber::text || ' - '::text, ''::text) || account.name::text AS "hospitalName",
    account.accountnumber AS "accountNo"
   FROM salesforce.branch_user_hospital__c
     JOIN salesforce.account ON branch_user_hospital__c.hospital_id__c::text = account.sfid::text
     JOIN salesforce."user" ON branch_user_hospital__c.user_id__c::text = "user".sfid::text
     JOIN salesforce.branch__c ON branch__c.sfid::text = branch_user_hospital__c.branch_id__c::text
  WHERE branch_user_hospital__c.isactive__c = true AND "user".isactive = true AND account.active__c = true AND branch__c.division__c IS NOT NULL;

CREATE MATERIALIZED VIEW repsuite.hospitals_mv
TABLESPACE pg_default
AS
 SELECT hospitals_v."branchID",
    hospitals_v."hospitalId",
    hospitals_v."hospitalName",
    hospitals_v."accountNo"
   FROM repsuite.hospitals_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_hospitals_branchid_hospitalid
    ON repsuite.hospitals_mv USING btree
    ("branchID" COLLATE pg_catalog."default", "hospitalId" COLLATE pg_catalog."default")
    TABLESPACE pg_default;