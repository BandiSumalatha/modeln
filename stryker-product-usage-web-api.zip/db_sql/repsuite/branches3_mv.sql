CREATE OR REPLACE VIEW repsuite.branches3_v
 AS
 SELECT branches.userid,
    branches.branch,
    branch.name,
    branches.mainbranch,
    branches.invlocation,
    branch.division__c AS branchdivision
   FROM ( SELECT branchesinner.userid,
            branchesinner.branch,
            max(branchesinner.mainbranch::text) AS mainbranch,
                CASE
                    WHEN max(branchesinner.invlocation) = 0 THEN false
                    ELSE true
                END AS invlocation
           FROM ( SELECT hospitals2_mv.userid,
                    hospitals2_mv."subBranch" AS branch,
                        CASE
                            WHEN hospitals2_mv."mainBranch"::text = hospitals2_mv."subBranch"::text THEN NULL::character varying
                            ELSE hospitals2_mv."mainBranch"
                        END AS mainbranch,
                    1 AS invlocation
                   FROM repsuite.hospitals2_mv
                  WHERE hospitals2_mv."subBranch" IS NOT NULL
                UNION
                 SELECT hospitals2_mv.userid,
                    hospitals2_mv."mainBranch" AS branch,
                    NULL::character varying AS "mainBranch",
                    0 AS invlocation
                   FROM repsuite.hospitals2_mv
                  WHERE hospitals2_mv."subBranch" IS NOT NULL
                UNION
                 SELECT userbranches.userid,
                    userbranches.branch,
                    branch__c.main_branch__c AS mainbranch,
                    1 AS invlocation
                   FROM ( SELECT users_mv.id AS userid,
                            unnest(string_to_array(users_mv."branchIds", ','::text)) AS branch
                           FROM repsuite.users_mv) userbranches
                     JOIN salesforce.branch__c ON userbranches.branch = branch__c.sfid::text) branchesinner
          GROUP BY branchesinner.userid, branchesinner.branch) branches
     JOIN salesforce.branch__c branch ON branch.sfid::text = branches.branch::text
    WHERE branch.division__c IS NOT NULL;

CREATE MATERIALIZED VIEW repsuite.branches3_mv
TABLESPACE pg_default
AS
 SELECT branches3_v.userid,
    branches3_v.branch,
    branches3_v.name,
    branches3_v.mainbranch,
    branches3_v.invlocation,
    branches3_v.branchdivision
   FROM repsuite.branches3_v
WITH DATA;

CREATE UNIQUE INDEX repsuite_branches3_mv_userid_branch
    ON repsuite.branches3_mv USING btree
    (userid COLLATE pg_catalog."default", branch COLLATE pg_catalog."default")
    TABLESPACE pg_default;