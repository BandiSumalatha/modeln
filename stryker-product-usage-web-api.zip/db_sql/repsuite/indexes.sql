CREATE UNIQUE INDEX repsuite_branches2_branchid
  ON repsuite.branches2_mv ("branchID");

CREATE UNIQUE INDEX repsuite_hospitals_branchid_hospitalId
  ON repsuite.hospitals_mv ("branchID", "hospitalId");

CREATE UNIQUE INDEX repsuite_parts_product_sfid
  ON repsuite.parts_mv ("product_sfid");

CREATE UNIQUE INDEX repsuite_salesrep_branchid_userid
  ON repsuite.salesreps_mv ("branchID", "userID");

CREATE UNIQUE INDEX repsuite_surgeons_branchid_surgeonid
  ON repsuite.surgeons_mv ("branchID", "surgeonID");

CREATE UNIQUE INDEX repsuite_users_id
  ON repsuite.users_mv ("id");