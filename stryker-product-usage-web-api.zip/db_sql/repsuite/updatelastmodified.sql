-- -------------------------------------------------------------
-- TablePlus 3.5.0(308)
--
-- https://tableplus.com/
--
-- Database: druvf59a7mfp0
-- Generation Time: 2020-06-04 15:45:05.4120
-- -------------------------------------------------------------


CREATE OR REPLACE FUNCTION repsuite.updatelastmodified()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
IF ((OLD.lot_serial_control_code__c != NEW.lot_serial_control_code__c) or (OLD."productOracleId" != NEW."productOracleId") or (OLD.partsearch__c != NEW.partsearch__c) or (OLD."pricebookName" != NEW."pricebookName") or (OLD.gtin != NEW.gtin)) 
THEN
UPDATE repsuite.parts_tracker SET last_modified = CURRENT_TIMESTAMP where part_name = old.part_name;
END IF;
RETURN NEW;
END;
$function$;

