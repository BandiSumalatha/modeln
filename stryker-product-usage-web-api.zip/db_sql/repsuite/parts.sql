CREATE OR REPLACE VIEW repsuite.parts_v
 AS
 SELECT DISTINCT ON ((concat(pricebook.name, product.catalog_number__c, product.description__c))) concat(product.catalog_number__c, ' - ', product.description__c) AS part_name,
    product.sfid AS product_sfid,
    product.description__c AS part_desc,
    pbe.lot_serial_control_code__c,
    product.inventory_item_id_plain__c AS "productOracleId",
    product.partsearch__c,
    replace(concat(product.productcode, ' ', product.description__c), '-'::text, ''::text) AS part_search_withouthyphen__c,
    pricebook.name AS "pricebookName",
    product.gtin__c AS gtin,
    product.catalog_number__c AS catalog_number
   FROM salesforce.pricebookentry pbe
     JOIN salesforce.product2 product ON pbe.product2id::text = product.sfid::text AND product.is_obsolete_in_us__c = false AND product.isactive = true
     JOIN salesforce.pricebook2 pricebook ON pbe.pricebook2id::text = pricebook.sfid::text
  WHERE (pricebook.name::text = ANY (ARRAY['Spine Products'::character varying::text, 'Ortho Products'::character varying::text])) AND pbe.lot_serial_control_code__c IS NOT NULL AND pbe.product2id IS NOT NULL AND (product.product_status__c::text = ANY (ARRAY['Active'::character varying::text, 'CUSTOM'::character varying::text, 'DSGN_INPRC'::character varying::text, 'DSGN_REL'::character varying::text, 'Hold'::character varying::text, 'PHASE_OUT'::character varying::text, 'LAUNCH'::character varying::text]));

CREATE MATERIALIZED VIEW repsuite.parts_mv
TABLESPACE pg_default
AS
 SELECT parts_v.part_name,
    parts_v.product_sfid,
    parts_v.part_desc,
    parts_v.lot_serial_control_code__c,
    parts_v."productOracleId",
    parts_v.partsearch__c,
    parts_v.part_search_withouthyphen__c,
    parts_v."pricebookName",
    parts_v.gtin,
    parts_v.catalog_number
   FROM repsuite.parts_v
WITH DATA;