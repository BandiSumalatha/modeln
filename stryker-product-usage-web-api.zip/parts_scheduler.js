require('dotenv/config');
const { herokuConnectClient } = require('./api/services/knex');
const { REDIS } = require('./api/config');
const { set, get } = require('./api/services/redis');
const { BlobServiceClient } = require('@azure/storage-blob');
const { enqueueBuildCache } = require('./api/services/cloudAMQP'); 

async function refreshBranches() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.branches2_mv');  
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.branches3_mv');
}

async function refreshSurgeons() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.surgeons_mv');  
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.surgeons2_mv');  
}

async function refreshHospitals() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.hospitals_mv');  
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.hospitals2_mv');
}

// refreshing materialize view
async function refreshUsers() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.users_mv');
}

// refreshing materialize view
async function refreshSalesReps() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.salesreps_mv');
}

// refreshing materialize view
async function refreshPartsMv() {
  await herokuConnectClient.raw('REFRESH MATERIALIZED VIEW CONCURRENTLY repsuite.parts_mv');
}

// deleting records from parts_tracker that has been deleted
async function deleteFromPartsTracker() {
  herokuConnectClient('parts_tracker')
    .withSchema('repsuite')
    .update({ isDeleted: true, last_modified: 'CURRENT_TIMESTAMP' })
    .whereRaw(`NOT is_deleted AND NOT EXISTS
                (SELECT 1 FROM repsuite.parts_mv left join repsuite.parts
                on repsuite.parts.product_sfid = repsuite.parts_mv.product_sfid
                and repsuite.parts."pricebookName" = repsuite.parts_mv."pricebookName"
                )`);
}

// updating parts records, that has been changed, comparing it with materialize view
async function updateParts() {
  await herokuConnectClient.raw(`UPDATE
      repsuite.parts
    SET
       (product_sfid,
               part_desc,
               lot_serial_control_code__c,
               "productOracleId",
               partsearch__c,
               part_search_withouthyphen__c,
               "pricebookName",
               gtin,
               catalog_number) = (b.product_sfid,
               b.part_desc,
               b.lot_serial_control_code__c,
               b."productOracleId",
               b.partsearch__c,
               b.part_search_withouthyphen__c,
               b."pricebookName",
               b.gtin,
               b.catalog_number)
    FROM
    repsuite.parts_mv b
    where
    parts.product_sfid = b.product_sfid
    and parts."pricebookName" = b."pricebookName"`);
}

// inserting new parts records if any into parts_tracker table
async function insertPartsIntoPartsTracker() {
  await herokuConnectClient.raw(`INSERT INTO repsuite.parts_tracker (part_name, is_deleted, last_modified, product_sfid, "pricebookName")
    SELECT
      part_name,
      FALSE,
      CURRENT_TIMESTAMP,
      parts_mv.product_sfid,
      "pricebookName"
    FROM
      repsuite.parts_mv
    WHERE
      NOT EXISTS (
        SELECT
          1
        FROM
          repsuite.parts
        WHERE
          repsuite.parts_mv.product_sfid = repsuite.parts.product_sfid
          and repsuite.parts_mv."pricebookName" = repsuite.parts."pricebookName");
    `);
}

// inserting new parts records if any into parts table
async function insertPartsIntoParts() {
  await herokuConnectClient.raw(`INSERT INTO repsuite.parts (part_name, product_sfid, part_desc, lot_serial_control_code__c, "productOracleId", partsearch__c, part_search_withouthyphen__c, "pricebookName", gtin, catalog_number)
      SELECT
        part_name,
        product_sfid,
        part_desc,
        lot_serial_control_code__c,
        "productOracleId",
        partsearch__c,
        part_search_withouthyphen__c,
        "pricebookName",
        gtin,
        catalog_number
      FROM
        repsuite.parts_mv
      WHERE
        NOT EXISTS (
          SELECT
            1
          FROM
            repsuite.parts
          WHERE
            repsuite.parts_mv.product_sfid = repsuite.parts.product_sfid
            and repsuite.parts_mv."pricebookName" = repsuite.parts."pricebookName");
      `);
}

// schedular function, sync parts difference and update records in DB
async function refreshParts() {
  try {
    const lastRunScheduler = await get(
      REDIS.PARTS_SCHEDULER_CACHE,
      REDIS.LAST_SCHEDULER_RUN
    );
    const schedulerStartTime = Date.now();
    const timeDifference =
      lastRunScheduler === null ? 0 : schedulerStartTime - lastRunScheduler;

    if (timeDifference > 57600000 || timeDifference === 0) {
      // refreshing materialize view
      await refreshPartsMv();

      // deleting records from parts_tracker that has been deleted
      await deleteFromPartsTracker();

      // updating parts records, that has been changed, comparing it with materialize view
      await updateParts();

      // inserting new parts records if any into parts_tracker table
      await insertPartsIntoPartsTracker();

      // inserting new parts records if any into parts table
      await insertPartsIntoParts();

      // removing deleted parts
      await removeDeletedParts();
      await set(
        REDIS.PARTS_SCHEDULER_CACHE,
        REDIS.LAST_SCHEDULER_RUN,
        schedulerStartTime
      );
    }
    console.log('Completed');
    return;
  } catch (err) {
    console.log(err);
    return;
  }
}

// deleting parts from parts
async function removeDeletedPartsFromParts() {
  await herokuConnectClient.raw(`DELETE FROM repsuite.parts where 
  repsuite.parts.product_sfid || '.' || repsuite.parts."pricebookName"
  IN 
  (select 
    repsuite.parts_tracker.product_sfid || '.' || repsuite.parts_tracker."pricebookName"
    from repsuite.parts_tracker 
    where is_deleted = TRUE AND last_modified < CURRENT_TIMESTAMP - interval '6 months'
    )`);
}

// deleting parts from parts_tracker
async function removeDeletedPartsFromPartsTracker() {
  await herokuConnectClient.raw(`delete from repsuite.parts_tracker
    where is_deleted = TRUE AND last_modified < CURRENT_TIMESTAMP - interval '6 months'
    `);
}

// deleting parts
async function removeDeletedParts() {
  await removeDeletedPartsFromParts();
  await removeDeletedPartsFromPartsTracker();
}

async function doWork() {
  await refreshHospitals();
  await refreshBranches();
  await refreshUsers();
  await refreshSalesReps();  
  await refreshSurgeons();
  await refreshParts();
  await enqueueBuildCache();
}

doWork();