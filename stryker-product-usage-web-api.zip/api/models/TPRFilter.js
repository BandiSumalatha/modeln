const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');

const schema = new mongoose.Schema({
  user_sfid: { type: String },
  name: { type: String },
  definition: { type: mongoose.Schema.Types.Mixed }
});

const TPRFilter = mongoose.model('TPRFilter', schema, `${MONGODB.PREFIX}tprfilters`);

async function migrate() {
  if (MONGODB.RECREATE_SCHEMA) {
    await TPRFilter.remove({});
    return;
  }
}

module.exports = {
  migrate,
  TPRFilter
};
