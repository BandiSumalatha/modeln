const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');
module.exports = mongoose.model('Submission', {}, `${MONGODB.PREFIX}submissions`);
