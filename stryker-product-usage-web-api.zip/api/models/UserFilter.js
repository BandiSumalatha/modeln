const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');

const schema = new mongoose.Schema({
  user_sfid: { type: String },
  name: { type: String },
  definition: { type: mongoose.Schema.Types.Mixed }
});

const UserFilter = mongoose.model('UserFilter', schema, `${MONGODB.PREFIX}userfilters`);

async function migrate() {
  if (MONGODB.RECREATE_SCHEMA) {
    await UserFilter.remove({});
    return;
  }
}

module.exports = {
  migrate,
  UserFilter
};
