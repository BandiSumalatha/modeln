const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');

const { Schema } = mongoose;

module.exports = mongoose.model(
  'SurveyResponse',
  new mongoose.Schema({
    survey_id: { type: String },
    submission_date: { type: Date },
    status: { type: String },
    responses: {
      type: mongoose.Schema.Types.Mixed
    }
  }),
  `${MONGODB.PREFIX}surveyResponses`
);
