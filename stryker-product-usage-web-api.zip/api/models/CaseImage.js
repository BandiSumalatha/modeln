const { STRING, TEXT, DECIMAL, INTEGER, BOOLEAN } = require('sequelize');
const { DEFAULT_MODEL_SETTINGS } = require('./config');
const sequelize = require('../services/sequelize');
const winston = require('winston');

const CaseImage = sequelize.define(
  'case_images',
  {
    id: {
      type: INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    case_external_id: {
      type: STRING,
      allowNull: true
    },
    case_sfid: {
      type: STRING,
      allowNull: true
    },
    cloudinary_image_id: {
      type: STRING,
      allowNull: false
    },
    attachment_name: {
      type: STRING,
      allowNull: true
    },
    cloudinary_image_url: {
      type: STRING,
      allowNull: false,
      unique: true
    },
    signature_by: {
      type: STRING,
      allowNull: true
    },
    attachment_id: {
      type: STRING,
      allowNull: true
    }
  },
  { ...DEFAULT_MODEL_SETTINGS, ...{ schema: 'salesforce' } }
);

async function migrate() {
  try {
    await CaseImage.sync({ force: process.env.RECREATE_SCHEMA === 'true' });
  } catch (error) {
    winston.error(error);
  }
}

module.exports = {
  CaseImage,
  migrate
};
