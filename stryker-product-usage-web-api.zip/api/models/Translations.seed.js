module.exports = {
  en: {
    dashboard: {
      todo: 'TODO: Translate for Nvj',
      home: 'Home',
      anonymous: 'Annonymous',
      survey: 'Survey',
      metrics: 'Metrics',
      surveyEditor: 'Survey Editor'
    },
    ortho: {
      dashboard: {
        todo: 'TODO: Translate for Ortho',
        home: 'Home',
        ortho: 'Ortho',
        metrics: 'Metrics',
        survey: 'POC Survey',
        surveyEditor: 'POC Survey Editor'
      }
    },
    nvj: {
      dashboard: {
        todo: 'TODO: Translate for Nvj',
        home: 'Home',
        metrics: 'Metrics',
        surveys: 'Surveys',
        departments: [
          { value: 'Radiology', label: 'Radiology' },
          {
            value: 'Gastroenterology/Gastrointestinal Surgery',
            label: 'Gastroenterology/Gastrointestinal Surgery'
          },
          {
            value: 'Respiratory Medicine/Thoracic Surgery',
            label: 'Respiratory Medicine/Thoracic Surgery'
          },
          {
            value: 'Cardiovascular/vascular Surgery ',
            label: 'Cardiovascular/vascular Surgery '
          },
          {
            value: 'Neurosurgery/Neuro Endovascular Surgery',
            label: 'Neurosurgery/Neuro Endovascular Surgery'
          },
          { value: 'Cardiology', label: 'Cardiology' },
          { value: 'Pediatric Cardiology', label: 'Pediatric Cardiology' },
          { value: 'Emergency Medical', label: 'Emergency Medical' },
          { value: 'Other', label: 'Other' }
        ]
      }
    },
    common: {
      actions: {
        toggleToJapanese: 'Japanese',
        toggleToEnglish: 'English'
      }
    }
  },
  'en-US': {
    dashboard: {
      home: 'Home',
      anonymous: 'Annonymous',
      survey: 'Survey',
      surveyEditor: 'Survey Editor'
    },
    ortho: {
      dashboard: {
        todo: 'TODO: Translate for Ortho',
        home: 'Home',
        ortho: 'Ortho',
        metrics: 'Metrics',
        survey: 'POC Survey',
        surveyEditor: 'POC Survey Editor'
      }
    },
    nvj: {
      dashboard: {
        todo: 'TODO: Translate for Nvj',
        home: 'Home',
        metrics: 'Metrics',
        surveys: 'Surveys',
        departments: [
          { value: 'Radiology', label: 'Radiology' },
          {
            value: 'Gastroenterology/Gastrointestinal Surgery',
            label: 'Gastroenterology/Gastrointestinal Surgery'
          },
          {
            value: 'Respiratory Medicine/Thoracic Surgery',
            label: 'Respiratory Medicine/Thoracic Surgery'
          },
          {
            value: 'Cardiovascular/Vascular Surgery ',
            label: 'Cardiovascular/Vascular Surgery '
          },
          {
            value: 'Neurosurgery/Neuro Endovascular Surgery',
            label: 'Neurosurgery/Neuro Endovascular Surgery'
          },
          { value: 'Cardiology', label: 'Cardiology' },
          { value: 'Pediatric Cardiology', label: 'Pediatric Cardiology' },
          { value: 'Emergency Medical', label: 'Emergency Medical' },
          { value: 'Other', label: 'Other' }
        ]
      }
    },
    common: {
      actions: {
        toggleToJapanese: 'Japanese',
        toggleToEnglish: 'English'
      }
    }
  },
  ja: {
    dashboard: {
      home: 'ホーム',
      anonymous: 'ホーム',
      survey: 'アンケート',
      surveyEditor: 'POC調査エディタ'
    },
    ortho: {
      dashboard: {
        todo: 'ホーム画面を実装する',
        home: 'ホーム',
        ortho: 'ホーム',
        survey: 'アンケート',
        surveyEditor: 'POC調査エディタ'
      }
    },
    nvj: {
      dashboard: {
        todo: 'ホーム画面を実装する',
        home: 'ホーム',
        nvj: 'ホーム',
        surveyInitiate: 'アンケートを開始する',
        surveys: 'アンケート',
        survey: 'アンケート',
        surveyEditor: 'POC調査エディタ',
        departments: [
          { value: 'Radiology', label: '放射線科' },
          {
            value: 'Gastroenterology/Gastrointestinal Surgery',
            label: '消化器内・外科'
          },
          {
            value: 'Respiratory Medicine/Thoracic Surgery',
            label: '呼吸器内・外科'
          },
          {
            value: 'Cardiovascular/Vascular Surgery ',
            label: '心臓・血管外科'
          },
          { value: 'Neurosurgery/Neuro Endovascular Surgery', label: '脳外科' },
          { value: 'Cardiology', label: '循内科' },
          { value: 'Pediatric Cardiology', label: '小児循環器科' },
          { value: 'Emergency Medical', label: ' 救命救急科' },
          { value: 'Other', label: 'その他' }
        ]
      }
    },
    common: {
      actions: {
        toggleToJapanese: '日本語',
        toggleToEnglish: 'English'
      }
    }
  }
};
