const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');

const Survey = new mongoose.Schema({
  name: { type: String },
  status: { type: String },
  survey_date: { type: Date },
  recurrence: { type: String },
  survey_id: { type: Number },
  definition: { type: mongoose.Schema.Types.Mixed }
});

module.exports = mongoose.model('Survey', Survey, `${MONGODB.PREFIX}surveys`);
