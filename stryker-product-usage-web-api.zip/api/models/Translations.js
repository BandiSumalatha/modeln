const { MONGODB } = require('../config');
const mongoose = require('../services/mongoose');

const translationsSchema = new mongoose.Schema({ locales: {} });
const Translations = mongoose.model('Translations', translationsSchema, `${MONGODB.PREFIX}translations`);

async function migrate() {
  if (MONGODB.RECREATE_SCHEMA) {
    const locales = require('./Translations.seed');
    await Translations.remove({});
    let translationsSeed = new Translations({ locales });
    await translationsSeed.save();
    return;
  }
}

module.exports = {
  Translations,
  migrate
};
