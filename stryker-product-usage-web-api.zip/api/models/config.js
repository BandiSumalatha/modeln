module.exports = {
  DEFAULT_MODEL_SETTINGS: {
    underscored: true,
    freezeTableName: true
  }
};
