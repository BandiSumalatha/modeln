const QUERY = `
SELECT 
c.division__c division,
c.name case_name,
c.surgeon_name__c surgeon_name,
up_user.name, 
up_user.sfid sfid,
up_user.email email
FROM salesforce.cases__c c 
LEFT JOIN salesforce.user up_user 
  ON up_user.sfid = c.kit_assigner__c 
WHERE 
up_user.user_sfid like :user_sfid`;

module.exports = QUERY;
