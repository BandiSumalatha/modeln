const { herokuConnectClient } = require('../../../services/knex');
const { uniq } = require('lodash');

module.exports = {
    getBranches
}

async function getBranches(user_sfid, branchIds) {
  const inner = herokuConnectClient
        .withSchema('salesforce')
        .from('invlocation__c')
        .select("id")
        .where('userid__c', user_sfid)
        .where('invlocation__c.branchid__c', herokuConnectClient.raw('"branches2_mv"."branchID"'))
        .limit(1);

  const inventoryLocation = herokuConnectClient.raw(inner).wrap('exists (', ') as \"inventoryLocation\"');

  const query = herokuConnectClient
  .withSchema('repsuite')
  .select(
    'branchID',
    'branchName',
    'branchDivision',
    'operatingUnit',
    'mainBranch',
    inventoryLocation
  )
  .from('branches2_mv')
  .whereRaw(`"branchID" in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`)
  .orWhere(function() {
    return this
    .whereRaw(`"mainBranch" in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`)
      .whereExists(inner);
  });
  const branches = await query; 

  const mainBranches = uniq(branches.map(x => x.mainBranch).filter(x => x != null));
  const finalBranches = branches.map(x => ({
    ...x,
    inventoryLocation: x.inventoryLocation || !mainBranches.includes(x.branchID)
  }))

  return finalBranches || [];
}