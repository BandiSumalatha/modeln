const { herokuConnectClient } = require('../../../services/knex');

const caseUsagesUpdateKeys = [
    { matchingApp: 'quantity__c', matchingDb: 'quantity__c' },
    { matchingApp: 'lot_number__c', matchingDb: 'lot_number__c' },
    { matchingApp: 'wasteds__c', matchingDb: 'wasteds__c' },
    { matchingApp: 'side__c', matchingDb: 'side__c' },
    { matchingApp: 'usg_price__c', matchingDb: 'usg_price__c' },
    { matchingApp: 'used_from__c', matchingDb: 'used_from__c' },
    { matchingApp: 'lot_controlled__c', matchingDb: 'lot_controlled__c' },
    { matchingApp: 'ship_to__c', matchingDb: 'ship_to__c' },
    { matchingApp: 'shipto_location__c', matchingDb: 'shipto_location__c' },
    { matchingApp: 'replenish__c', matchingDb: 'replenish__c' },
    { matchingApp: 'procedure__c', matchingDb: 'procedure__c' },
    { matchingApp: 'price_override__c', matchingDb: 'price_override__c' },
    {
      matchingApp: 'inventory_product_system__c',
      matchingDb: 'inventory_product_system__c'
    },
    { matchingApp: 'override_price__c', matchingDb: 'override_price__c' },
    {
      matchingApp: 'usg_total_amount__c',
      matchingDb: 'usg_total_amount__c'
    },
    {
      matchingApp: 'contract__c',
      matchingDb: 'contract__c'
    },
    {
      matchingApp: 'csr_contract__c',
      matchingDb: 'csr_contract__c'
    },
    {
      matchingApp: 'csr_usage_price__c',
      matchingDb: 'csr_usage_price__c'
    },
    {
      matchingApp: 'csr_price_override__c',
      matchingDb: 'csr_price_override__c'
    },
    {
      matchingApp: 'expiry_date__c',
      matchingDb: 'expiry_date__c'
    },
    {
      matchingApp: 'serial_number__c',
      matchingDb: 'serial_number__c'
    },
    {
      matchingApp: 'unit_number__c',
      matchingDb: 'unit_number__c'
    }
  ];

  async function getAllCaseUsages(cases_external_id, cases__c) {
    if (!cases_external_id && !cases__c) {
      return [];
    }
  
    const query = herokuConnectClient
      .withSchema('salesforce')
      .select(
        'sfid',
        'external_id__c',
        'quantity__c',
        'lot_number__c',
        'wasteds__c',
        'side__c',
        'usg_price__c',
        'used_from__c',
        'lot_controlled__c',
        'ship_to__c',
        'shipto_location__c',
        'replenish__c',
        'procedure__c',
        'price_override__c',
        'inventory_product_system__c',
        'override_price__c',
        'usg_total_amount__c',
        'contract__c',
        'csr_contract__c',
        'csr_usage_price__c',
        'csr_price_override__c',
        'expiry_date__c',
        'serial_number__c',
        'unit_number__c'
      )
      .from('casesusage__c');
    if (cases_external_id) {
      query.where({
        surgical_cases__r__external_id__c: cases_external_id
      });
    } else {
      query.where({ surgical_cases__c: cases__c });
    }
    return query;
  }

  const getCUFilteredDataOnConditions = (object, base) => {
    return object.reduce(
      (acc, item) => {
        let updateItem = null;
        const baseObj = base.find(obj2 => {
          if (item.external_id__c) {
            return item.external_id__c === obj2.external_id__c;
          } else if (item.sfid) {
            return item.sfid === obj2.sfid;
          }
          return false;
        });
        if (baseObj) {
          updateItem = caseUsagesUpdateKeys.find(
            filter =>
              `${item[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
          );
        }
        if (updateItem) {
          item.external_id__c = baseObj.external_id__c;
          item.sfid = baseObj.sfid;
          acc.updateElements.push(item);
        } else if (!baseObj) {
          const { external_id__c, ...rest } = item;
          acc.insertElements.push(rest);
        }
        return acc;
      },
      { updateElements: [], insertElements: [] }
    );
  };

  const getCUDeleteDataOnConditions = (object, base) =>
    base.filter(
        obj =>
        !object.some(obj2 => {
            if (obj2.external_id__c) {
              return obj.external_id__c === obj2.external_id__c;
            } else if (obj2.sfid) {
              return obj2.sfid === obj.sfid;
            }
              return false;
        })
    );

    async function deleteCasesUsageProducts(products, trx) {
        const sfids = [],
          externalIds = [];
        for (const product of products) {
          if (product.sfid) {
            sfids.push(product.sfid);
          } else if (product.external_id__c) {
            externalIds.push(product.external_id__c);
          }
        }
      
        return herokuConnectClient('casesusage__c')
          .withSchema('salesforce')
          .transacting(trx)
          .where(function () {
            if (externalIds.length > 0 && sfids.length > 0) {
              this.whereIn('external_id__c', externalIds).orWhereIn('sfid', sfids);
            } else if (sfids.length > 0) {
              this.whereIn('sfid', sfids);
            } else {
              this.whereIn('external_id__c', externalIds);
            }
          })
          .del();
      }

    function updateCaseUsages(record, trx) {
        if (record.external_id__c || record.sfid) {
          
          delete record.surgical_cases__c;
          delete record.surgical_cases__r__external_id__c;
          
          const cupUpdate = herokuConnectClient('casesusage__c')
            .withSchema('salesforce')
            .update(record)
            .transacting(trx);
      
          // we should always have external id or sfid
          if (record.external_id__c) {
            cupUpdate.where('external_id__c', '=', record.external_id__c);
          } else if (record.sfid) {
            cupUpdate.where('sfid', '=', record.sfid);
          }
          return cupUpdate;
        }
        return Promise.resolve();
    }

module.exports = {
  getAllCaseUsages,
  getCUFilteredDataOnConditions,
  getCUDeleteDataOnConditions,
  deleteCasesUsageProducts,
  updateCaseUsages
}