const { groupBy } = require('lodash');
const { herokuConnectClient } = require('../../../services/knex');
const { getBranches } = require('./branches');

module.exports = {
  findUserPreferences
};

async function findUserPreferences(user, filters, branchId) {
  const user_sfid = user.sfids[0];
  const branchIds = branchId ? [...branchId.split(',')] : (await getBranches(user_sfid, user.branchIds)).map(x => x.branchID);
  console.log(branchIds);
  let query = herokuConnectClient
    .withSchema('salesforce')
    .select()
    .distinct([
      'surgeon_preference__c.name',
      'surgeon_preference__c.hospitalid__c',
      'surgeon_preference__c.branchid__c',
      'surgeon_preference__c.contactid__c',
      'surgeon_preference__c.procedureid__c',
      'surgeon_preference__c.isactive__c',
      'surgeon_preference__c.external_id__c',      
      'surgeon_preference__c.sfid',
      'procedure__c.name AS procedureName',
      'surgeon_preference__c.surg_pref_comments__c',
      'surgeon_preference__c.acetabular_component__c',
      'surgeon_preference__c.procedure__c',
      'surgeon_preference__c.approach__c',
      'surgeon_preference__c.femoral_component__c',
      'surgeon_preference__c.insert_type__c',
      'surgeon_preference__c.baseplate__c',
      herokuConnectClient.raw(
        `CONCAT (account.accountnumber, ' - ', account.name) AS "hospitalName"`
      ),
      herokuConnectClient.raw(
        `CONCAT (contact.surgeon_erp_code__c, ' - ', contact.name) AS "surgeonName"`
      ),
      'branch__c.name AS branch',
      'surgeon_preference__c.lastmodifieddate',
      'user.name as user_name',
      'user.sfid as created_user_sfid'
    ])
    .from('surgeon_preference__c')
    .innerJoin('account', 'surgeon_preference__c.hospitalid__c', 'account.sfid')
    .innerJoin(
      'branch__c',
      'surgeon_preference__c.branchid__c',
      'branch__c.sfid'
    )
    .leftJoin(
      'procedure__c',
      'surgeon_preference__c.procedureid__c',
      'procedure__c.sfid'
    )
    .leftJoin(
      'contact',
      'surgeon_preference__c.contactid__c',
      'contact.sfid'
    )
    .leftJoin(
      'user',
      'surgeon_preference__c.created_by_sales_rep__c',
      'user.sfid'
    )
    .whereIn('surgeon_preference__c.branchid__c', branchIds)
    .where(function() {
      this
        .where('procedure__c.isactive__c', true)
        .orWhereNull('procedure__c.isactive__c');
    })
    .orderBy('surgeon_preference__c.lastmodifieddate', 'desc', {
      nulls: 'first'
    });

  // Filters
  if (filters && filters.filterHospital) {
    query.where('hospitalid__c', filters.filterHospital);
  }
  if (filters && filters.filterSalesRep) {
    query.where('created_by_sales_rep__c', filters.filterSalesRep);
  }
  if (filters && filters.filterSurgeon) {
    query.where('contactid__c', filters.filterSurgeon);
  }
  if (filters && filters.procedure) {
    query.where(function() {
      this
        .where('procedureid__c', filters.procedure)
        .orWhere('procedure__c', filters.procedure);
    });
  }

  let preferences = await query;
  let preferencesSets = [];
  if (preferences) {
    preferences = groupBy(
      preferences,
      item => item.external_id__c || item.sfid
    );
    preferencesSets = await findSetsWithParts(branchIds, Object.keys(preferences));
    preferences = Object.keys(preferences).map(id => {
      const firstPreference = preferences[id][0];
      return {
        name: firstPreference.name,
        hospitalid__c: firstPreference.hospitalid__c,
        branchid__c: firstPreference.branchid__c,
        contactid__c: firstPreference.contactid__c,
        procedureid__c: firstPreference.procedureid__c,
        procedure__c: firstPreference.procedure__c,
        external_id__c: firstPreference.external_id__c,
        sfid: firstPreference.sfid,
        procedureName: firstPreference.procedureName ? firstPreference.procedureName : firstPreference.procedure__c,
        preferenceDetailId: firstPreference.preferenceDetailId,
        surg_pref_comments__c: firstPreference.surg_pref_comments__c,
        surgeonName: firstPreference.surgeonName,
        hospitalName: firstPreference.hospitalName,
        user_name: firstPreference.user_name,
        created_user_sfid: firstPreference.created_user_sfid,
        isactive__c: firstPreference.isactive__c,
        approach__c: firstPreference.approach__c,
        femoral_component__c: firstPreference.femoral_component__c,
        insert_type__c: firstPreference.insert_type__c,
        baseplate__c: firstPreference.baseplate__c,
        acetabular_component__c: firstPreference.acetabular_component__c,
        branch: firstPreference.branch
      };
    });
  }

  return { preferences: preferences || [], preferencesSets };
}

function findSetsWithParts(branchIds, preferenceIds) {
  return herokuConnectClient
    .withSchema('salesforce')
    .select()
    .distinct([
      'pd.surgeon_preference__r__external_id__c AS surgeon_preference__r__external_id__c',
      'pd.surgeon_preference__c AS surgeon_preference__c',
      'pd.sfid AS preferenceDetailId',
      'pd.isloaner__c AS loaner__c',
      'ps.sfid AS set_id',
      'ps.productsystemname__c AS set_name',
      herokuConnectClient.raw(`'Loaner' AS "setType"`),
      herokuConnectClient.raw(
        `CASE 
         WHEN p.sfid is not null and ps.sfid is not null and pspc.sfid is not null THEN true 
         ELSE false
        END AS "isPrefItemsValid"`
      )
    ])
    .from('preference_detail__c AS pd')
    .innerJoin('surgeon_preference__c AS sp', function() {
      this.on('sp.sfid', '=', 'pd.surgeon_preference__c');
      this.orOn('sp.external_id__c', '=', 'pd.surgeon_preference__r__external_id__c');
    })
    .leftJoin('procedure__c as p', function() { 
      this.on('p.sfid', 'sp.procedureid__c');
      this.on('p.isactive__c', herokuConnectClient.raw('?', [true]));
    })
    .leftJoin('product_system_procedure_category__c as pspc', function() {
      this.on('pspc.product_system__c', 'pd.product_system__c');
      this.on('pspc.procedure__c', 'sp.procedureid__c');
      this.onIn('pspc.branchid__c', branchIds);
      this.on('pspc.isactive__c', herokuConnectClient.raw('?', [true]));
    })
    .leftJoin('product_system__c AS ps', 'pd.product_system__c', 'ps.sfid')
    .whereIn('sp.sfid', preferenceIds)
    .orWhereIn('sp.external_id__c', preferenceIds);
}