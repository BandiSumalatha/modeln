const { herokuConnectClient } = require('../../../services/knex');
const { uniq } = require('lodash');

module.exports = {
    getBranches,
    getAllBranches
}

async function getAllBranches(user_sfid) {
  const userPersonas = await herokuConnectClient
    .withSchema('repsuite')
    .select('personas')
    .from('users_mv')
    .where('id', user_sfid);

  let specialUser = false;
  if (userPersonas && userPersonas.length > 0) {
    let personas = userPersonas[0].personas.toLowerCase();
    specialUser = personas.indexOf('in-house') !== -1 || personas.indexOf('csr') !== -1 || personas.indexOf('branch op') !== -1;
  }

  return herokuConnectClient
    .withSchema('repsuite')
    .select(
      herokuConnectClient.raw('branch as "branchID"'),
      herokuConnectClient.raw('name as "branchName"'),
      herokuConnectClient.raw('branchdivision as "branchDivision"'),
      herokuConnectClient.raw('mainbranch as "mainBranch"'),
      herokuConnectClient.raw('invlocation as "inventoryLocation"')
    )
    .from('branches3_mv')
    .where('userid', specialUser ? 'ALL' : user_sfid); 
}

async function getBranches(user_sfid, branchIds) {
  const userPersonas = await herokuConnectClient
    .withSchema('repsuite')
    .select('personas')
    .from('users_mv')
    .where('id', user_sfid);

  let specialUser = false;
  if (userPersonas && userPersonas.length > 0) {
    let personas = userPersonas[0].personas.toLowerCase();
    specialUser = personas.indexOf('in-house') !== -1 || personas.indexOf('csr') !== -1 || personas.indexOf('branch op') !== -1;
  }

  return herokuConnectClient
    .withSchema('repsuite')
    .select(
      herokuConnectClient.raw('branch as "branchID"'),
      herokuConnectClient.raw('name as "branchName"'),
      herokuConnectClient.raw('branchdivision as "branchDivision"'),
      herokuConnectClient.raw('mainbranch as "mainBranch"'),
      herokuConnectClient.raw('invlocation as "inventoryLocation"')
    )
    .from('branches3_mv')
    .where('userid', specialUser ? 'ALL' : user_sfid)
    .whereIn('branch', branchIds); 
}