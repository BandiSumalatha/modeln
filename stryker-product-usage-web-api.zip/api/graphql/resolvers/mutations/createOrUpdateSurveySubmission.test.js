jest.mock('../../../config', () => ({
  RATE_LIMIT_REQUESTS_PER_MINUTE: 120,
  HEROKU_CONNECT: {
    DATABASE_URL: 'test'
  }
}));

jest.mock('../../../services/salesforce', () => ({
  upsertSFObject: jest.fn().mockReturnValue({ id: 1 })
}));

jest.mock('../../services/sfdcTransformation', () => ({
  transformSurveyResponse: jest.fn()
}));

const createOrUpdateSurveySubmission = require('./createOrUpdateSurveySubmission');
describe('createOrUpdateSurveySubmission mutation', () => {
  it('should return response for a given payload', async () => {
    const definitionJson = `{"title": "IschemiaSurvey"}`;
    const args = {
      surveyResponseJson: `{"name": "Surgery Request California","status": "Requested","survey_date": "4/11/2018","recurrence": "one-time", "definition": ${definitionJson}}`,
      id: 1
    };

    const result = await createOrUpdateSurveySubmission({}, args, {});
    expect(result).toHaveProperty('response');
  });

  //TODO need to work on it to properly throw error
  it('should throw error', async () => {
    /**jest.mock('../../../services/salesforce', () => ({
      upsertSFObject: jest.fn().mockRejectedValue(new Error('Async error'))
    }));**/
    const definitionJson = `{"title": "IschemiaSurvey"}`;
    const args = {
      surveyResponseJson: `{"name": "Surgery Request California","status": "Requested","survey_date": "4/11/2018","recurrence": "one-time", "definition": ${definitionJson}}`,
      id: 1
    };

    const result = await createOrUpdateSurveySubmission({}, args, {});
    expect(result).toHaveProperty('response');
  });
});
