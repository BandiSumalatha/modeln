const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

module.exports = async (
    root,
    { caseSfid, fromCloud },
    context
) => {
    const currentUser = await context.currentUser(true);

    //If upload is FROM CLOUD button of web or upload is by mobile client
    if (fromCloud) {
        // updating history tracking
        caseActionTracker(
            currentUser,
            CASE_ACTION_TRACKER.PS_UPLOAD_CLOUD,
            caseSfid,
            null,
            null
        );
    } else { //If upload is FROM COMPUTER button of web
        // updating history tracking
        caseActionTracker(
            currentUser,
            CASE_ACTION_TRACKER.PS_UPLOAD_COMPUTER,
            caseSfid,
            null,
            null
        );
    }
    return true;
};