const moment = require("moment");
const {
  upsertSFObject,
} = require("../../../services/salesforce");
const Promise = require('bluebird');
const { getScansForTPR } = require('../../../common/fetchCases');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

const herokuConnectClient = require("../../../services/knex")
  .herokuConnectClient;

const statusMappingMako = {
  "TreatmentPlanAvailable": "Treatment Plan Available",
  "TreatmentPlanDelivered": "Treatment Plan Downloaded",
  "SignedOff": "Signed Off",
  "InDesign": "InDesign",
  "In Design": "InDesign"
};

const statusMappingAS1 = {
  "Created": "Created-Awaiting CT scan",
  "Rejected": "Rejected-Rework Required",
  "TreatmentPlanAvailable": "Surgical Plan Available",
  "ConditionallyApproved": "Surgical Plan Conditionally Approved",
  "ChangeRequested": "Surgical Plan Change Requested",
  "FinalPlanAvailable": "Final Plan Available and Product Manufacturing",
  "Approved": "Surgical Plan Approved",
  "ShippedToSales": "Shipped To Sales",
  "InDesign": "InDesign",
  "In Design": "InDesign"
};

module.exports = resolver;

async function resolver(root, { payload }, context) {
  let currentUser = await context.currentUser(true);
  const {
    case_sfid,
    tpr_name,
    treatment_plan_filename__c,
    cancellation_comment__c,
    assigned_rep__c,
    primary_mps__c,
    hospital__c,
    surgeon__c,
    right__c,
    left__c,
    cloned,
    branch__c,
    status__c,
    tpr_opened__c,
    external_tpr_id__c,
    sfid,
    external_id__c,
    patient_scan_id__c,
    cancellation_reason__c,
    rejection_reason__c,
    insert_type__c,
    internal_comments__c,
    patient_info_id__c,
    need_by_date__c,
    baseplate__c,
    femoral_component__c,
    procedure__c,
    covering_reps__c,
    treatment_plan_id__c,
    as1_insert_type__c,
    patient_pre_op_alignment__c,
    as1_femoral_component__c,
    catalog_description__c,
    insert_implant_3__c,
    tibia_preference__c,
    insert_implant_2__c,
    femur_implant__c,
    insert_trial_set__c,
    insert_implant_1__c,
    femur_preference__c,
    catalog_number__c,
    insert_thickness__c,
    tibia_implant__c,
    as1_baseplate__c,
    ct_scan_error_message__c,
    ct_scan_error_codes__c,
    surgeon_approval__c,
    surgical_plan_warning_message__c,
    surgical_plan_warning_codes__c,
    femoral_component_for_approach__c,
    acetabular_component__c,
    approach_tha__c,
    patient_scans,
    cup_size__c,
    head_size__c,
    stem_size__c,
    femoral_implant_size__c,
    tibial_implant_size__c,
  } = payload;

  let foundSfid = sfid;
  let foundExternalId = external_id__c;

  // Assumes UNIX epoch input

  let TPRObject = {
    assigned_rep__c,
    treatment_plan_filename__c,
    cancellation_comment__c,
    primary_mps__c,
    hospital__c,
    surgeon__c,
    right__c,
    left__c,
    branch__c,
    status__c,
    tpr_opened__c,
    external_tpr_id__c,
    lastmodifiedbyid: currentUser.sfids[0],
    cancellation_reason__c,
    rejection_reason__c,
    insert_type__c,
    internal_comments__c,
    patient_info_id__c, //removed need_by_date__c from this
    baseplate__c,
    femoral_component__c,
    procedure__c,
    covering_reps__c,
    treatment_plan_id__c,
    as1_insert_type__c,
    patient_pre_op_alignment__c,
    as1_femoral_component__c,
    catalog_description__c,
    insert_implant_3__c,
    tibia_preference__c,
    insert_implant_2__c,
    femur_implant__c,
    insert_trial_set__c,
    insert_implant_1__c,
    femur_preference__c,
    catalog_number__c,
    insert_thickness__c,
    tibia_implant__c,
    as1_baseplate__c,
    ct_scan_error_message__c,
    ct_scan_error_codes__c,
    surgeon_approval__c,
    surgical_plan_warning_message__c,
    surgical_plan_warning_codes__c,
    femoral_component_for_approach__c,
    acetabular_component__c,
    approach_tha__c,
  };

  let productObject = {};

  if (tpr_name) {
    TPRObject.name = tpr_name;
  }

  if (case_sfid) {
    productObject.surgical_case__c = case_sfid;

    if (status__c) {
      const caseResult = await herokuConnectClient("cases__c")
        .withSchema('salesforce')
        .select('as1__c', 'mako__c', 'name')
        .where('sfid', case_sfid);

      const { as1__c, mako__c, name } = caseResult && caseResult.length >= 1 ? caseResult[0] : { as1__c: false, mako__c: false, name: null };

      if (name && TPRObject.name && !TPRObject.name.startsWith(name)) {
        throw new Error(`Invalid attempt to make ${TPRObject.name} a child of ${name}: ${JSON.stringify(TPRObject)}`);
      }

      if (as1__c || mako__c) {
        if (as1__c) {
          TPRObject.status__c = statusMappingAS1[status__c] || status__c;
        } else if (mako__c) {
          TPRObject.status__c = statusMappingMako[status__c] || status__c;
        }
      } else {
        TPRObject.status__c = status__c;
      }
    }
  } else {
    if (status__c) {
      TPRObject.status__c = status__c;
    }
  }

  if (tpr_name) {
    TPRObject.name = tpr_name;
  }

  if (assigned_rep__c) {
    TPRObject.assigned_rep__c = assigned_rep__c;
  }

  if (treatment_plan_filename__c) {
    TPRObject.treatment_plan_filename__c = treatment_plan_filename__c;
  }

  if (cancellation_comment__c) {
    TPRObject.cancellation_comment__c = cancellation_comment__c;
  }

  if (primary_mps__c) {
    TPRObject.primary_mps__c = primary_mps__c;
  }
  if (hospital__c) {
    TPRObject.hospital__c = hospital__c;
  }
  if (surgeon__c) {
    TPRObject.surgeon__c = surgeon__c;
  }
  if (right__c) {
    TPRObject.right__c = right__c;
  }
  if (left__c) {
    TPRObject.left__c = left__c;
  }
  if (branch__c) {
    TPRObject.branch__c = branch__c;
  }

  if (tpr_opened__c) {
    TPRObject.tpr_opened__c = tpr_opened__c;
  }

  if (external_tpr_id__c) {
    TPRObject.external_tpr_id__c = external_tpr_id__c;
  }
  if (patient_scan_id__c) {
    TPRObject.patient_scan_id__c = patient_scan_id__c;
  }
  if (cancellation_reason__c) {
    TPRObject.cancellation_reason__c = cancellation_reason__c;
  }
  if (rejection_reason__c) {
    TPRObject.rejection_reason__c = rejection_reason__c;
  }
  if (insert_type__c) {
    TPRObject.insert_type__c = insert_type__c;
  }
  if (internal_comments__c) {
    TPRObject.internal_comments__c = internal_comments__c;
  }
  if (patient_info_id__c) {
    TPRObject.patient_info_id__c = patient_info_id__c;
  }
  if (need_by_date__c) {
    TPRObject.need_by_date__c = need_by_date__c;
  }
  if (baseplate__c) {
    TPRObject.baseplate__c = baseplate__c;
  }
  if (femoral_component__c) {
    TPRObject.femoral_component__c = femoral_component__c;
  }
  if (procedure__c) {
    TPRObject.procedure__c = procedure__c;
  }
  // if (patient_gender__c) {
  //   TPRObject.patient_gender__c = patient_gender__c;
  // }
  if (covering_reps__c) {
    TPRObject.covering_reps__c = covering_reps__c;
  }
  if (treatment_plan_id__c) {
    TPRObject.treatment_plan_id__c = treatment_plan_id__c;
  }
  if (as1_insert_type__c) {
    TPRObject.as1_insert_type__c = as1_insert_type__c;
  }
  if (patient_pre_op_alignment__c) {
    TPRObject.patient_pre_op_alignment__c = patient_pre_op_alignment__c;
  }
  if (as1_femoral_component__c) {
    TPRObject.as1_femoral_component__c = as1_femoral_component__c;
  }
  if (catalog_description__c) {
    TPRObject.catalog_description__c = catalog_description__c;
  }
  if (insert_implant_3__c) {
    TPRObject.insert_implant_3__c = insert_implant_3__c;
  }
  if (tibia_preference__c) {
    TPRObject.tibia_preference__c = tibia_preference__c;
  }
  if (insert_implant_2__c) {
    TPRObject.insert_implant_2__c = insert_implant_2__c;
  }
  if (femur_implant__c) {
    TPRObject.femur_implant__c = femur_implant__c;
  }
  if (insert_trial_set__c) {
    TPRObject.insert_trial_set__c = insert_trial_set__c;
  }
  if (insert_implant_1__c) {
    TPRObject.insert_implant_1__c = insert_implant_1__c;
  }
  if (femur_preference__c) {
    TPRObject.femur_preference__c = femur_preference__c;
  }
  if (catalog_number__c) {
    TPRObject.catalog_number__c = catalog_number__c;
  }
  if (insert_thickness__c) {
    TPRObject.insert_thickness__c = insert_thickness__c;
  }
  if (tibia_implant__c) {
    TPRObject.tibia_implant__c = tibia_implant__c;
  }
  if (as1_baseplate__c) {
    TPRObject.as1_baseplate__c = as1_baseplate__c;
  }
  if (ct_scan_error_message__c) {
    TPRObject.ct_scan_error_message__c = ct_scan_error_message__c;
  }
  if (ct_scan_error_codes__c) {
    TPRObject.ct_scan_error_codes__c = ct_scan_error_codes__c;
  }
  if (surgeon_approval__c) {
    TPRObject.surgeon_approval__c = surgeon_approval__c;
  }
  if (surgical_plan_warning_message__c) {
    TPRObject.surgical_plan_warning_message__c = surgical_plan_warning_message__c;
  }
  if (surgical_plan_warning_codes__c) {
    TPRObject.surgical_plan_warning_codes__c = surgical_plan_warning_codes__c;
  }
  if (femoral_component_for_approach__c) {
    TPRObject.femoral_component_for_approach__c = femoral_component_for_approach__c;
  }
  if (acetabular_component__c) {
    TPRObject.acetabular_component__c = acetabular_component__c;
  }
  if (approach_tha__c) {
    TPRObject.approach_tha__c = approach_tha__c;
  }
  if (cup_size__c && cup_size__c !== '' && !isNaN(parseFloat(cup_size__c))) {
    TPRObject.cup_size__c = cup_size__c;
  }
  if (head_size__c && head_size__c !== '' && !isNaN(parseFloat(head_size__c))) {
    TPRObject.head_size__c = head_size__c;
  }
  if (stem_size__c && stem_size__c !== '' && !isNaN(parseFloat(stem_size__c))) {
    TPRObject.stem_size__c = stem_size__c;
  }
  if (femoral_implant_size__c && femoral_implant_size__c !== '' && !isNaN(parseFloat(femoral_implant_size__c))) {
    TPRObject.femoral_implant_size__c = femoral_implant_size__c;
  }
  if (tibial_implant_size__c && tibial_implant_size__c !== '' && !isNaN(parseFloat(tibial_implant_size__c))) {
    TPRObject.tibial_implant_size__c = tibial_implant_size__c;
  }

  if (status__c === 'Rejected') {
    TPRObject.tpr_opened__c = false;
  }

  let identifier;
  if (foundSfid) {
    identifier = "sfid";
    TPRObject.sfid = foundSfid;
  } else if (foundExternalId) {
    identifier = "external_id__c";
    TPRObject.external_id__c = foundExternalId;
  } else {
    if (external_tpr_id__c) {
      let tprIds = await herokuConnectClient('treatment_plan_request__c')
        .withSchema('salesforce')
        .select('sfid', 'external_id__c')
        .where('external_tpr_id__c', external_tpr_id__c);

      if (tprIds.length > 0) {
        foundSfid = tprIds[0].sfid;
        foundExternalId = tprIds[0].external_id__c;
      }
    }

    if (tpr_name && !foundSfid && !foundExternalId) {
      let tprIds = await herokuConnectClient('treatment_plan_request__c')
        .withSchema('salesforce')
        .select('sfid', 'external_id__c')
        .where('name', tpr_name);

      if (tprIds.length > 0) {
        foundSfid = tprIds[0].sfid;
        foundExternalId = tprIds[0].external_id__c;
      }
    }

    if (foundSfid) {
      identifier = "sfid";
      TPRObject.sfid = foundSfid;
    }
    else if (foundExternalId) {
      identifier = "external_id__c";
      TPRObject.external_id__c = foundExternalId;
    }
    else {
      identifier = "external_id__c";
    }
  }

  TPRObject.lastmodifieddate = moment().toDate();

  if (!foundExternalId && !foundSfid) {
    TPRObject.createddate = moment().toDate();
    TPRObject.createdbyid = currentUser.sfids[0];
  }

  // reset tpr opened to false on submission
  if (status__c === 'Submitted') {
    if (foundExternalId || foundSfid) {
      let currentTprQuery = herokuConnectClient('treatment_plan_request__c')
        .withSchema('salesforce')
        .select('status__c');
      if (foundSfid) {
        currentTprQuery = currentTprQuery.where('sfid', foundSfid);
      }
      else {
        currentTprQuery = currentTprQuery.where('external_id__c', foundExternalId);
      }
      const currentTpr = await currentTprQuery;
      if (currentTpr && currentTpr.length > 0) {
        const currentTprStatus = currentTpr[0].status__c;
        if (currentTprStatus !== 'Submitted') {
          if (currentTprStatus === 'InDesign' || currentTprStatus === 'In Design') {
            TPRObject.status__c = 'InDesign';
            }
          TPRObject.tpr_opened__c = false;            
        }
      }
      else {
        TPRObject.tpr_opened__c = false;  
      }
    }
    else {
      TPRObject.tpr_opened__c = false;
    }
  }

  const dbPatientScans = await getScansForTPR({ tprSfid: foundSfid, tprExternalId: foundExternalId });
  const deletableScans = [];
  const payloadPatientScanMap = {};
  const payloadPatientScans = patient_scans ? patient_scans : [];
  for (const patientScan of payloadPatientScans) {
    if (patientScan.sfid) payloadPatientScanMap[patientScan.sfid] = patientScan;
    if (patientScan.external_id__c) payloadPatientScanMap[patientScan.external_id__c] = patientScan;
  }
  for (const patientScan of dbPatientScans) {
    if (!payloadPatientScanMap[patientScan.sfid] && !payloadPatientScanMap[patientScan.external_id__c]) {
      if (patientScan.sfid) {
        deletableScans.push({ sfid: patientScan.sfid });
      }
      else if (patientScan.external_id__c) {
        deletableScans.push({ external_id__c: patientScan.external_id__c });
      }
    }
  }

  // check whether the identifier and name match
  if (foundSfid || foundExternalId) {
    let dbTPR;
    if (foundSfid) {
      dbTPR = (await herokuConnectClient('treatment_plan_request__c')
        .withSchema('salesforce')
        .where('sfid', foundSfid)
        .select('name', 'external_tpr_id__c'))[0];
    }
    else {
      dbTPR = (await herokuConnectClient('treatment_plan_request__c')
        .withSchema('salesforce')
        .where('external_id__c', foundExternalId)
        .select('name', 'external_tpr_id__c'))[0];
    }

    if (TPRObject.name && TPRObject.name !== dbTPR.name) {
      throw new Error('Invalid attempt to change TPR name: ' + JSON.stringify(TPRObject));
    }

    if (TPRObject.external_tpr_id__c && TPRObject.external_tpr_id__c !== dbTPR.external_tpr_id__c) {
      throw new Error('Invalid attempt to change TPR RHS ID: ' + JSON.stringify(TPRObject));
    }
  }

  // check whether the linked case will match the name

  return await herokuConnectClient.transaction(function (trx) {
    return upsertSFObject(
      "salesforce.treatment_plan_request__c",
      TPRObject,
      identifier,
      trx
    ).then(function (tpr) {
      const promises = [];
      promises.push(Promise.resolve(tpr));
      for (let patient_scan_object of payloadPatientScans) {
        if (foundSfid) {
          patient_scan_object.tpr_id__c = foundSfid;
        }
        else if (tpr.external_id__c) {
          patient_scan_object.tpr_id__r__external_id__c = tpr.external_id__c;
        }
        if (patient_scan_object.external_id__c === null) {
          delete patient_scan_object.external_id__c;
        }
        if (patient_scan_object.tpr_id__r__external_id__c === null) {
          delete patient_scan_object.tpr_id__r__external_id__c;
        }

        if (patient_scan_object.ispatientscan__c === null || typeof patient_scan_object.ispatientscan__c == 'undefined') {
          patient_scan_object.ispatientscan__c = true;
        }

        if (patient_scan_object.issurgicalplan__c === null || typeof patient_scan_object.issurgicalplan__c == 'undefined') {
          patient_scan_object.issurgicalplan__c = false;
        }

        if (patient_scan_object.external_id__c) {
          promises.push(upsertSFObject(
            "salesforce.patient_scan__c",
            patient_scan_object,
            "external_id__c",
            trx
          ));
        } else {
          promises.push(upsertSFObject(
            "salesforce.patient_scan__c",
            patient_scan_object,
            "sfid",
            trx
          ));
        }
      }
      for (const deletableScan of deletableScans) {
        const deleteQuery = herokuConnectClient('patient_scan__c')
          .withSchema('salesforce')
          .transacting(trx)
          .del();
        if (deletableScan.sfid) {
          deleteQuery.where('sfid', deletableScan.sfid);
          promises.push(deleteQuery);
        }
        else if (deletableScan.external_id__c) {
          deleteQuery.where('external_id__c', deletableScan.sfid);
          promises.push(deleteQuery);
        }
      }
      if (!foundExternalId && !foundSfid) {
        productObject.treatment_plan_request__r__external_id__c = tpr.external_id__c;
        promises.push(
          upsertSFObject(
            "salesforce.surgical_case_products__c",
            productObject,
            "external_id__c",
            trx
          ).then(function (scp) {
            let updateObj = {};
            if (scp.sfid) {
              updateObj.surgical_case_details__c = scp.sfid;
            }
            if (scp.external_id__c) {
              updateObj.surgical_case_details__r__external_id__c = scp.external_id__c;
            }
            return herokuConnectClient('treatment_plan_request__c')
              .transacting(trx)
              .withSchema('salesforce')
              .where('external_id__c', tpr.external_id__c)
              .update(updateObj);
          })
        );
      }

      promises.push(
        herokuConnectClient('cases__c')
          .transacting(trx)
          .withSchema('salesforce')
          .where('sfid', case_sfid)
          .where('status__c', 'New')
          .update({
            status__c: 'Requested'
          })
      );

      return Promise.all(promises);
    })
      .then(trx.commit)
      .catch((error) => {
        trx.rollback(error);
        console.log(error);
        throw error;
      });
  }).then(function (results) {
    if (results && results.length > 0) {
      console.log('TPR Tracking; TPR Updated', results[0]);
      console.log('TPR Tracking; TPR External ID', results[0].external_id__c);
    }
    else {
      console.log('Could not get TPR ID.');
    }
    console.log('TPR Tracking; External ID from param', foundExternalId);
    console.log('TPR Tracking; Status', status__c);

    const tpr_external_id = results[0].external_id__c;

    // updating history tracking
    if (!foundSfid && !foundExternalId) {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_CREATED,
        case_sfid,
        null,
        tpr_external_id
      );
    }

    if (status__c === 'Submitted') {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_SUBMITTED,
        case_sfid,
        null,
        tpr_external_id
      );
    } else if (status__c === 'Cancelled') {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_CANCELLED,
        case_sfid,
        null,
        tpr_external_id
      );
    } else if (status__c === 'Treatment Plan Available' || status__c === 'TreatmentPlanAvailable') {
      console.log('TPR Tracking; TPR Uploaded');
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_UPLOADED,
        case_sfid,
        null,
        tpr_external_id
      );
    } else if (status__c === 'InDesign' || status__c === 'In Design') {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_INDESIGN,
        case_sfid,
        null,
        tpr_external_id
      );
    } else if (status__c === 'Rejected') {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_REJECTED,
        case_sfid,
        null,
        tpr_external_id
      );
    }

    if (cloned) {
      caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.TPR_CLONED,
        case_sfid,
        null,
        tpr_external_id
      );
    }

    return results[0];
  }).catch(function (error) {
    console.error(error);
  });
}