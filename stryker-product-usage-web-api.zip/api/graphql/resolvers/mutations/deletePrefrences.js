const { findUserPreferences } = require('../common/preferences');
const herokuConnectClient = require('../../../services/knex')
  .herokuConnectClient;

module.exports = async (root, { external_id__c, sfid }, context) => {
  const currentUser = await context.currentUser(true);
  if (external_id__c || sfid) {
    await herokuConnectClient
      .transaction(async trx => {
        try {
          await herokuConnectClient('surgeon_preference__c')
            .withSchema('salesforce')
            .where(function() {
              if (external_id__c && sfid) {
                this.where('external_id__c', external_id__c).orWhere(
                  'sfid',
                  sfid
                );
              } else if (external_id__c) {
                this.where('external_id__c', external_id__c);
              } else if (sfid) {
                this.where('sfid', sfid);
              }
            })

            .del();

          await herokuConnectClient('preference_detail__c')
            .withSchema('salesforce')
            .where(function() {
              if (external_id__c && sfid) {
                this.where(
                  'surgeon_preference__r__external_id__c',
                  external_id__c
                ).orWhere('surgeon_preference__c', sfid);
              } else if (external_id__c) {
                this.where(
                  'surgeon_preference__r__external_id__c',
                  external_id__c
                );
              } else if (sfid) {
                this.where('surgeon_preference__c', sfid);
              }
            })
            .del();

          trx.commit;
        } catch (e) {
          trx.rollback;
          throw e;
        }
      })

      .catch(error => {
        return error;
      });
    const preferences = await findUserPreferences(currentUser);
    return preferences || [];
  }
  return [];
};