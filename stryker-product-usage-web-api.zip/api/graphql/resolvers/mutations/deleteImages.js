const { createDeleteImageJob } = require('./../../../services/cloudAMQP');
const { fetchCases } = require('../../../common/fetchCases');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');
const herokuConnectClient = require('../../../services/knex').herokuConnectClient;

module.exports = async(
    _root, {
        surgical_cases__r__external_id__c,
        surgical_cases__c,
        images
    },
    context) => {
        const currentUser = await context.currentUser(true);

        let imageIds = images.map(x => x.azure_image_url);

        await createDeleteImageJob(
            surgical_cases__c,
            surgical_cases__r__external_id__c,
            false,
            [],
            imageIds
          );
  
        await deleteCasesUsageImages(
            surgical_cases__c,
            surgical_cases__r__external_id__c,
            imageIds
        );

        const imageCount = await countImages(surgical_cases__c, surgical_cases__r__external_id__c);

        if (imageCount==0 && (surgical_cases__r__external_id__c || surgical_cases__c)) {
            let updateCase =  herokuConnectClient('cases__c')
              .withSchema('salesforce')

            if (surgical_cases__r__external_id__c) {
                updateCase = updateCase.where({ external_id__c: surgical_cases__r__external_id__c });
            } else if (surgical_cases__c) {
                updateCase = updateCase.where({ sfid: surgical_cases__c });
            }

            await updateCase.update({
                'po_uploaded__c': false
            });
        }

        caseActionTracker(
            currentUser,
            CASE_ACTION_TRACKER.USAGE_UPDATED,
            surgical_cases__c,
            surgical_cases__r__external_id__c,
            null
          );

        const [myCase] = await fetchCases({
            externalId: surgical_cases__r__external_id__c,
            sfId: surgical_cases__c
        });
        return myCase;
    }

async function deleteCasesUsageImages(
    surgical_cases__c,
    surgical_cases__r__external_id__c,
    imageIds
) {
    const query = herokuConnectClient('case_images').withSchema('salesforce');
    if (surgical_cases__r__external_id__c) {
        query.where({ case_external_id: surgical_cases__r__external_id__c });
    } else if (surgical_cases__c) {
        query.where({ case_sfid: surgical_cases__c });
    } else {
        return;
    }
    query.whereNull('signature_by');
    if (imageIds.length > 0) {
        query.whereIn('case_images.azure_image_url', imageIds);
        await query.del();
    }
    return;        
}

async function countImages(
    surgical_cases__c,
    surgical_cases__r__external_id__c
) {
    const query = herokuConnectClient('case_images')
        .withSchema('salesforce')
        .count('id as i');
    if (surgical_cases__r__external_id__c) {
        query.where({ case_external_id: surgical_cases__r__external_id__c });
    } else if (surgical_cases__c) {
        query.where({ case_sfid: surgical_cases__c });
    } else {
        return 0;
    }
    query.whereNull('signature_by');
    const res = await query;
    return res[0].i;
}