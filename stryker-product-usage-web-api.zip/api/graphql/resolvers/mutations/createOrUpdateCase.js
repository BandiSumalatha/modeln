const moment = require('moment');
const { uniq } = require('lodash');
const {
  upsertSFObject,
  batchInsertSFObject
} = require('../../../services/salesforce');

const herokuConnectClient = require('../../../services/knex')
  .herokuConnectClient;

const { fetchCases } = require('../../../common/fetchCases');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

const { getInsertedData, getDeleteData } = require('../../../utils');

const { Timer, defaultTimeout } = require('../../../services/timer');

module.exports = resolver;

async function resolver(root, { payload }, context) {
  let currentUser = await context.currentUser(true);
  const {
    division__c,
    branchid__c,
    hospitalid__c,
    hospital_staffid__c,
    patient_info__c,
    procedureid__c,
    kit_assigner__c,
    kitdelivery_date__c,
    delivery_options__c,
    ship_to__c,
    covering_reps__c,
    cap_price__c,
    revisions__c,
    case_coverage__c,
    surgery_date_time,
    status__c,
    cancel_reason__c,
    external_id__c,
    left__c,
    right__c,
    mako__c,
    adapt__c,
    sfid,
    favourite__c,
    is_hospital_owned__c,
    coveringRepsName,
    procedure_list__c,
    hospital_location__c,
    subbranch,
    as1__c,
    surgery_date_confirmed__c,
    patient_gender__c,
  } = payload;

  const editabilityTimer = new Timer('createCase.editableCheck', defaultTimeout);
  await editabilityTimer.start();
  if (sfid || external_id__c) {
    let retrievedStatuses = herokuConnectClient('cases__c')
      .withSchema('salesforce')
      .select('status__c')
      .limit(1);

    if (sfid) {
      retrievedStatuses = await retrievedStatuses.where('sfid', sfid);
    }
    else if (external_id__c) {
      retrievedStatuses = await retrievedStatuses.where('external_id__c', external_id__c);
    }

    if (retrievedStatuses && retrievedStatuses.length === 1) {
      let status = retrievedStatuses[0].status__c;
      if (status === 'Completed' || status === 'Cancelled') {
        const [myCase] = await fetchCases({
          externalId: external_id__c, 
          sfId: sfid });
        await editabilityTimer.stop();
        return myCase;
      }
    }
  }
  await editabilityTimer.stop();

  // Assumes UNIX epoch input

  let caseObject = {
    division__c,
    branchid__c,
    hospitalid__c,
    hospital_staffid__c,
    patient_info__c,
    kit_assigner__c,
    kitdelivery_date__c,
    delivery_options__c,
    ship_to__c,
    cap_price__c,
    revisions__c,
    favourite__c,
    case_coverage__c,
    createdbyid: currentUser.sfids[0],
    lastmodifiedbyid: currentUser.sfids[0],
    left__c,
    right__c,
    mako__c,
    adapt__c,
    is_hospital_owned__c,
    covering_reps__c,
    current_logged_in_user__c: currentUser.sfids[0],
    hospital_location__c,
    region_filter__c: subbranch,
    as1__c,
    surgery_date_confirmed__c,
    patient_gender__c,
  };

  if (surgery_date_time) {
    caseObject.surgery_start_date_time__c = moment(
      new Date(parseInt(surgery_date_time))
    ).toDate();
  }

  if (kitdelivery_date__c) {
    caseObject.kitdelivery_date__c = moment(
      new Date(parseInt(kitdelivery_date__c))
    ).toDate();
  }

  let converRepsSfids = caseObject.covering_reps__c;
  caseObject.covering_reps__c = coveringRepsName;

  caseObject.status__c = status__c || 'New';

  if (cancel_reason__c) {
    caseObject.cancel_reason__c = cancel_reason__c;
  }

  if (procedure_list__c) {
    caseObject.procedure_list__c = procedure_list__c;
  }

  if(procedureid__c) {
    caseObject.procedureid__c = procedureid__c;
  }

  if (cap_price__c === null && !(sfid || external_id__c)) {
    caseObject.cap_price__c = false;
  }

  caseObject.non_usage_orders__c = false;

  let identifier = 'external_id__c';
  if (sfid) {
    identifier = 'sfid';
    caseObject.sfid = sfid;
  } else if (external_id__c) {
    identifier = 'external_id__c';
    caseObject.external_id__c = external_id__c;
  }

  const coverRepsRetrieval = async () => {
    if (!converRepsSfids) return null;

    if (!converRepsSfids.includes(kit_assigner__c)) {
      converRepsSfids = `${converRepsSfids}, ${kit_assigner__c}`;
    }

    const coveringReps = converRepsSfids
      .split(',')
      .map(item => ({ sfid: item.trim() }));

    let appCoveringReps = uniq(coveringReps);

    const matchingArr = appCoveringReps.filter(
      cr => cr.sfid === kit_assigner__c
    );
    if (matchingArr && matchingArr.length === 0) {
      appCoveringReps.push({ sfid: kit_assigner__c });
    }
    let insertedSaleRep = appCoveringReps,
      deletedSaleRep = [];
    if (external_id__c || sfid) {
      const salesRepTimer = new Timer('createCase.salesReps', defaultTimeout);
      await salesRepTimer.start();
      const dbSaleRep = await getAllSaleRep(external_id__c, sfid);
      await salesRepTimer.stop();

      insertedSaleRep = getInsertedData(
        appCoveringReps,
        dbSaleRep,
        'sfid',
        'sales_rep__c'
      );

      deletedSaleRep = getDeleteData(
        appCoveringReps,
        dbSaleRep,
        'sfid',
        'sales_rep__c'
      );
    }

    return { insertedSaleRep, deletedSaleRep };
  };

  let externalId = '';
  let sfId = '';
  
  return await herokuConnectClient
    .transaction(async trx => {
      try {
        caseObject.changedby__c = `${currentUser.first_name} ${
          currentUser.last_name
        }`;

        const caseTimer = new Timer('createCase.updateCase', defaultTimeout);
        await caseTimer.start();
        const result = await upsertSFObject(
          'salesforce.cases__c',
          caseObject,
          identifier,
          trx
        );
        await caseTimer.stop();

        if (result) {
          externalId = result.external_id__c;
          sfId = result.sfid;

          const coveringTimer = new Timer('createCase.coveringReps', defaultTimeout);
          await coveringTimer.start();

          const ops = [];          
          const [coverRepsResponse] = await Promise.all([
            coverRepsRetrieval()
          ]);          
          if (coverRepsResponse) {
            if (coverRepsResponse.deletedSaleRep.length > 0)
              ops.push(deleteSalesReps(coverRepsResponse.deletedSaleRep, trx));

            if (coverRepsResponse.insertedSaleRep.length > 0)
              ops.push(
                saveSaleRep(
                  coverRepsResponse.insertedSaleRep,
                  branchid__c,
                  externalId,
                  sfId,
                  trx
                )
              );
          }

          await Promise.all(ops);
          await coveringTimer.stop();

          await trx.commit;
        }
      } catch (e) {
        await trx.rollback;
        throw e;
      }
    })
    .then(async () => {
      const trackingTimer = new Timer('createCase.tracking', defaultTimeout);
      await trackingTimer.start();
      // updating history tracking
      caseActionTracker(
        currentUser,
        sfId
          ? CASE_ACTION_TRACKER.CASE_UPDATED
          : CASE_ACTION_TRACKER.CASE_CREATED,
        sfId,
        externalId,
        null
      );
      await trackingTimer.stop();

      const refetchTimer = new Timer('createCase.refetch', defaultTimeout);
      await refetchTimer.start();
      const [myCase] = await fetchCases({ externalId, sfId });
      await refetchTimer.stop();

      return myCase;
    });
}

async function deleteSalesReps(salesReps, trx) {
  const sfids = [],
    externalIds = [];
  salesReps.forEach(x => {
    if (x.sfid) {
      sfids.push(x.sfid);
    } else if (x.external_id__c) {
      externalIds.push(x.external_id__c);
    }
  });

  return herokuConnectClient('surgical_case_sales_team__c')
    .withSchema('salesforce')
    .transacting(trx)
    .where(function() {
      if (sfids.length > 0 && externalIds.length > 0) {
        this.whereIn('external_id__c', externalIds).orWhereIn('sfid', sfids);
      } else if (sfids.length > 0) {
        this.whereIn('sfid', sfids);
      } else {
        this.whereIn('external_id__c', externalIds);
      }
    })
    .del();
}

async function saveSaleRep(
  coveringReps,
  branchid__c,
  surgical_cases__r__external_id__c,
  surgical_cases__c,
  trx
) {
  const caseSaleRep = coveringReps.map(item => {
    return {
      sales_rep__c: item.sfid,
      branchid__c,
      surgical_cases__r__external_id__c,
      surgical_cases__c
    };
  });

  await batchInsertSFObject(
    'salesforce.surgical_case_sales_team__c',
    caseSaleRep,
    trx
  );
}

async function getAllSaleRep(external_id__c, surgical_cases) {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select('sfid', 'external_id__c', 'sales_rep__c')
    .from('surgical_case_sales_team__c');
  if (external_id__c) {
    query.where({ surgical_cases__r__external_id__c: external_id__c });
  } else {
    query.where({ surgical_cases__c: surgical_cases });
  }
  return query;
}
