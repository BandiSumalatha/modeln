const { upsertSFObject } = require('../../../services/salesforce');
const herokuConnectClient = require('../../../services/knex')
  .herokuConnectClient;

module.exports = resolver;

async function resolver(
  root,
  { name, address, city, state, zip, external_id__c },
  context
) {
  await herokuConnectClient
    .transaction(async trx => {
      try {
        let addressObject = {
          name,
          address1__c: address,
          city__c: city,
          state_province__c: state,
          postalcode__c: zip,
          external_id__c: external_id__c && external_id__c
        };

        const addressResult = await upsertSFObject(
          'salesforce.address__c',
          addressObject,
          'external_id__c'
        );
        if (addressResult) {
          response = JSON.stringify(addressResult);
          // externalId = result.external_id__c;
        }
        trx.commit;
      } catch (e) {
        trx.rollback;
        throw e;
      }
    })
    .catch(error => {
      throw error;
    });

  return true;
}
