const refreshJwt = require('./refreshJwt');
describe('refreshJwt mutation', () => {
  it('should return a response for a given refresh token', async () => {
    const args = {
      refresh_token: 'mock'
    };
    const response = await refreshJwt({}, args, {});
    expect(response).toBe(undefined);
  });
});
