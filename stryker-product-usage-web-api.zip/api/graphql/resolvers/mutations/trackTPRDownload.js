const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

module.exports = async (
    root,
    { caseSfid, tprExternalId },
    context
) => {
    const currentUser = await context.currentUser(true);
    //This will be called when TPR is downloaded from web client
    if (caseSfid) {
        // updating history tracking
        caseActionTracker(
            currentUser,
            CASE_ACTION_TRACKER.TPR_DOWNLOADED,
            caseSfid,
            null,
            tprExternalId
        );
        return true;
    } else {
        return false;
    }
};
