const client = require('../../../services/knex').herokuConnectClient;
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

module.exports = async (
  root,
  { sfid, external_id, reason, comments },
  context
) => {
  const currentUser = await context.currentUser(true);

  let whereClause = {};
  if (external_id) {
    whereClause.external_id__c = external_id;
  } else if (sfid) {
    whereClause.sfid = sfid;
  } else {
    throw new Error(`A valid sfid or external_id must be supplied`);
  }

  await client('cases__c')
    .withSchema('salesforce')
    .where(whereClause)
    .update({
      status__c: 'Cancelled',
      cancel_reason__c: reason,
      cancel_comment__c: comments,
      changedby__c: `${currentUser.first_name} ${currentUser.last_name}`
    });

  // updating history tracking
  caseActionTracker(
    currentUser,
    CASE_ACTION_TRACKER.CASE_CANCELLED,
    sfid,
    external_id,
    null
  );

  return true;
};
