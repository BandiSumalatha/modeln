const { UserFilter } = require('../../../models/UserFilter');

module.exports = async (root, args, context) => {
  const currentUser = await context.currentUser(false);
  const { id } = args;
  await UserFilter.findOne({ _id: id })
    .remove()
    .exec();
  let response = UserFilter.find({
    user_sfid: currentUser.sfids[0]
  }).exec();
  return response;
};
