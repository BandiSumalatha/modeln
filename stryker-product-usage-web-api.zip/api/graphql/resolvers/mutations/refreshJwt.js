const { OAUTH } = require('../../../config');
const axios = require('axios');
const qs = require('qs');
const moment = require('moment');
const { getRHSToken, RHS_SCOPES } = require("../../../services/rhsAuthentication");

module.exports = async (root, args, context) => {
  const { refresh_token } = args;
  const tokenUrl = OAUTH.TOKEN_URL;
  const client_id = OAUTH.CLIENT_ID;
  const client_secret = OAUTH.CLIENT_SECRET;
  const scope = OAUTH.SCOPE;

  const result = await axios.post(tokenUrl, qs.stringify({
    grant_type: 'refresh_token',
    refresh_token,
    client_id,
    client_secret,
    scope
  }));  

  if (!result || !result.data) {
    throw new Error("Failed to retrieve token.");
  }
  
  const access_token = result.data.access_token;
  const new_refresh_token = result.data.refresh_token;

  const mako_token = await getRHSToken(new_refresh_token, RHS_SCOPES.MAKO);
  const as1_token = await getRHSToken(new_refresh_token, RHS_SCOPES.AS1);

  const expires_in = moment().add(result.data.expires_in, 's').toDate().getTime();

  return {
    access_token,
    refresh_token: new_refresh_token,
    mako_token,
    as1_token,
    expires_in
  };
};
