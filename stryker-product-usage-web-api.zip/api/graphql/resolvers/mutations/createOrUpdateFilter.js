const { UserFilter } = require('../../../models/UserFilter');
const mongoose = require('../../../services/mongoose');
const {
  transformSurveyResponse
} = require('../../services/sfdcTransformation');

module.exports = async (root, args, context) => {
  const { id, name, user_sfid, definition } = args;
  let response = await UserFilter.findOneAndUpdate(
    { name },
    { name, user_sfid, definition },
    {
      upsert: true,
      new: true
    }
  ).exec();

  return response;
};
