const { herokuConnectClient } = require('../../../services/knex');
const { fetchCases } = require('../../../common/fetchCases');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');

module.exports = async (
  root,
  { surgical_cases__r__external_id__c, surgical_cases__c, caseDetail },
  context
) => {
  if(surgical_cases__r__external_id__c || surgical_cases__c) {
    const currentUser = await context.currentUser(true);
    caseDetail.changedby__c = `${currentUser.first_name} ${
      currentUser.last_name
    }`;
    // Update Cases__c' object
    const caseUpdate = herokuConnectClient('cases__c')
      .withSchema('salesforce')
      .update({
        ...caseDetail
      });
  
    if (surgical_cases__r__external_id__c) {
      caseUpdate.where('external_id__c', '=', surgical_cases__r__external_id__c);
    } else if (surgical_cases__c) {
      caseUpdate.where('sfid', '=', surgical_cases__c);
    }
  
    await caseUpdate;
  
    // updating history tracking
    caseActionTracker(
      currentUser,
      CASE_ACTION_TRACKER.CASE_UPDATED,
      surgical_cases__c,
      surgical_cases__r__external_id__c
    );
  
    const [myCase] = await fetchCases({
      externalId: surgical_cases__r__external_id__c,
      sfId: surgical_cases__c
    });
  
    return myCase;
  }
  return;
  
};
