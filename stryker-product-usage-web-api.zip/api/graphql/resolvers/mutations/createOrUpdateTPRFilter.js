const { TPRFilter } = require('../../../models/TPRFilter');

module.exports = async(_root, args, context) => {
    const { name } = args;
    const currentUser = await context.currentUser(false);
    const user_sfid = currentUser.sfids[0];

    let response = await TPRFilter.findOneAndUpdate(
        { name, user_sfid },
        { name, user_sfid, definition: { ...args } },
        { 
            upsert: true,
            new: true
        }
    ).exec();

    return response;
}