const { fetchCases } = require('../../../common/fetchCases');
const client = require('../../../services/knex').herokuConnectClient;
const { Timer, defaultTimeout } = require('../../../services/timer');

module.exports = async (
  root,
  { sfid, external_id, quickquote_code, quickquote_rationale, usage_override, usage_finalamount, freight_charges, usagePriceContracts },
  context
) => {
  const currentUser = await context.currentUser(true);
  const changedby__c = `${currentUser.first_name} ${currentUser.last_name}`;

  await client.transaction(async trx => {
    const usageTimer = new Timer('setContractPrices.usages', defaultTimeout);
    await usageTimer.start();
    for (const usagePrice of usagePriceContracts) {
      let caseUpdate = trx('casesusage__c')
        .withSchema('salesforce');
        
      if (usagePrice.external_id) {
        caseUpdate = caseUpdate.where('external_id__c', '=', usagePrice.external_id);
      } else if (usagePrice.sfid) {
        caseUpdate = caseUpdate.where('sfid', '=', usagePrice.sfid);
      } else {
        throw new Error(`A valid sfid or external_id must be supplied for each usage`);
      }

      await caseUpdate.update({
        contract__c: usagePrice.contract,
        usg_price__c: usagePrice.usg_price,
        override_price__c: usagePrice.price_override,
        usg_total_amount__c: usagePrice.usg_total_amount,
        quantity__c: usagePrice.quantity        
      });
    }
    await usageTimer.stop();

    let whereClause = {};
    if (external_id) {
      whereClause.external_id__c = external_id;
    } else if (sfid) {
      whereClause.sfid = sfid;
    } else {
      throw new Error(`A valid sfid or external_id must be supplied for each usage`);
    }

    const freightCharges = freight_charges && !isNaN(parseFloat(freight_charges)) ? parseFloat(freight_charges) : 0;
    const usageFinalAmount = usage_finalamount && !isNaN(parseFloat(usage_finalamount)) ? parseFloat(usage_finalamount) : 0;

    //To update cases__c 
    const caseTimer = new Timer('setContractPrices.case', defaultTimeout);
    await caseTimer.start();

    let caseWrite = {
      cap_price__c : false,
      total_cap_price__c: null,
      usage_override__c : usage_override,
      usage_finalamount__c : usageFinalAmount,
      charges__c : freightCharges,
      order_amount__c : usageFinalAmount + freightCharges,
      changedby__c
    };

    if (quickquote_code) caseWrite.quickquote_code__c = quickquote_code;
    if (quickquote_rationale) caseWrite.quickquote_rationale__c = quickquote_rationale;

    await trx('cases__c')
      .withSchema('salesforce')
      .where(whereClause)
      .update(caseWrite);
    await caseTimer.stop();
  });

  const refetchTimer = new Timer('setContractPrices.refetch', defaultTimeout);
  await refetchTimer.start();
  const [myCase] = await fetchCases({
    externalId: external_id,
    sfId: sfid
  });
  await refetchTimer.stop();
  return myCase;
};
