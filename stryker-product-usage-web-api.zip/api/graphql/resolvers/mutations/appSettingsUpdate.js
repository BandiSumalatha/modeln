const { upsertSFObject } = require('../../../services/salesforce');
const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (
  root,
  {
    oracle_order_notify__c,
    ship_ready_for_surgery_sets_notification__c,
    sets_cancelled_removed_notification__c,
    case_cancelled_notification__c,
    requested_sets_notification__c,
    send_email_invite_notification__c,
    new_patient_scan_available__c,
    tpr_cancelled__c,
    tpr_creation_notification__c,
    tpr_indesign_notification__c,
    tpr_rejection_notification__c,
    tpr_submission_notification__c,
    tpr_as1_indesign_notification__c,
    tpr_as1_rejected_notification__c,
    tpr_as1_submmision_notification__c,
    tpr_as1_cancelled_notification__c,
    tpr_as1_signed_off_notification__c,
    tpr_treatmentplanavailable_notification__c,
    treatment_plan_downloaded__c,
    external_id__c,
    sfid,
    branch__c,
    tpr_created_awaiting_ct_scan__c,
    tpr_surgical_plan_available_notiify__c,
    tpr_completed_notification__c,
    tpr_surgicalplan_conditionally_approved__c,
    tpr_surgicalplan_change_requested__c,
    tpr_surgical_plan_approved__c,
    tpr_finalplanavail_manf__c,
    tpr_shiped_to_sales_notification__c

  },
  context
) => {
  const currentUser = await context.currentUser(true);
  const { branchIds } = currentUser;

  const existing = await herokuConnectClient
    .withSchema('salesforce')
    .select('sfid', 'external_id__c', 'branch__c')
    .from('repsuiteapp_settings__c')
    .where('user__c', currentUser.sfids[0])
    .where('isdeleted', false)
    .whereRaw(`branch__c in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`);

  let existingMap = {};
  for (var current of existing) {
    existingMap[current.branch__c] = { sfid: current.sfid, external_id__c: current.external_id__c };
  }

  try {
    let updates = [];
    for (var branch of branchIds) {
      let identifier = 'external_id__c';
      let upsertObj = {
        oracle_order_notify__c,
        ship_ready_for_surgery_sets_notification__c,
        sets_cancelled_removed_notification__c,
        case_cancelled_notification__c,
        requested_sets_notification__c,
        send_email_invite_notification__c,
        branch__c: branch,
        user__c: currentUser.sfids[0],
        name: `${currentUser.first_name} ${currentUser.last_name}`
      };

      if (existingMap[branch]) {
        if (existingMap[branch].external_id__c) {
          upsertObj.external_id__c = existingMap[branch].external_id__c;
        }
        else if (existingMap[branch].sfid) {
          upsertObj.sfid = existingMap[branch].sfid;
          identifier = 'sfid';
        }
      }

      if (new_patient_scan_available__c != null && typeof new_patient_scan_available__c != 'undefined') {
        upsertObj.new_patient_scan_available__c = new_patient_scan_available__c;
      }

      if (tpr_cancelled__c != null && typeof tpr_cancelled__c != 'undefined') {
        upsertObj.tpr_cancelled__c = tpr_cancelled__c;
      }

      if (tpr_creation_notification__c != null && typeof tpr_creation_notification__c != 'undefined') {
        upsertObj.tpr_creation_notification__c = tpr_creation_notification__c;
      }

      if (tpr_indesign_notification__c != null && typeof tpr_indesign_notification__c != 'undefined') {
        upsertObj.tpr_indesign_notification__c = tpr_indesign_notification__c;
      }

      if (tpr_rejection_notification__c != null && typeof tpr_rejection_notification__c != 'undefined') {
        upsertObj.tpr_rejection_notification__c = tpr_rejection_notification__c;
      }

      if (tpr_submission_notification__c != null && typeof tpr_submission_notification__c != 'undefined') {
        upsertObj.tpr_submission_notification__c = tpr_submission_notification__c;
      }

      if (tpr_as1_indesign_notification__c != null && typeof tpr_as1_indesign_notification__c != 'undefined') {
        upsertObj.tpr_as1_indesign_notification__c = tpr_as1_indesign_notification__c;
      }

      if (tpr_as1_rejected_notification__c != null && typeof tpr_as1_rejected_notification__c != 'undefined') {
        upsertObj.tpr_as1_rejected_notification__c = tpr_as1_rejected_notification__c;
      }

      if (tpr_as1_submmision_notification__c != null && typeof tpr_as1_submmision_notification__c != 'undefined') {
        upsertObj.tpr_as1_submmision_notification__c = tpr_as1_submmision_notification__c;
      }

      if (tpr_as1_cancelled_notification__c != null && typeof tpr_as1_cancelled_notification__c != 'undefined') {
        upsertObj.tpr_as1_cancelled_notification__c = tpr_as1_cancelled_notification__c;
      }

      if (tpr_as1_signed_off_notification__c != null && typeof tpr_as1_signed_off_notification__c != 'undefined') {
        upsertObj.tpr_as1_signed_off_notification__c = tpr_as1_signed_off_notification__c;
      }

      if (tpr_treatmentplanavailable_notification__c != null && typeof tpr_treatmentplanavailable_notification__c != 'undefined') {
        upsertObj.tpr_treatmentplanavailable_notification__c = tpr_treatmentplanavailable_notification__c;
      }

      if (treatment_plan_downloaded__c != null && typeof treatment_plan_downloaded__c != 'undefined') {
        upsertObj.treatment_plan_downloaded__c = treatment_plan_downloaded__c;
      }

      if (tpr_created_awaiting_ct_scan__c != null && typeof tpr_created_awaiting_ct_scan__c != 'undefined') {
        upsertObj.tpr_created_awaiting_ct_scan__c = tpr_created_awaiting_ct_scan__c;
      }

      if (tpr_surgical_plan_available_notiify__c != null && typeof tpr_surgical_plan_available_notiify__c != 'undefined') {
        upsertObj.tpr_surgical_plan_available_notiify__c = tpr_surgical_plan_available_notiify__c;
      }

      if (tpr_completed_notification__c != null && typeof tpr_completed_notification__c != 'undefined') {
        upsertObj.tpr_completed_notification__c = tpr_completed_notification__c;
      }
      if (tpr_surgicalplan_conditionally_approved__c != null && typeof tpr_surgicalplan_conditionally_approved__c != 'undefined') {
        upsertObj.tpr_surgicalplan_conditionally_approved__c = tpr_surgicalplan_conditionally_approved__c;
      }
      if (tpr_surgicalplan_change_requested__c != null && typeof tpr_surgicalplan_change_requested__c != 'undefined') {
        upsertObj.tpr_surgicalplan_change_requested__c = tpr_surgicalplan_change_requested__c;
      }
      if (tpr_surgical_plan_approved__c != null && typeof tpr_surgical_plan_approved__c != 'undefined') {
        upsertObj.tpr_surgical_plan_approved__c = tpr_surgical_plan_approved__c;
      }
      if (tpr_finalplanavail_manf__c != null && typeof tpr_finalplanavail_manf__c != 'undefined') {
        upsertObj.tpr_finalplanavail_manf__c = tpr_finalplanavail_manf__c;
      }
      if (tpr_shiped_to_sales_notification__c != null && typeof tpr_shiped_to_sales_notification__c != 'undefined') {
        upsertObj.tpr_shiped_to_sales_notification__c = tpr_shiped_to_sales_notification__c;
      }



      updates.push(upsertSFObject(
        'salesforce.repsuiteapp_settings__c',
        upsertObj,
        identifier
      ));
    }

    await Promise.all(updates);
    return true;
  }
  catch (e) {
    console.log(e);
    return false;
  }
}