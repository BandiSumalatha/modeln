const { fetchCases } = require('../../../common/fetchCases');
const client = require('../../../services/knex').herokuConnectClient;
const { Timer, defaultTimeout } = require('../../../services/timer');

module.exports = async (
  root,
  { sfid, external_id, cap_price, total_cap_price, freight_charges, usage_override, usage_finalamount, usagePrices },
  context
) => {
  const currentUser = await context.currentUser(true);
  const changedby__c = `${currentUser.first_name} ${currentUser.last_name}`;

  await client.transaction(async trx => {
    let totalUpcharge = 0.0;
    let override = false;
    
    const usageTimer = new Timer('setCapPrices.usages', defaultTimeout);
    await usageTimer.start();
    for (const usagePrice of usagePrices) {
      let caseUpdate = trx('casesusage__c')
        .withSchema('salesforce');
        
      if (usagePrice.external_id) {
        caseUpdate = caseUpdate.where('external_id__c', '=', usagePrice.external_id);
      } else if (usagePrice.sfid) {
        caseUpdate = caseUpdate.where('sfid', '=', usagePrice.sfid);
      } else {
        throw new Error(`A valid sfid or external_id must be supplied for each usage`);
      }

      if (usagePrice.usg_total_amount && !isNaN(parseFloat(usagePrice.usg_total_amount))) {
        totalUpcharge += parseFloat(usagePrice.usg_total_amount);
        override = true;
      }

      await caseUpdate.update({
        contract__c: null,
        usg_price__c: usagePrice.usg_price,
        override_price__c: false,
        usg_total_amount__c: usagePrice.usg_total_amount,
        quantity__c: usagePrice.quantity
      });
    }
    await usageTimer.stop();

    let whereClause = {};
    if (external_id) {
      whereClause.external_id__c = external_id;
    } else if (sfid) {
      whereClause.sfid = sfid;
    } else {
      throw new Error(`A valid sfid or external_id must be supplied for each usage`);
    }

    const totalCapPrice = total_cap_price && !isNaN(parseFloat(total_cap_price)) ? parseFloat(total_cap_price) : 0;
    const freightCharges = freight_charges && !isNaN(parseFloat(freight_charges)) ? parseFloat(freight_charges) : 0;

    const caseTimer = new Timer('setCapPrices.case', defaultTimeout);
    await caseTimer.start();
    //To update cases__c 
    await trx('cases__c')
      .withSchema('salesforce')
      .where(whereClause)
      .update({
        cap_price__c : true,
        total_cap_price__c : totalCapPrice,
        charges__c : freightCharges,
        usage_override__c : override,
        usage_finalamount__c : totalUpcharge,
        order_amount__c : totalCapPrice + totalUpcharge + freightCharges,
        changedby__c
      });
    await caseTimer.stop();
  });

  const refetchTimer = new Timer('setCapPrices.refetch', defaultTimeout);
  await refetchTimer.start();
  const [myCase] = await fetchCases({
    externalId: external_id,
    sfId: sfid
  });
  await refetchTimer.stop();

  return myCase;
};
