const { fetchCases } = require('../../../common/fetchCases');

module.exports = async (root, { external_id__c, sfid }, context) => {
  const [myCase] = await fetchCases({
    externalId: external_id__c,
    sfId: sfid
  });
  return myCase;
};
