const { herokuConnectClient } = require('../../../services/knex');
const {
  batchInsertSFObject
} = require('../../../services/salesforce');
const { fetchCases } = require('../../../common/fetchCases');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');
const { 
  getAllCaseUsages, 
  deleteCasesUsageProducts, 
  getCUDeleteDataOnConditions, 
  getCUFilteredDataOnConditions, 
  updateCaseUsages 
} = require('../common/caseUsages');

module.exports = async(
    _root, 
    {
        case_sfid,
        case_external_id,
        parts,
        hospital_printed_name,
        sales_rep,
        status
    }, 
    context) => {
        if (!case_sfid && !case_external_id) {
            return null;
        }
        const currentUser = await context.currentUser(true);
        
        let casePayload = {
            status__c: status,
            changedby__c: `${currentUser.first_name} ${currentUser.last_name}`,
            hospital_printed_name__c: hospital_printed_name,
            rep_printed_name__c: sales_rep
        };

        if (status == 'Completed') {
            casePayload.submitusage__c = true;
            casePayload.submit_usage_datetime__c = new Date();
            casePayload.order_created_status__c = 'Not submitted ';
        }

        const modifiedCaseUsages = async () => {
            const allDbCaseUsages = await getAllCaseUsages(
              case_external_id,
              case_sfid
            );
        
            let updatedCaseUsagesElements = [],
              insertedCaseUsagesElements = [];
            // Front end was on parts tabl so only updating parts
            const caseUsageParts = getCUFilteredDataOnConditions(
                parts,
                allDbCaseUsages
            );
    
            updatedCaseUsagesElements = caseUsageParts.updateElements;
            insertedCaseUsagesElements = caseUsageParts.insertElements;
        
            const deletedCaseUsagesElements = getCUDeleteDataOnConditions(
              parts,
              allDbCaseUsages
            );
            return { 
                updateElements: updatedCaseUsagesElements, 
                insertElements: insertedCaseUsagesElements, 
                deletedElements: deletedCaseUsagesElements };
          };

          const modifiedCaseUsageResults = await modifiedCaseUsages();
          const {
            updateElements,
            insertElements,
            deletedElements
          } = modifiedCaseUsageResults;

          return await herokuConnectClient
            .transaction(async trx => {
                const ops = [];
                try {
                    // Delete all currently associated casesusage__c rows to the external_id__c
                    if (deletedElements.length > 0) {
                        ops.push(deleteCasesUsageProducts(deletedElements, trx));
                    }

                    // Insert case usages
                    if (insertElements.length > 0) {
                        ops.push(
                            batchInsertSFObject('salesforce.casesusage__c', insertElements, trx)
                        );
                    }

                    // Update case usages
                    if (updateElements.length > 0) {
                        const caseUsages = updateElements.map(product => {
                            return updateCaseUsages(product, trx);
                        });

                        ops.push(Promise.all(caseUsages));
                    }

                    const caseUpdate = herokuConnectClient('cases__c')
                        .withSchema('salesforce')
                        .update({
                            ...casePayload
                        })
                        .transacting(trx);

                    if (case_external_id) {
                        caseUpdate.where(
                            'external_id__c',
                            '=',
                            case_external_id
                        );
                    } else if (case_sfid) {
                        caseUpdate.where('sfid', '=', case_sfid);
                    }

                    await Promise.all(ops);
                    await caseUpdate;
                    await trx.commit;
                } catch (error) {
                    await trx.rollback;
                    throw error;
                }
            }).then(async() => {
                // updating history tracking
                caseActionTracker(
                    currentUser,
                    casePayload['status__c'] === 'Completed'
                        ? CASE_ACTION_TRACKER.USAGE_SUBMITTED
                        : CASE_ACTION_TRACKER.USAGE_UPDATED,
                    case_sfid,
                    case_external_id
                );
                const [myCase] = await fetchCases({
                    externalId: case_external_id,
                    sfId: case_sfid
                });
                return myCase;
            });
}