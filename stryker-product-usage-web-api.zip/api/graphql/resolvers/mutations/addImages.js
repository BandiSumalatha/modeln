const { batchUpsertSFObject } = require('../../../services/salesforce');
const { createUploadImageJob } = require('../../../services/cloudAMQP');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');
const herokuConnectClient = require('../../../services/knex').herokuConnectClient;
const { fetchCases } = require('../../../common/fetchCases');

module.exports = async(
    _root, {
        surgical_cases__r__external_id__c,
        surgical_cases__c,
        images,
        po_uploaded__c
    },
    context) => {
        const currentUser = await context.currentUser(true);
        let processedImages = images.map(image => {
            let {...processedImage} = image;
            processedImage.created_at = new Date();
            processedImage.updated_at = new Date();
            delete processedImage.isNew;
            return processedImage;
        });
        
        await batchUpsertSFObject(
            'salesforce.case_images',
            processedImages,
            'azure_image_url',
            `"case_images"."attachment_id" is null`
        );
  
        await createUploadImageJob(
            surgical_cases__r__external_id__c,
            surgical_cases__c,
            images.map(image => image.azure_image_url)
        );

        if (po_uploaded__c && (surgical_cases__c || surgical_cases__r__external_id__c)) {
            let query = herokuConnectClient('cases__c')
                .withSchema('salesforce');
            if (surgical_cases__c && surgical_cases__r__external_id__c) {
                query = query
                    .where('sfid', surgical_cases__c)
                    .orWhere('external_id__c', surgical_cases__r__external_id__c);
            }
            else if (surgical_cases__c) {
                query = query.where('sfid', surgical_cases__c)
            }
            else {
                query = query.where('external_id__c', surgical_cases__r__external_id__c);
            }
            await query.update({
                po_uploaded__c
            });
        }
        
        caseActionTracker(
            currentUser,
            CASE_ACTION_TRACKER.USAGE_UPDATED,
            surgical_cases__c,
            surgical_cases__r__external_id__c
          );

        const [myCase] = await fetchCases({
            externalId: surgical_cases__r__external_id__c,
            sfId: surgical_cases__c
        });

        return myCase;
    }