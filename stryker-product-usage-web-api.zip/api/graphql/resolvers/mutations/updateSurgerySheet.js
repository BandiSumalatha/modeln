const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');
const { herokuConnectClient } = require('../../../services/knex');
const { fetchCases } = require('../../../common/fetchCases');

module.exports = async (_root, {
  case_sfid,
  case_external_id,
  internal_comments,
  external_comments,
  hospital_printed_name,
  sales_rep,
  status
}, context) => {
  if (!case_sfid && !case_external_id) {
    throw new Error('You must provide either case_sfid or case_external_id');
  }

  const currentUser = await context.currentUser(true);

  let casePayload = {
    case_coverage__c: internal_comments,
    external_comments__c: external_comments,
    hospital_printed_name__c: hospital_printed_name,
    rep_printed_name__c: sales_rep,
    status__c: status,
    changedby__c: `${currentUser.first_name} ${currentUser.last_name}`
  }

  if (status === 'Completed') {
    casePayload.submitusage__c = true;
    casePayload.submit_usage_datetime__c = new Date();
    casePayload.order_created_status__c = 'Not submitted ';

    let tprPayload = { status__c: 'Completed' }

    let tprUpdate = herokuConnectClient('treatment_plan_request__c')
      .withSchema('salesforce')
      .update(tprPayload)
      .whereRaw(` treatment_plan_request__c.status__c = 'Shipped To Sales' AND surgical_case_details__c  in (select  surgical_case_products__c.sfid FROM
            surgical_case_products__c INNER JOIN cases__c ON surgical_case_products__c.surgical_case__c = cases__c.sfid
            WHERE surgical_case_products__c.treatment_plan_request__c IS NOT NULL AND cases__c.as1__c = true
            AND ( surgical_case_products__c.surgical_case__c = '${case_sfid}'
            OR surgical_case_products__c.surgical_case__r__external_id__c = '${case_external_id}' ) )`);

    await tprUpdate;
  }

  const caseUpdate = herokuConnectClient('cases__c')
    .withSchema('salesforce')
    .update(casePayload);

  if (case_external_id) {
    caseUpdate.where(
      'external_id__c',
      '=',
      case_external_id
    );
  } else if (case_sfid) {
    caseUpdate.where('sfid', '=', case_sfid);
  }
  await caseUpdate;

  // updating history tracking
  caseActionTracker(
    currentUser,
    status === 'Completed'
      ? CASE_ACTION_TRACKER.USAGE_SUBMITTED
      : CASE_ACTION_TRACKER.USAGE_UPDATED,
    case_sfid,
    case_external_id
  );

  const [myCase] = await fetchCases({
    externalId: case_external_id,
    sfId: case_sfid
  });
  return myCase;
}