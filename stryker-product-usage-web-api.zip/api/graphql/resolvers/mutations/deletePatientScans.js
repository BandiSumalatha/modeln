const herokuConnectClient = require("../../../services/knex").herokuConnectClient;
const { getScansForTPR } = require("../../../common/fetchCases");
const Promise = require('bluebird');

module.exports = async (root, { scans, tpr_sfid, tpr_external_id__c }, context) => {
  console.log("inside deletePateintscan..");
  let activeFlag = 0;
  let scanSfidList = [];
  let scanExtIdList = [];
  for (const payload of scans) {
    const { scan_sfid, scan_external_id__c } = payload;
    if (scan_sfid) {
      scanSfidList.push(scan_sfid);
    }
    if (scan_external_id__c) {
      scanExtIdList.push(scan_external_id__c);
    }
  }

  if (scanSfidList.length > 0 || scanExtIdList.length > 0) {
    let toBeDeletedScans = await herokuConnectClient
      .withSchema("salesforce")
      .select(["scan.is_active__c as active"])
      .from("patient_scan__c AS scan")
      .where(function() {
        this.whereIn("sfid", scanSfidList);
        this.orWhereIn("external_id__c", scanExtIdList);
      });
    for (let activeCheck of toBeDeletedScans) {
      let { active } = activeCheck;

      if (active === true) {
        activeFlag = 1;
        break;
      }
    }

    return await herokuConnectClient.transaction(function (trx) {
        return herokuConnectClient("patient_scan__c")
          .withSchema("salesforce")
          .where(function() {
            this.whereIn("sfid", scanSfidList);
            this.orWhereIn("external_id__c", scanExtIdList);
          })
          .del()
          .transacting(trx)
          .then(function() {
            if (activeFlag === 1) {
              let query = herokuConnectClient
                .withSchema("salesforce")
                .select("scan.patientscanid__c as scan_rhs_id", "scan.sfid as scan_sfid", "scan.external_id__c as scan_external_id__c")
                .from("patient_scan__c AS scan")
                .orderBy("scan.createddate", "desc")
                .transacting(trx)
                .limit(1);
              
              if (tpr_sfid && tpr_external_id__c) {
                query = query
                  .where("scan.tpr_id__c", tpr_sfid)
                  .orWhere("scan.tpr_id__r_external_id__c", tpr_external_id__c);
                return query;
              }
              else if (tpr_sfid) {
                query = query
                  .where("scan.tpr_id__c", tpr_sfid);
                return query;
              }
              else if (tpr_external_id__c) {
                query = query
                  .where("scan.tpr_id__r_external_id__c", tpr_external_id__c);
                return query;
              }
              else {
                return Promise.resolve([]);
              }
            }
            return Promise.resolve(null)
          })
          .then(function(presentScans) {
            let newActiveScan = {};
            let activeScan = null;
            let scanSfid;
            let scanExternalId;
            const promises = [];
            if (presentScans) {
              // set default in case presentScans is an empty array
              newActiveScan = { patient_scan_id__c: null };
              for (let scanIdData of presentScans) {
                const { scan_rhs_id, scan_sfid, scan_external_id__c } = scanIdData;
                scanSfid = scan_sfid;
                scanExternalId = scan_external_id__c;
                newActiveScan = { patient_scan_id__c: scan_rhs_id };
                activeScan = { is_active__c: true };
              }

              let activeScanUpdateTPR = herokuConnectClient("treatment_plan_request__c")
                .withSchema("salesforce")
                .transacting(trx)
                .update(newActiveScan);

              if (tpr_sfid && tpr_external_id__c) {
                activeScanUpdateTPR = activeScanUpdateTPR
                  .where("sfid", tpr_sfid)
                  .orWhere("external_id__c", tpr_external_id__c);
                promises.push(activeScanUpdateTPR);
              }
              else if (tpr_sfid) {
                activeScanUpdateTPR = activeScanUpdateTPR
                  .where("sfid", tpr_sfid);
                promises.push(activeScanUpdateTPR);
              }
              else if (tpr_external_id__c) {
                activeScanUpdateTPR = activeScanUpdateTPR
                  .where("external_id__c", tpr_external_id__c);
                promises.push(activeScanUpdateTPR);
              }
            }

            if (activeScan) {
              let activeScanUpdateScan = herokuConnectClient("patient_scan__c")
                .withSchema("salesforce")
                .transacting(trx)
                .update(activeScan);

              if (scanSfid) {
                activeScanUpdateScan = activeScanUpdateScan
                  .where("sfid", scanSfid);
                promises.push(activeScanUpdateScan);
              }
              else if (scanExternalId) {
                activeScanUpdateScan = activeScanUpdateScan
                  .where("external_id__c", scanExternalId);
                promises.push(activeScanUpdateScan);
              }              
            }

            return Promise.all(promises);
          })
          .then(trx.commit)
          .catch(trx.rollback);
    })
    .then(function() {
      if (tpr_sfid || tpr_external_id__c) {
        return getScansForTPR({ tprSfid: tpr_sfid, tprExternalId: tpr_external_id__c });
      }
      return Promise.resolve([]);
    });
  }
  else {
    if (tpr_sfid || tpr_external_id__c) {
      return await getScansForTPR({ tprSfid: tpr_sfid, tprExternalId: tpr_external_id__c });
    }
    return [];
  }
};
