const mockingoose = require('mockingoose').default;
jest.mock('../../../services/salesforce', () => {
  let findUserMock = jest.fn();
  findUserMock.mockReturnValue({ email: 'some@test.org', sfids: [] });
  return {
    findUser: findUserMock,
    upsertSFObject: jest.fn(),
    batchUpsertSFObject: jest.fn()
  };
});

jest.mock('../../../services/knex', () => {
  const knex = require('knex');
  const mockDb = require('mock-knex');
  let tracker = mockDb.getTracker();
  tracker.install();
  tracker.on('query', query => {
    query.response([]);
  });
  const db = knex({
    useNullAsDefault: true,
    client: 'sqlite'
  });
  mockDb.mock(db);
  return {
    herokuConnectClient: db
  };
});

jest.mock('../../../common/fetchCases', () => {
  let fetchCases = jest.fn();
  fetchCases.mockReturnValue([{}]);
  return { fetchCases };
});

const createOrUpdateCase = require('./createOrUpdateCase');
describe('createOrUpdateCase mutation', () => {
  it('should return response and case id for a given payload', async () => {
    const args = {
      payload: {
        branchid__c: 'a5oW0000000HpQ8IAK',
        cap_price__c: false,
        case_coverage__c: 'undefined',
        covering_reps__c:
          '0053100000870qnAAA,005W00000039UbhIAE,005W0000003PxVkIAK',
        delivery_options__c: null,
        division__c: 'Spine',
        hospital_staffid__c: '003W000000qHsHTIA0',
        hospitalid__c: '001W000000gucB6IAI',
        kit_assigner__c: '005W00000039Ta9IAE',
        kitdelivery_date__c: '05/29/2018',
        patient_info__c: 'P-110',
        procedureid__c: 'a61W00000005bgoIAA,a61W00000005bWeIAI',
        ship_to__c: 'Home',
        surgery_date_time: '1527618600000'
      }
    };

    let result = await createOrUpdateCase({}, args, {
      headers: { authorization: 'Bearer test' }
    });
    // TODO: Create assertions here
  });

  it('should return error', async () => {
    const args = {
      payload: {
        branchid__c: 'a5oW0000000HpQ8IAK',
        cap_price__c: false,
        case_coverage__c: 'undefined',
        covering_reps__c:
          '0053100000870qnAAA,005W00000039UbhIAE,005W0000003PxVkIAK',
        delivery_options__c: null,
        division__c: 'Spine',
        hospital_staffid__c: '003W000000qHsHTIA0',
        hospitalid__c: '001W000000gucB6IAI',
        kit_assigner__c: '005W00000039Ta9IAE',
        kitdelivery_date__c: '05/29/2018',
        patient_info__c: 'P-110',
        procedureid__c: 'a61W00000005bgoIAA,a61W00000005bWeIAI',
        ship_to__c: 'Home',
        surgery_date_time: '1527618600000'
      }
    };
    const result = await createOrUpdateCase({}, args, {
      headers: { authorization: 'Bearer test' }
    });
    // TODO: Create assertion here
  });
});
