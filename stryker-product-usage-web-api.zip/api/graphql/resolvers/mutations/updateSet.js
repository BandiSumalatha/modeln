const { herokuConnectClient } = require('../../../services/knex');
module.exports = async (root, { sets }, context) => {
  await herokuConnectClient.transaction(async trx => {
    try {
      const updateSets = sets.map(set => {
        let payload = {
          status__c: set.status__c
        };
        if (
          set.inventory_type === 'Hospital' &&
          (set.status__c === 'Available' || set.status__c === 'Pending Restock')
        ) {
          payload.surgical_cases__c = '';
        }

        return herokuConnectClient('inventory_product_system__c')
          .withSchema('salesforce')
          .transacting(trx)
          .where('sfid', '=', set.set_id)
          .update(payload);
      });
      // Update sets
      await Promise.all(updateSets);
      trx.commit;
    } catch (error) {
      trx.rollback;
      throw error;
    }
  });

  return true;
};
