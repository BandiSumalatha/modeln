const { herokuConnectClient } = require('../../../services/knex');
const {
  batchInsertSFObject,
  batchUpsertSFObject
} = require('../../../services/salesforce');
const { fetchCases } = require('../../../common/fetchCases');
const {
  createUploadImageJob,
  createDeleteImageJob
} = require('./../../../services/cloudAMQP');
const { getDeleteData, getCUFilteredData } = require('../../../utils');
const caseActionTracker = require('../../../common/caseActionTracker');
const { CASE_ACTION_TRACKER } = require('../../../constants');
const {
  getAllCaseUsages,
  deleteCasesUsageProducts,
  getCUDeleteDataOnConditions,
  getCUFilteredDataOnConditions,
  updateCaseUsages
} = require('../common/caseUsages');
const { Timer, defaultTimeout } = require('../../../services/timer');

const caseUsagesUpdateKeys = [
  { matchingApp: 'quantity__c', matchingDb: 'quantity__c' },
  { matchingApp: 'lot_number__c', matchingDb: 'lot_number__c' },
  { matchingApp: 'wasteds__c', matchingDb: 'wasteds__c' },
  { matchingApp: 'side__c', matchingDb: 'side__c' },
  { matchingApp: 'usg_price__c', matchingDb: 'usg_price__c' },
  { matchingApp: 'used_from__c', matchingDb: 'used_from__c' },
  { matchingApp: 'lot_controlled__c', matchingDb: 'lot_controlled__c' },
  { matchingApp: 'ship_to__c', matchingDb: 'ship_to__c' },
  { matchingApp: 'shipto_location__c', matchingDb: 'shipto_location__c' },
  { matchingApp: 'replenish__c', matchingDb: 'replenish__c' },
  { matchingApp: 'procedure__c', matchingDb: 'procedure__c' },
  { matchingApp: 'price_override__c', matchingDb: 'price_override__c' },
  {
    matchingApp: 'inventory_product_system__c',
    matchingDb: 'inventory_product_system__c'
  },
  { matchingApp: 'override_price__c', matchingDb: 'override_price__c' },
  {
    matchingApp: 'usg_total_amount__c',
    matchingDb: 'usg_total_amount__c'
  },
  {
    matchingApp: 'contract__c',
    matchingDb: 'contract__c'
  },
  {
    matchingApp: 'csr_contract__c',
    matchingDb: 'csr_contract__c'
  },
  {
    matchingApp: 'csr_usage_price__c',
    matchingDb: 'csr_usage_price__c'
  },
  {
    matchingApp: 'csr_price_override__c',
    matchingDb: 'csr_price_override__c'
  },
  {
    matchingApp: 'expiry_date__c',
    matchingDb: 'expiry_date__c'
  },
  {
    matchingApp: 'serial_number__c',
    matchingDb: 'serial_number__c'
  },
  {
    matchingApp: 'unit_number__c',
    matchingDb: 'unit_number__c'
  }
];

const additionalFeeUpdateKeys = [
  { matchingApp: 'name', matchingDb: 'name' },
  { matchingApp: 'value__c', matchingDb: 'value__c' }
];
module.exports = async (
  _root,
  {
    surgical_cases__r__external_id__c,
    surgical_cases__c,
    parts,
    surgeryCaseProcedures,
    additionalFees,
    caseDetail,
    images,
    mode
  },
  context
) => {
  if (!surgical_cases__r__external_id__c && !surgical_cases__c) {
    return null;
  }
  const currentUser = await context.currentUser(true);
  const {
    patient_info__c,
    status__c,
    submitusage__c,
    order_created_status__c,
    hospital_printed_name__c,
    rep_printed_name__c,
    external_comments__c,
    case_coverage__c,
    signature_source__c,
    po_uploaded__c,
    urgentreplenish__c,
    adapt: adapt__c
  } = caseDetail;

  const casePayload =
    status__c !== 'Completed'
      ? {
        patient_info__c,
        status__c,
        hospital_printed_name__c,
        rep_printed_name__c,
        external_comments__c,
        case_coverage__c,
        signature_source__c,
        po_uploaded__c,
        urgentreplenish__c,
        adapt__c,
        changedby__c: `${currentUser.first_name} ${currentUser.last_name}`
      }
      : {
        patient_info__c,
        status__c,
        submitusage__c,
        submit_usage_datetime__c: new Date(),
        order_created_status__c,
        hospital_printed_name__c,
        rep_printed_name__c,
        external_comments__c,
        case_coverage__c,
        signature_source__c,
        po_uploaded__c,
        urgentreplenish__c,
        adapt__c,
        changedby__c: `${currentUser.first_name} ${currentUser.last_name}`
      };

  const modifiedCaseUsages = async () => {
    if (mode === 1) {
      return {
        updateElements: [],
        insertElements: [],
        deletedCaseUsagesElements: []
      };
    }

    const existingUsageTimer = new Timer('setCasesUsage.existing', defaultTimeout);
    await existingUsageTimer.start();
    const allDbCaseUsages = await getAllCaseUsages(
      surgical_cases__r__external_id__c,
      surgical_cases__c
    );
    await existingUsageTimer.stop();

    let updateElements = [],
      insertElements = [];
    // Front end was on parts tabl so only updating parts
    if (mode === 0) {
      const caseUsageParts = getCUFilteredDataOnConditions(
        parts,
        allDbCaseUsages
      );

      updateElements = caseUsageParts.updateElements;
      insertElements = caseUsageParts.insertElements;
      if (caseUsageParts.insertElements) for (const insertElement of caseUsageParts.insertElements) {
        insertElement.wasteds__c = !!insertElement.wasteds__c;
      }
      if (caseUsageParts.updateElements) for (const updateElement of caseUsageParts.updateElements) {
        if (updateElement.wasteds__c == null) updateElement.wasteds__c = false;
        if (updateElement.override_price__c == null) updateElement.override_price__c = false;
        if (updateElement.lot_number__c == '') updateElement.lot_number__c = null;
      }
    }

    console.log('surgeryCaseProcedures', surgeryCaseProcedures);
    if (surgeryCaseProcedures) for (const caseProcedure of surgeryCaseProcedures) {
      console.log('caseProcedure', caseProcedure);
      if (updateElements) for (const element of updateElements) {
        element.procedure__c = caseProcedure.procedureid__c;
        console.log('element', element);
      }
      if (insertElements) for (const element of insertElements) {
        element.procedure__c = caseProcedure.procedureid__c;
      }
    }

    // mode = 0(PARTS tab on front end) || mode = 2(SURGERY SHEET tab on front end)

    const deletedCaseUsagesElements = getCUDeleteDataOnConditions(
      parts,
      allDbCaseUsages
    );
    return { updateElements, insertElements, deletedCaseUsagesElements };
  };

  const modifiedAdditionalFees = async () => {
    if (mode === 1) {
      return {
        insertAdditionalFees: [],
        updateAdditionalFees: [],
        deletedAdditionalFees: []
      };
    }
    // Additional fees
    const existingFeesTimer = new Timer('setCasesUsage.existingAdditionalFees', defaultTimeout);
    await existingFeesTimer.start();
    const getAllSurgeryFees = await getAllAdditionalSurgeryFees(
      surgical_cases__r__external_id__c,
      surgical_cases__c
    );
    await existingFeesTimer.stop();

    let insertAdditionalFees = [],
      updateAdditionalFees = [];

    if (mode === 1) {
      const cuAdditionalFeesElements = getCUFilteredData(
        additionalFees,
        getAllSurgeryFees,
        'name',
        'name',
        additionalFeeUpdateKeys
      );

      insertAdditionalFees = cuAdditionalFeesElements.insertElements;
      updateAdditionalFees = cuAdditionalFeesElements.updateElements;
    }

    const deletedAdditionalFees = getDeleteData(
      additionalFees,
      getAllSurgeryFees,
      'name',
      'name'
    );

    return {
      insertAdditionalFees,
      updateAdditionalFees,
      deletedAdditionalFees
    };
  };

  const [
    modifiedCaseUsageResults,
    modifiedAdditionalFeesResults
  ] = await Promise.all([modifiedCaseUsages(), modifiedAdditionalFees()]);
  const {
    updateElements,
    insertElements,
    deletedCaseUsagesElements
  } = modifiedCaseUsageResults;
  const {
    insertAdditionalFees,
    updateAdditionalFees,
    deletedAdditionalFees
  } = modifiedAdditionalFeesResults;

  return await herokuConnectClient
    .transaction(async trx => {
      let ops = [];
      try {
        // Delete all currently associated casesusage__c rows to the external_id__c
        if (deletedCaseUsagesElements.length > 0)
          ops.push({type: "D", operations: deleteCasesUsageProducts(deletedCaseUsagesElements, trx)});

        // Insert case usages
        if (insertElements.length > 0) {
          ops.push({
            type: "I",
            operations: batchInsertSFObject('salesforce.casesusage__c', insertElements, trx)
          });
        }

        // Update case usages
        if (updateElements.length > 0) {
          const caseUsages = updateElements.map(product => {
            return updateCaseUsages(product, trx);
          });

          ops.push({
            type: "U",
            operations: Promise.all(caseUsages)
          });
        }

        // Delete all currently associated additional_surgery_fee__c rows to the external_id__c
        if (deletedAdditionalFees.length > 0)
          ops.push({
            type: "D",
            operations: deleteAdditionalSurgeryFees(deletedAdditionalFees, trx)
          });

        //Insert additional_surgery_fee__c
        if (insertAdditionalFees.length > 0)
          ops.push({
            type: "I",
            operations: batchInsertSFObject(
              'salesforce.additional_surgery_fee__c',
              insertAdditionalFees,
              trx
            )
          });

        // Update case Additional Fees
        if (updateAdditionalFees.length > 0) {
          const caseAddFees = updateAdditionalFees.map(fee => {
            return updateAdditionalSurgeryFee(fee, trx);
          });

          ops.push({
            type: "U",
            operations: Promise.all(caseAddFees)
          });
        }

        // Update Cases__c' object
        const caseUpdate = herokuConnectClient('cases__c')
          .withSchema('salesforce')
          .update({
            ...casePayload
          })
          .transacting(trx);

        if (surgical_cases__r__external_id__c) {
          caseUpdate.where(
            'external_id__c',
            '=',
            surgical_cases__r__external_id__c
          );
        } else if (surgical_cases__c) {
          caseUpdate.where('sfid', '=', surgical_cases__c);
        }

        const usageUpdateTimer = new Timer('setCasesUsage.usageUpdate', defaultTimeout);
        await usageUpdateTimer.start();
        
        // sort operations by action (insert, update, delete)
        ops = ops.sort((a, b) => {
          if (a.type === b.type) return 0;
          if (a.type === 'U') return -1;
          if (a.type === 'D') return 1;
          if (a.type === 'I' && b.type === 'D') return -1;
          if (a.type === 'I' && b.type === 'U') return 1;
          return 0;
        });

        if (ops) for(const op in ops) {
          if (op.operations) {
            await Promise.all(op.operations);
          }
        }

        await usageUpdateTimer.stop();

        const caseUpdateTimer = new Timer('setCasesUsage.caseUpdate', defaultTimeout);
        await caseUpdateTimer.start();
        await caseUpdate;
        await caseUpdateTimer.stop();

        await trx.commit;
      } catch (error) {
        await trx.rollback;
        throw error;
      }
    })
    .then(async () => {
      if (mode === 2 || mode === 3) {
        images = images.map(image => {
          image.created_at = new Date();
          image.updated_at = new Date();
          return image;
        });

        const shouldDeleteSignatures =
          mode === 3 && images.some(image => image.signature_by);
        let imageIds = images.map(x => x.azure_image_url);
        images = images.filter(image => image.isNew === true).map(image => {
          const { isNew, ...rest } = image;
          return rest;
        });

        // Empty the table salesforce.case_images
        const deleteImageTimer = new Timer('setCasesUsage.deleteImage', defaultTimeout);
        await deleteImageTimer.start();
        await createDeleteImageJob(
          surgical_cases__c,
          surgical_cases__r__external_id__c,
          shouldDeleteSignatures,
          imageIds,
          []
        );
        await deleteImageTimer.stop();

        const deleteCasesUsageImagesTimer = new Timer('setCasesUsage.deleteCasesUsage', defaultTimeout);
        await deleteCasesUsageImagesTimer.start();
        await deleteCasesUsageImages(
          surgical_cases__c,
          surgical_cases__r__external_id__c,
          shouldDeleteSignatures,
          imageIds
        );
        await deleteCasesUsageImagesTimer.stop();

        if (!shouldDeleteSignatures) {
          images = images.filter(image => !image.signature_by);
        }

        const insertImagesTimer = new Timer('setCasesUsage.insertImages', defaultTimeout);
        await insertImagesTimer.start();
        await batchUpsertSFObject(
          'salesforce.case_images',
          images,
          'azure_image_url',
          `"case_images"."attachment_id" is null`
        );
        await insertImagesTimer.stop();

        const uploadImageTimer = new Timer('setCasesUsage.uploadImage', defaultTimeout);
        await uploadImageTimer.start();
        await createUploadImageJob(
          surgical_cases__r__external_id__c,
          surgical_cases__c,
          images.map(image => image.azure_image_url)
        );
        await uploadImageTimer.stop();
      }
      
      // updating history tracking
      const trackingTimer = new Timer('setCasesUsage.tracking', defaultTimeout);
      await trackingTimer.start();
      caseActionTracker(
        currentUser,
        casePayload['status__c'] === 'Completed'
          ? CASE_ACTION_TRACKER.USAGE_SUBMITTED
          : CASE_ACTION_TRACKER.USAGE_UPDATED,
        surgical_cases__c,
        surgical_cases__r__external_id__c
      );
      await trackingTimer.stop();

      //This is to update tpr as completed once AS1 case is completed
      if (casePayload['status__c'] === 'Completed') {
        let tprPayload = { status__c: 'Completed' }

        const tprUpdateTimer = new Timer('setCasesUsage.tprUpdate', defaultTimeout);
        await tprUpdateTimer.start();
        let tprUpdate = herokuConnectClient('treatment_plan_request__c')
          .withSchema('salesforce')
          .update(tprPayload)
          .whereRaw(` treatment_plan_request__c.status__c = 'Shipped To Sales' AND surgical_case_details__c  in (select  surgical_case_products__c.sfid FROM
                surgical_case_products__c INNER JOIN cases__c ON surgical_case_products__c.surgical_case__c = cases__c.sfid
                WHERE surgical_case_products__c.treatment_plan_request__c IS NOT NULL AND cases__c.as1__c = true
                AND ( surgical_case_products__c.surgical_case__c = '${surgical_cases__c}'
                OR surgical_case_products__c.surgical_case__r__external_id__c = '${surgical_cases__r__external_id__c}' ) )`);

        await tprUpdate;
        await tprUpdateTimer.stop();
      }

      const refetchTimer = new Timer('setCasesUsage.fetch', defaultTimeout);
      await refetchTimer.start();
      const [myCase] = await fetchCases({
        externalId: surgical_cases__r__external_id__c,
        sfId: surgical_cases__c
      });
      await refetchTimer.stop();
      return myCase;
    });
};

async function deleteCasesUsageImages(
  surgical_cases__c,
  surgical_case__r__external_id__c,
  shouldDeleteSignatures,
  imageIds
  // trx
) {
  const query = herokuConnectClient('case_images').withSchema('salesforce'); //.transacting(trx); //TODO not working correctly with transaction
  if (surgical_case__r__external_id__c) {
    query.where({ case_external_id: surgical_case__r__external_id__c });
  } else if (surgical_cases__c) {
    query.where({ case_sfid: surgical_cases__c });
  } else {
    return;
  }
  if (!shouldDeleteSignatures) {
    query.whereNull('signature_by');
  }
  if (imageIds.length > 0) {
    query.whereNotIn('case_images.azure_image_url', imageIds);
  }
  await query.del();
}

async function getAllAdditionalSurgeryFees(case_external_id, surgical_case) {
  if (!case_external_id && !surgical_case) {
    return [];
  }
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select('name', 'value__c', 'sfid', 'external_id__c')
    .from('additional_surgery_fee__c');
  if (case_external_id) {
    query.where({ surgical_case__r__external_id__c: case_external_id });
  } else {
    query.where({ surgical_case__c: surgical_case });
  }
  return query;
}

async function deleteAdditionalSurgeryFees(fees, trx) {
  const sfids = [],
    externalIds = [];
  if (fees) for (const fee of fees) {
    if (fee.sfid) {
      sfids.push(fee.sfid);
    } else if (fee.externalId) {
      externalIds.push(fee.externalId);
    }
  }

  return herokuConnectClient('additional_surgery_fee__c')
    .withSchema('salesforce')
    .transacting(trx)
    .where(function () {
      if (externalIds.length > 0 && sfids.length > 0) {
        this.whereIn('external_id__c', externalIds).orWhereIn('sfid', sfids);
      } else if (sfids.length > 0) {
        this.whereIn('sfid', sfids);
      } else {
        this.whereIn('external_id__c', externalIds);
      }
    })
    .del();
}
async function updateAdditionalSurgeryFee(record, trx) {
  if (record.external_id__c || record.sfid) {
    const feeUpdate = herokuConnectClient('additional_surgery_fee__c')
      .withSchema('salesforce')
      .update(record)
      .transacting(trx);

    if (record.external_id__c) {
      feeUpdate.where('external_id__c', '=', record.external_id__c);
    } else if (record.sfid) {
      feeUpdate.where('sfid', '=', record.sfid);
    }
    return feeUpdate;
  }
  return Promise.resolve();
}