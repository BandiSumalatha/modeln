const mockingoose = require('mockingoose').default;

jest.mock('../../../config', () => ({
  MONGODB: {}
}));

const createOrUpdateFilter = require('./createOrUpdateFilter');
describe('mutations -> createOrUpdateFilter', () => {
  it('should return response for a given payload', async () => {
    const args = {
      user_sfid: 'some-user-sfid',
      name: 'My Test Filter',
      definition: {
        isFavorite: true,
        status: 'Completed',
        branchId: 'some-branch-sfid'
      }
    };
    mockingoose.UserFilter.toReturn(args, 'findOneAndUpdate');
    const result = await createOrUpdateFilter({}, args, {});
    let output = JSON.parse(JSON.stringify(result));
    expect(output).toBeTruthy();
    expect(output).toMatchObject(args);
  });
});
