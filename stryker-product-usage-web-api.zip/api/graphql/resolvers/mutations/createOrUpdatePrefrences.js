const {
  upsertSFObject,
  batchUpsertSFObject
} = require('../../../services/salesforce');
const herokuConnectClient = require('../../../services/knex')
  .herokuConnectClient;

const { findUserPreferences } = require('../common/preferences');
const {
  getInsertDataOnMultipleKey,
  getUpdatedDataOnMultipleKey,
  getDeleteDataOnMultipleKey,
  getUndefinedForBlank
} = require('../../../utils');
module.exports = resolver;
const checkUpdateKeys = [
  { matchingApp: 'ipsid__c', matchingDb: 'ipsid__c' },
  { matchingApp: 'product_system__c', matchingDb: 'product_system__c' },
  { matchingApp: 'productid__c', matchingDb: 'productid__c' },
  { matchingApp: 'isloaner__c', matchingDb: 'isloaner__c' }
];

async function resolver(
  root,
  { payload, external_id__c, sfid, filters },
  context
) {
  try {
    const { surgeon_perference, preference_details } = payload;
    const currentUser = await context.currentUser(true);
    await herokuConnectClient
      .transaction(async trx => {
        try {
          let identifier = 'external_id__c';
          if (sfid) {
            identifier = 'sfid';
            surgeon_perference.sfid = sfid;
          } else if (external_id__c) {
            identifier = 'external_id__c';
            surgeon_perference.external_id__c = external_id__c;
          }
          if (
            !external_id__c &&
            !sfid &&
            currentUser &&
            currentUser.sfids &&
            currentUser.sfids.length > 0
          )
            surgeon_perference.created_by_sales_rep__c = currentUser.sfids[0];

          surgeon_perference.lastmodifieddate = new Date();

          if (
            surgeon_perference.hospitalid__c &&
            currentUser &&
            currentUser.sfids &&
            currentUser.sfids.length > 0
            ) {
              const branchLookup = await herokuConnectClient('hospitals2_mv')
                .withSchema('repsuite')
                .where('hospitalid', surgeon_perference.hospitalid__c)
                .where('userid', currentUser.sfids[0])
                .select('subBranch', 'mainBranch');

              if (branchLookup && branchLookup.length > 0) {
                surgeon_perference.branchid__c = branchLookup[0].subBranch || branchLookup[0].mainBranch || surgeon_perference.branchid__c;
              }
            }

          const result = await upsertSFObject(
            'salesforce.surgeon_preference__c',
            surgeon_perference,
            identifier
          );
          if (result) {
            const externalId = result.external_id__c;
            const surgeon_preference__c = result.sfid;

            const allSps = await getAllSurgeonPreference(
              externalId,
              surgeon_preference__c
            );
            const insertElements = getInsertDataOnMultipleKey(
              preference_details,
              allSps,
              [
                { app: 'ipsid__c', db: 'ipsid__c' },
                { app: 'product_system__c', db: 'product_system__c' },
                { app: 'productid__c', db: 'productid__c' }
              ]
            );
            const deletedElements = getDeleteDataOnMultipleKey(
              preference_details,
              allSps,
              [
                { app: 'ipsid__c', db: 'ipsid__c' },
                { app: 'product_system__c', db: 'product_system__c' },
                { app: 'productid__c', db: 'productid__c' }
              ]
            );
            const updateElements = getUpdatedDataOnMultipleKey(
              preference_details,
              allSps,
              [
                { app: 'ipsid__c', db: 'ipsid__c' },
                { app: 'product_system__c', db: 'product_system__c' },
                { app: 'productid__c', db: 'productid__c' }
              ],
              checkUpdateKeys
            );
            // Delete all currently associated surgery_case_procedure__c rows to the external_id__c
            if (deletedElements.length > 0)
              await deleteSurgeonPreference(deletedElements);
            //Insert preference_detail__c
            if (insertElements.length > 0)
              await saveSurgeonPerferenceDetail(
                insertElements,
                externalId,
                surgeon_preference__c
              );

            //Update case preference
            if (updateElements.length > 0) {
              const sps = updateElements.map(preference => {
                const preferences = allSps
                  ? allSps.find(
                    item =>
                      getUndefinedForBlank(item.ipsid__c) ===
                      getUndefinedForBlank(preference.ipsid__c) &&
                      getUndefinedForBlank(item.product_system__c) ===
                      getUndefinedForBlank(preference.product_system__c) &&
                      getUndefinedForBlank(item.productid__c) ===
                      getUndefinedForBlank(preference.productid__c)
                  )
                  : null;
                return updateSurgeonPreference(preference, trx, preferences);
              });
              await Promise.all(sps);
            }
          }
          trx.commit;
        } catch (e) {
          console.log(`Error ${e}`);
          trx.rollback;
          throw e;
        }
      })
      .catch(error => {
        return error;
      });
    const preferences = await findUserPreferences(
      currentUser,
      filters,
      null
    );
    return preferences || [];
  } catch (err) {
    console.log('err: ', err);
  }
}

async function getAllSurgeonPreference(external_id, surgeon_preference) {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select()
    .from('preference_detail__c');

  if (external_id) {
    query.where('surgeon_preference__r__external_id__c', '=', external_id);
  } else if (surgeon_preference) {
    query.where('surgeon_preference__c', '=', surgeon_preference);
  }

  return query;
}
async function deleteSurgeonPreference(surgeonPreferences) {
  const sfids = surgeonPreferences
    .filter(preference => preference.sfid)
    .map(preference => preference.sfid);
  const externalIds = surgeonPreferences
    .filter(preference => preference.external_id__c)
    .map(preference => preference.external_id__c);
  return herokuConnectClient('preference_detail__c')
    .withSchema('salesforce')
    .where(function () {
      this.whereIn('external_id__c', externalIds).orWhereIn('sfid', sfids);
    })
    .del();
}

function updateSurgeonPreference(record, trx, preference) {
  if (preference.external_id__c || preference.sfid) {
    let preferenceUpdate = herokuConnectClient('preference_detail__c')
      .withSchema('salesforce')
      .update(record)
      .transacting(trx);

    if (preference.external_id__c) {
      preferenceUpdate.where('external_id__c', '=', preference.external_id__c);
    } else if (preference.sfid) {
      preferenceUpdate.where('sfid', '=', preference.sfid);
    }
    return preferenceUpdate;
  }
  return;
}

function saveSurgeonPerferenceDetail(
  preferenceDetails,
  surgeon_preference__r__external_id__c,
  surgeon_preference__c
) {
  const preferences = preferenceDetails.map(
    ({ ipsid__c, productid__c, product_system__c, isloaner__c }) => ({
      ipsid__c,
      productid__c,
      product_system__c,
      isloaner__c,
      surgeon_preference__r__external_id__c,
      surgeon_preference__c
    })
  );
  return batchUpsertSFObject(
    'salesforce.preference_detail__c',
    preferences,
    'id'
  );
}
