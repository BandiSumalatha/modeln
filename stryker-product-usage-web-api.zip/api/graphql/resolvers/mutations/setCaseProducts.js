const { herokuConnectClient } = require("../../../services/knex");
const { uniqBy } = require("lodash");
const {
  fetchCases
} = require("../../../common/fetchCases");
const Promise = require('bluebird');
const { getDeleteData, getCUFilteredData } = require("../../../utils");
const caseActionTracker = require("../../../common/caseActionTracker");
const { CASE_ACTION_TRACKER} = require("../../../constants");
const moment = require("moment");
const { Timer, defaultTimeout } = require('../../../services/timer');

module.exports = async (
  root,
  {
    case__c,
    external_id__c,
    sets,
    parts,
    is_hospital_owned__c,
    is_submit,
    case_current_status,
    branch
  },
  context
) => {
  if (!case__c && !external_id__c) {
    return;
  }
  const currentUser = await context.currentUser(true);
  let areSetsDeleted = false;
  let areSetsInserted = false;

  uniqBy(sets, "id");
  uniqBy(parts, "id");

  const filteredConsignments = [],
    filteredLoaners = [];
  for (const set of sets) {
    const setType = set.type;
    if (setType === "consignment") {
      filteredConsignments.push({ ...set, inactive__c: false });
    } else if (setType === "loaner") {
      filteredLoaners.push({ ...set, inactive__c: false });
    }
  }

  const existingProductsTimer = new Timer('setCaseProducts.existingProducts', defaultTimeout);
  await existingProductsTimer.start();
  const allSCPS = await getAllSurgicalCaseProducts(external_id__c, case__c);
  await existingProductsTimer.stop();

  const determineChangesTimer = new Timer('setCaseProducts.determineChanges', defaultTimeout);
  await determineChangesTimer.start();

  const allIPs = [],
    allPs = [],
    allParts = [];
  for (const scpsItem of allSCPS) {
    if (scpsItem.ips_id__c) {
      allIPs.push(scpsItem);
    } else if (!scpsItem.ips_id__c && scpsItem.product_system__c) {
      allPs.push(scpsItem);
    } else if (scpsItem.product__c) {
      allParts.push(scpsItem);
    }
  }

  const ipsSproductSystems = getCUFilteredData(
    filteredConsignments,
    allIPs,
    "id",
    "ips_id__c",
    [
      { matchingApp: "quantity", matchingDb: "quantity__c" },
      { matchingApp: "inactive__c", matchingDb: "inactive__c" }
    ]
  );

  const loanerCUElements = getCUFilteredData(
    filteredLoaners,
    allPs,
    "id",
    "product_system__c",
    [
      { matchingApp: "quantity", matchingDb: "quantity__c" },
      { matchingApp: "inactive__c", matchingDb: "inactive__c" }
    ]
  );

  const productSystemSets = {
    updateElements: loanerCUElements.updateElements,
    insertElements: loanerCUElements.insertElements,
    deletedElements: getDeleteData(
      filteredLoaners,
      allPs,
      "id",
      "product_system__c"
    ),
  };

  // checking whether sets are deleted, inserted
  areSetsInserted = productSystemSets.insertElements.length > 0;
  areSetsDeleted = productSystemSets.deletedElements.length > 0;

  parts = parts.map(part => { return {...part, inactive__c: false}});

  const caseCUElements = getCUFilteredData(
    parts,
    allParts,
    "product_sfid",
    "product__c",
    [
      { 
        matchingApp: "is_loaner", 
        matchingDb: "loaner__c" 
      },
      {
        matchingApp: "is_preference_product__c",
        matchingDb: "is_preference_product__c",
      },
      {
        matchingApp: "quantity",
        matchingDb: "quantity__c",
      },
      {
        matchingApp: "inactive__c", 
        matchingDb: "inactive__c"
      },
    ]
  );

  const caseParts = {
    updateElements: caseCUElements.updateElements,
    insertElements: caseCUElements.insertElements,
    deletedElements: getDeleteData(
      parts,
      allParts,
      "product_sfid",
      "product__c"
    ),
  };

  let deletedElements = [];

  deletedElements = [
    ...productSystemSets.deletedElements,
    ...caseParts.deletedElements,
  ];
  
  const isAllPartShipped = parts.filter(part => !part.is_loaner);

  const dbOperations = [];

  // Change the Status__c of Inventory_Product_System__c to Shipped for consignmentSets
  const ipsids = [];

  // Consignment Sets === real sets
  // Loaner and From Set Catalog are actually Set Categories (Product System)
  for (const consignmentSet of ipsSproductSystems.insertElements) {
    pushConsignmentSetToOpArray({
      consignmentSet,
      case__c,
      external_id__c,
      ipsids,
      dbOperations,
      isInsert: true,
    });
  }

  for (const consignmentSet of ipsSproductSystems.updateElements) {
    pushConsignmentSetToOpArray({
      consignmentSet,
      case__c,
      external_id__c,
      ipsids,
      dbOperations,
      isInsert: false,
    });
  }

  for (const productSystem of productSystemSets.insertElements) {
    pushProductSystemToOpArray({
      productSystem,
      case__c,
      external_id__c,
      dbOperations,
      isInsert: true,
    });
  }

  for (const productSystem of productSystemSets.updateElements) {
    pushProductSystemToOpArray({
      productSystem,
      case__c,
      external_id__c,
      dbOperations,
      isInsert: false,
    });
  }

  for (const part of caseParts.insertElements) {
    pushPartsToOpArray({
      part,
      case__c,
      external_id__c,
      dbOperations,
      isInsert: true,
    });
  }

  for (const part of caseParts.updateElements) {
    pushPartsToOpArray({
      part,
      case__c,
      external_id__c,
      dbOperations,
      isInsert: false,
    });
  }

  // We only flip to Shipped if only Consignment Sets were requested
  let caseStatus = "New";
  if (
    (filteredConsignments.length > 0 &&
      filteredLoaners.length === 0 &&
      isAllPartShipped.length === parts.length) ||
    (filteredConsignments.length === 0 &&
      filteredLoaners.length === 0 &&
      parts.length === 0 &&
      is_hospital_owned__c) ||
    (filteredConsignments.length === 0 &&
      filteredLoaners.length === 0 &&
      (parts.length > 0 && isAllPartShipped.length === parts.length))
  ) {
    caseStatus = "Shipped/Ready for Surgery";
  } else if (
    isAllPartShipped.length !== parts.length ||
    filteredLoaners.length > 0
  ) {
    caseStatus = "Requested";
  }

  const caseUpdatePayload = {
    is_hospital_owned__c,
  };

  if (branch) {
    caseUpdatePayload.region_filter__c = branch;
  }

  caseUpdatePayload.changedby__c = `${currentUser.first_name} ${
    currentUser.last_name
  }`;

  await determineChangesTimer.stop();

  const deleteProductsTimer = new Timer('setCaseProducts.deleteProducts', defaultTimeout);
  const changeProductsTimer = new Timer('setCaseProducts.changeProducts', defaultTimeout);
  const inventoryProductsTimer = new Timer('setCaseProducts.inventoryProductSystems', defaultTimeout);
  const setsCompleteTimer = new Timer('setCaseProducts.setsComplete', defaultTimeout);
  const queuedSetsTimer = new Timer('setCaseProducts.queuedSets', defaultTimeout);
  const refetchTimer = new Timer('setCaseProducts.refetch', defaultTimeout);

  return await herokuConnectClient.transaction(function(trx) {
    return Promise.all([])
      .then(changeProductsTimer.start.bind(changeProductsTimer))
      .then(function() {
        let promises = [];        
        for(const dbOperation of dbOperations) {
          if (!dbOperation.scps) {
            promises.push(upsertRecord(dbOperation.record, trx, dbOperation.scps));
          }
        }
        for(const dbOperation of dbOperations) {          
          if (dbOperation.scps) {
            promises.push(upsertRecord(dbOperation.record, trx, dbOperation.scps));
          }
        }
        return Promise.all(promises);
      })
      .then(changeProductsTimer.stop.bind(changeProductsTimer))
      .then(inventoryProductsTimer.start.bind(inventoryProductsTimer))
      .then(function() {
        return updatedInventoryProductSystem(
          trx,
          ipsids,
          case__c,
          external_id__c
        );
      })
      .then(inventoryProductsTimer.stop.bind(inventoryProductsTimer))        
      .then(deleteProductsTimer.start.bind(deleteProductsTimer))
      .then(function() {
        return deleteSurgicalCaseProducts(deletedElements, trx);
      })
      .then(deleteProductsTimer.stop.bind(deleteProductsTimer))
      .then(trx.commit)
      .catch(trx.rollback);
  })
  .then(function() {
    if (areSetsDeleted) {
      // updating history tracking
      return caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.SETS_REMOVED,
        case__c,
        external_id__c,
        null
      );
    }
    return Promise.resolve();
  })
  .then(setsCompleteTimer.start.bind(setsCompleteTimer))
  .then(function() {
    let payload = {
      ...caseUpdatePayload,
      is_set_complete__c: true,
    };
    if (is_submit || case_current_status !== "New") {
      payload.status__c = caseStatus;
    }

    const setsComplete = herokuConnectClient("cases__c")
      .withSchema("salesforce")
      .where(function() {
        this.where('is_set_complete__c', false).orWhereNull('is_set_complete__c');
      })
      .where(function() {
        this.where('lastmodifieddate', '<', moment().subtract(15, 'seconds')).orWhereNull('lastmodifieddate');
      })
      .update(payload, ['sfid', 'external_id__c']);

    if (external_id__c) {
      setsComplete.where("external_id__c", "=", external_id__c);
    } else if (case__c) {
      setsComplete.where("sfid", "=", case__c);
    }

    return setsComplete;
  })
  .then((updated) => {
    setsCompleteTimer.stop.bind(setsCompleteTimer);
    return updated;
  })
  .then(function() {
    // if the sets are inserted
    if (areSetsInserted) {
      // updating history tracking
      return caseActionTracker(
        currentUser,
        CASE_ACTION_TRACKER.SETS_REQUESTED,
        case__c,
        external_id__c
      );
    }
    return Promise.resolve();
  })
  .then((updated) => {
    queuedSetsTimer.start.bind(queuedSetsTimer);
    return updated;
  })
  .then(function(updated) {
    if (!updated || updated.length < 1) {
      let promises = [
        herokuConnectClient.raw(
          '? ON CONFLICT (id) DO NOTHING RETURNING *;',
          [
            herokuConnectClient("queued_sets")
              .withSchema("repsuite")
              .insert({
                id: case__c ? case__c : external_id__c,
                queued: `NOW()`
              })
          ]
        )
      ];

      let payload = {
        ...caseUpdatePayload                
      };
      if (is_submit || case_current_status !== "New") {
        payload.status__c = caseStatus;
      }
      
      let caseUpdate = herokuConnectClient("cases__c")
        .withSchema("salesforce")
        .update(payload);
      if (external_id__c) {
        caseUpdate = caseUpdate.where("external_id__c", "=", external_id__c);
      } else if (case__c) {
        caseUpdate = caseUpdate.where("sfid", "=", case__c);
      }

      promises.push(caseUpdate);

      return Promise.all(promises);
    }
  })
  .then(queuedSetsTimer.stop.bind(queuedSetsTimer))
  .then(refetchTimer.start.bind(refetchTimer))
  .then(function() {
    return fetchCases({
      externalId: external_id__c,
      sfId: case__c,
    });
  })
  .then((myCases) => {
    refetchTimer.stop.bind(refetchTimer);
    return myCases;
  })
  .then(function(myCases) {    
    return myCases && myCases.length > 0 ? myCases[0] : null;
  }).catch(function(err) {
    console.log(err);
    throw err;
  });
};

function pushPartsToOpArray({
  part,
  case__c,
  external_id__c,
  dbOperations,
  isInsert,
}) {
  let record = {
    // ipcid__c: part.id, // TODO: Need to verify if a user searches on inventory components
    // product__c is the only data element we know that is being used
    product__c: part.product_sfid,
    loaner__c: part.is_loaner,
    status__c: part.is_loaner ? "Requested" : "Shipped/Ready for Surgery",
    quantity__c: part.quantity,
    quantityval__c: part.quantity,
    is_preference_product__c: part.is_preference_product__c || false,
  };
  if (external_id__c) {
    record.surgical_case__r__external_id__c = external_id__c;
  } else if (case__c) {
    record.surgical_case__c = case__c;
  }
  dbOperations.push({
    record,
    scps: isInsert
      ? null
      : { external_id__c: part.external_id__c, sfid: part.sfid },
  });
}

function pushProductSystemToOpArray({
  productSystem,
  case__c,
  external_id__c,
  dbOperations,
  isInsert,
}) {
  let record = {
    product_system__c: productSystem.id,
    // in case of loaner it is always true
    loaner__c: true,
    status__c: productSystem.status__c || "Requested",
    quantity__c: productSystem.quantity,
    is_preference_product__c: productSystem.is_preference_product__c || false,
  };
  if (external_id__c) {
    record.surgical_case__r__external_id__c = external_id__c;
  } else if (case__c) {
    record.surgical_case__c = case__c;
  }
  dbOperations.push({
    record,
    scps: isInsert
      ? null
      : {
          external_id__c: productSystem.external_id__c,
          sfid: productSystem.sfid,
        },
  });
}

function pushConsignmentSetToOpArray({
  consignmentSet,
  case__c,
  external_id__c,
  ipsids,
  dbOperations,
  isInsert,
}) {
  const record = {
    ips_id__c: consignmentSet.id,
    // in case of consignments it is always false
    loaner__c: false,
    status__c: "Shipped/Ready for Surgery",
    quantity__c: consignmentSet.quantity,
    is_preference_product__c: consignmentSet.is_preference_product__c || false,
  };
  if (external_id__c) {
    record.surgical_case__r__external_id__c = external_id__c;
  } else if (case__c) {
    record.surgical_case__c = case__c;
  }
  ipsids.push(consignmentSet.id);
  dbOperations.push({
    record,
    scps: isInsert
      ? null
      : {
          external_id__c: consignmentSet.external_id__c,
          sfid: consignmentSet.sfid,
        },
  });
}

async function getAllSurgicalCaseProducts(case_external_id, surgical_case) {
  // belts and braces
  if (case_external_id === null && surgical_case === null) {
    return [];
  }
  const query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "sfid",
      "external_id__c",
      "ips_id__c",
      "product_system__c",
      "product__c",
      "quantity__c",
      "loaner__c",
      "is_preference_product__c",
      "inactive__c"
    )
    .from("surgical_case_products__c");

  if (case_external_id) {
    query.where({ surgical_case__r__external_id__c: case_external_id });
  } else {
    query.where({ surgical_case__c: surgical_case });
  }
  return query;
}

function deleteSurgicalCaseProducts(scps, trx) {
  let sfids = [],
    externalIds = [];
  for (const scpsItem of scps) {
    if (scpsItem.sfid) {
      sfids.push(scpsItem.sfid);
    } else if (scpsItem.external_id__c) {
      externalIds.push(scpsItem.external_id__c);
    }
  }
  if (externalIds.length > 0 || sfids.length > 0) {
    return herokuConnectClient("surgical_case_products__c")
      .transacting(trx)
      .withSchema("salesforce")
      .where(function() {
        if (externalIds.length > 0 && sfids.length > 0) {
          this.whereIn("external_id__c", externalIds).orWhereIn("sfid", sfids);
        } else if (sfids.length > 0) {
          this.whereIn("sfid", sfids);
        } else {
          this.whereIn("external_id__c", externalIds);
        }
      })
      .update({
        inactive__c: true
      });
  }
}

function upsertRecord(record, trx, scps) {
  if (scps) {
    if (scps.sfid || scps.external_id__c) {
      let scpsUpdate = herokuConnectClient("surgical_case_products__c")
        .withSchema("salesforce")
        .update({
          ...record,
          inactive__c: false
        })
        .transacting(trx);

      if (scps.external_id__c) {
        scpsUpdate = scpsUpdate.where("external_id__c", "=", scps.external_id__c);
      } else if (scps.sfid) {
        scpsUpdate = scpsUpdate.where("sfid", "=", scps.sfid);
      }
      return scpsUpdate;
    } else {
      return Promise.resolve();
    }
  } else {
    return herokuConnectClient("surgical_case_products__c")
      .withSchema("salesforce")
      .transacting(trx)
      .insert(record);
  }
}

function updatedInventoryProductSystem(
  trx,
  ipsids,
  case__c,
  external_id__c
) {
  if (!ipsids || ipsids.length === 0) {
    return Promise.resolve([]);
  }
  const scpsUpdate = herokuConnectClient("inventory_product_system__c")
    .withSchema("salesforce")
    .update({
      status__c: "Assigned",
      surgical_cases__c: case__c || "",
      surgical_cases__r__external_id__c: external_id__c,
    })
    .transacting(trx)
    .whereIn("sfid", ipsids);

  return scpsUpdate;
}
