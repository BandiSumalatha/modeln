const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, args, context) => {
  const currentUser = await context.currentUser(false);
  let user_sfid = currentUser.sfids[0];

  let query = herokuConnectClient
    .withSchema('salesforce')
    .select([
      'product_system__c.id',
      'product_system__c.sfid as set_id',
      'product_system__c.category__c as set_name',
      'product_system__c.productsystemname__c as catalog_category',
      'product_system__c.category__c AS catalog_item_name',
      'product_system__c.sfid as catalog_item_sfid'
    ])
    .from('product_system__c')
    .innerJoin('user', function() {
      this.on(
        herokuConnectClient.raw(
          `"user".multiselect_division__c LIKE '%' || product_system__c.division__c || '%'`
        )
      );
    })
    .where('user.sfid', user_sfid);

  let sets = await query;
  return sets || {};
};
