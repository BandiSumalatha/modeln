const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { }, context) => {
  
  let surgicalPlanCodes = await herokuConnectClient
    .withSchema('repsuite')
    .select(
      herokuConnectClient.raw('label as "label"'),
      herokuConnectClient.raw('code as "code"'),
      herokuConnectClient.raw('readabletext as "readabletext"'),
      herokuConnectClient.raw('type as "ewtype"'),
    )
    .from('surgical_plan_codes')
    .orderBy(herokuConnectClient.raw(`code::integer`));
  
    const groupedResult = {};

    for(const {label, code, readabletext, ewtype} of surgicalPlanCodes) {
        if(!groupedResult[label]) groupedResult[label] = [];
        groupedResult[label].push({ surgicalCode: code, description: readabletext, ewtype: ewtype });
    }

  return Object.keys(groupedResult).map(label => {
    return { 
      label,
      statusCode: groupedResult[label]
    };
  }) || [];
};
