const { herokuConnectClient } = require("../../../services/knex");
const { groupBy } = require("lodash");

module.exports = async (root, { caseExternalId, caseSfId }, context) => {
  try {
    const query = herokuConnectClient
      .withSchema("salesforce")
      .select(
        "caseaction_tracking__c.changed_date__c as change_date",
        "caseaction_tracking__c.action__c as action",
        "caseaction_tracking__c.changed_by_system__c as changed_by_system",
        "caseaction_tracking__c.changed_by__c as changed_by"
      )
      .from("caseaction_tracking__c")
      .orderBy("caseaction_tracking__c.changed_date__c", "desc");
    if (caseSfId) {
      query.where("caseaction_tracking__c.surgical_case__c", caseSfId);
    } else {
      query.where(
        "caseaction_tracking__c.surgical_case__r__external_id__c",
        caseExternalId
      );
    }
    const caseAction = await query;
    return caseAction;
  } catch (ex) {
    console.log(ex);
    throw ex;
  }
};
