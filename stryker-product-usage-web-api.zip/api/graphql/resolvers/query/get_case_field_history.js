const { herokuConnectClient } = require("../../../services/knex");
const { groupBy } = require("lodash");

module.exports = async (root, { caseExternalId, caseSfId }, context) => {
  try {
    const query = herokuConnectClient
      .withSchema("salesforce")
      .select(
        "cases__history.createddate as created_date",
        "user.name as user_id",
        "cases__history.field as field_name",
        "cases__history.newvalue as new_value",
        "cases__history.oldvalue as old_value"
      )
      .from("cases__history")
      .innerJoin("user", "cases__history.createdbyid", "user.sfid");
    if (caseSfId) {
      query.where("cases__history.parentid", caseSfId);
    } else {
      query.where("cases__history.id", caseExternalId);
    }
    const data = await query;
    return data;
  } catch (ex) {
    console.log(ex);
    throw ex;
  }
};
