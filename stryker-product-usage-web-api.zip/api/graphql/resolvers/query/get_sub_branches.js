const { getBranches } = require('../common/branches');

module.exports = async (_root, { branchId }, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  const branches = await getBranches(user_sfid, branchId ? [ branchId ] : currentUser.branchIds);
  return branches.filter((b) => { return b.inventoryLocation; });
};
