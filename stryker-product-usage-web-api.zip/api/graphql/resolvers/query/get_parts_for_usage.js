const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (
  root,
  {searchText},
  context
) => {
  let query = herokuConnectClient
  .withSchema('repsuite')
  .select(
    'parts.part_name',
    'parts.product_sfid',
    'part_desc',
    'lot_serial_control_code__c',
      herokuConnectClient.raw(
        `CASE WHEN (lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      ),
    'productOracleId',
    'gtin',
    'catalog_number',
    'parts_tracker.is_deleted'
    )
  .from('parts')
  .leftJoin(
    'parts_tracker',
    'parts.product_sfid',
    'parts_tracker.product_sfid'
  ).where(function() {
    this.where('parts_tracker.is_deleted', false)
    .orWhere('parts_tracker.is_deleted', null);
  })
  
  if (searchText) {
    query = query.where(function() {
      this.where("partsearch__c", "ilike", `%${searchText}%`).
      orWhere("part_search_withouthyphen__c", "ilike", `%${searchText}%`);
      })
  } 
  let parts = query.limit(50);
  return parts || {};
}
