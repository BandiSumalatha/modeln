const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { tprNames }, _context) => {
    let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "external_tpr_id__c AS tpr_rhs_id",
      "sfid AS tpr_sfid",
      "external_id__c AS external_id",
      "name AS tpr_name",      
      "tpr_opened__c AS tpr_opened",
    )
    .from('treatment_plan_request__c')   
    .whereIn('name', tprNames);   

    const arrTprNames = await query;
  return arrTprNames || [];
}