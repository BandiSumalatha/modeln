const { getAllBranches } = require('../common/branches2');

module.exports = async (_root, _args, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  return await getAllBranches(user_sfid);
};
