const { TPRFilter } = require('../../../models/TPRFilter');

module.exports = async(_root, _args, context) => {
    const currentUser = await context.currentUser(false);
    const user_sfid = currentUser.sfids[0];

    const response = await TPRFilter.find({ user_sfid }).exec();
    return response.map((r) => { return { name: r.name, ...r.definition };});
}