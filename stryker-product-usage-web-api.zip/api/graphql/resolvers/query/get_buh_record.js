const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (
  root,
  { hospital_sfid, surgeon_sfid, branch_sfid, sales_rep_sfid },
  context
) => {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select(1)
    .from('branch_user_hospital__c')

    .innerJoin('contact', function() {
      this.on('branch_user_hospital__c.contact_id__c', '=', 'contact.sfid');
    })
    .innerJoin('user', function() {
      this.on('branch_user_hospital__c.user_id__c', '=', 'user.sfid');
    })
    .innerJoin('branch__c', function() {
      this.on('branch_user_hospital__c.branch_id__c', '=', 'branch__c.sfid');
    })
    .where('contact.inactive__c', false)
    .where('user.isactive', true)
    .where(function() {
      this.where('branch__c.isactive__c', '1');
      this.orWhereNull('branch__c.isactive__c');
    })
    .where('branch_user_hospital__c.branch_id__c', branch_sfid)
    .andWhere('branch_user_hospital__c.contact_id__c', surgeon_sfid)
    .andWhere('branch_user_hospital__c.user_id__c', sales_rep_sfid)
    .andWhere('branch_user_hospital__c.hospital_id__c', hospital_sfid)
    .limit(1);

  const buhRecordsCount = await query;
  return { buh_available: buhRecordsCount.length > 0 };
};
