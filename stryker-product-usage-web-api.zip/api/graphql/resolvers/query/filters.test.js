const mockingoose = require('mockingoose').default;

jest.mock('../../../config', () => ({
  MONGODB: {}
}));

jest.mock('../../services/sfdcTransformation', () => ({
  transformSurveyResponse: jest.fn()
}));

const filters = require('./filters');
describe('query -> filters', () => {
  it('should return response for a given payload', async () => {
    const args = {
      user_sfid: 'some-user-sfid'
    };
    const mockUserFilters = [
      {
        id: 'some-id',
        user_sfid: 'some-user-sfid',
        name: 'Test Filter',
        definition: {
          division: 'Spine',
          branchId: 'some-branch-sfid',
          salesRepId: 'some-salesrep-sfid',
          fromDate: new Date().toString(),
          toDate: new Date().toString()
        }
      },
      {
        id: 'some-id',
        user_sfid: 'some-user-sfid',
        name: 'Test Filter 2',
        definition: {
          isFavorite: true,
          branchId: 'some-branch-sfid',
          salesRepId: 'some-salesrep-sfid',
          fromDate: new Date().toString(),
          toDate: new Date().toString()
        }
      }
    ];
    mockingoose.UserFilter.toReturn(mockUserFilters, 'find');
    const result = await filters({}, args, {
      currentUser: {
        sfids: ['12345']
      }
    });
    expect(result).toBeTruthy();
    expect(result.length).toBe(mockUserFilters.length);
  });
});
