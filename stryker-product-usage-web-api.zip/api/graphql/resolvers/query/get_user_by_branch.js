const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { branchIds }, context) => {
  const userRepsPersona = process.env.USER_REPS_PERSONA
    ? process.env.USER_REPS_PERSONA.split(';')
        .map(persona => `'${persona}'`)
        .join(',')
    : [`'Sales Rep'`];
  const currentUser = await context.currentUser(false);
  let { divisions } = currentUser || {};
  divisions = divisions.map(div => `'${div}'`).join(',');

  let normalizedBranches = ['ALL'];
  if (branchIds) {
    branchIds.forEach(id => normalizedBranches.push(id));
  }

  let query = herokuConnectClient
    .withSchema('repsuite')
    .select(
      'branchID',
      'userID',
      'userName',
      'multiplePersona',
      'divisions',
      'personas'
    )
    .from('salesreps_mv')
    .whereRaw(`"branchID" in (VALUES ${normalizedBranches.map(x => "('" + x + "')").join(',')})`)
    .where(
      herokuConnectClient.raw(
        `divisions && ARRAY[${divisions}]`
      )
    )
    .where(
      herokuConnectClient.raw(
        `personas && ARRAY[${userRepsPersona}]`
      )
    );
  const users = await query;
  return users || [];
};
