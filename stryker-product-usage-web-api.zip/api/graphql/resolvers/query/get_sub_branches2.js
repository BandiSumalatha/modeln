const { getBranches, getAllBranches } = require('../common/branches2');

module.exports = async (_root, { branchId }, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  const branches = branchId ? await getBranches(user_sfid, [ branchId ]) : await getAllBranches(user_sfid);
  return branches.filter((b) => { return b.inventoryLocation; });
};
