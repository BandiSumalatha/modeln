const { herokuConnectClient } = require("../../../services/knex");
const { groupBy } = require("lodash");

module.exports = async (root, { caseExternalId, caseSfId }, context) => {
  try {
    const query = herokuConnectClient
      .withSchema("salesforce")
      .select(
        "caseaction_tracking__c.action__c as action",
        herokuConnectClient.raw(
          `array_AGG(CONCAT(changed_date__c ,' , ', changed_by__c) order by changed_date__c) AS "caseHistory"`
        )
      )
      .from("caseaction_tracking__c")
      .groupBy("caseaction_tracking__c.action__c");
    if (caseSfId) {
      query.where("caseaction_tracking__c.surgical_case__c", caseSfId);
    } else {
      query.where(
        "caseaction_tracking__c.surgical_case__r__external_id__c",
        caseExternalId
      );
    }
    const data = await query;
    return data;
  } catch (ex) {
    console.log(ex);
    throw ex;
  }
};
