const { herokuConnectClient } = require('../../../services/knex');
const { shortTermCache } = require('../../../services/CacheService');

async function populatePreferences() {
  const query = herokuConnectClient
      .withSchema('salesforce')
      .select()
      .from('repsuiteapp_settings__c')
      .innerJoin('recordtype', function() {
        this.on('recordtype.sfid', '=', 'repsuiteapp_settings__c.recordtypeid');
        this.on(function() {
          this.on(
            herokuConnectClient.raw("recordtype.name  = 'Hospital Preference'")
          );
          this.orOn(
            herokuConnectClient.raw("recordtype.name  = 'Branch Preference'")
          );
        });
      });
    return await query;
}

module.exports = async (root, args, context) => {
  let notificationPrefs = await shortTermCache.getOrUpdate('get_rep_suite_app_settings', populatePreferences);
  return notificationPrefs || {};
};
