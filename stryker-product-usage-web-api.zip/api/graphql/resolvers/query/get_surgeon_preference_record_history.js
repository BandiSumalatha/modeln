const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (
  root,
  { surgeon_preference_id, surgeon_preference_external_id },
  context
) => {
  if (surgeon_preference_id || surgeon_preference_external_id) {
    const records = await herokuConnectClient
      .withSchema('salesforce')
      .select([
        'record_history__c.new_value__c as value',
        'record_history__c.old_value__c as old_value',
        'user.name as user_name',
        'record_history__c.update_time__c as updated_date'
      ])
      .from('record_history__c')
      .innerJoin('user', 'record_history__c.updated_by__c', 'user.sfid')
      .where(function() {
        if (surgeon_preference_id)
          return this.where(
            `record_history__c.surgeon_preference__c`,
            surgeon_preference_id
          );
        else {
          return this.where(
            `record_history__c.surgeon_preference__r__external_id__c`,
            surgeon_preference_external_id
          );
        }
      })
      .orderBy('record_history__c.update_time__c', 'DESC');
    return records || [];
  }
  return [];
};
