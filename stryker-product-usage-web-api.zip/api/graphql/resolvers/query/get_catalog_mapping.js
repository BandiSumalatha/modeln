const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (
  root,
  { femoralComponent, insertType, baseplate },
  context
) => {
  try {
    if (femoralComponent && insertType && baseplate) {
      const query = herokuConnectClient
        .withSchema("repsuite")
        .select(
          "catalognumber as catalogNumber",
          "catalogdescription as catalogDescription"
        )
        .from("as1_catalog_mapping")
        .where("active", false)
        .where("femoralcomponent", femoralComponent)
        .where("inserttype", insertType)
        .where("baseplate", baseplate);

      const catalogMapping = await query;
      return catalogMapping;
    }
  } catch (ex) {
    console.log(ex);
    throw ex;
  }
};
