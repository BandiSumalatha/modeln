const { herokuConnectClient } = require('../../../services/knex');
const { uniqBy } = require('lodash');

module.exports = async (_root, _args, context) => {
  let startTime = Date.now();
  const currentUser = await context.currentUser(false);
  const { divisions } = currentUser;
  let user_sfid = currentUser.sfids[0];
  const casesSets = await findCasesSets(user_sfid);
  let sets = uniqBy([...casesSets], 'set_id');
  const setIds = sets.reduce((accumulator, set) => {
    if (accumulator.indexOf(set.set_id) < 0 && set.set_id) {
      accumulator.push(set.set_id);
    }
    return accumulator;
  }, []);
  const parts = await findPartsForSets(setIds, divisions);
  console.log(`Time spent retrieving sets from DB: ${Date.now() - startTime}ms`);
  startTime = Date.now();
  sets = sets.map(set => {
    set.parts = parts.filter(part => part.set_id === set.set_id);
    return set;
  });
  console.log(`Time spent retrieving sets: ${Date.now() - startTime}ms`);
  return sets;
};

function findCasesSets(user_sfid) {
  return herokuConnectClient
    .withSchema('salesforce')
    .select(
      'ipsc.sfid AS set_id',
      'ipsc.name AS set_name',
      'ipsc.kit_no__c AS kit_no__c',
      'c.surgery_start_date_time__c AS Surgery_date__c',
      'c.name AS Case_Number__c',
      'ipsc.status__c AS Status__c',
      'productSystem.category__c AS Category__c',
      herokuConnectClient.raw(`'Cases' AS inventory_type`),
      herokuConnectClient.raw(
        `CASE WHEN (ipsc.kit_no__c IS NULL OR ipsc.kit_no__c = '')
          THEN ipsc.name
          ELSE CONCAT (ipsc.kit_no__c, ' - ', ipsc.name) END
         AS label`
      )
    )
    .from('user AS u')
    .innerJoin('cases__c AS c', 'c.kit_assigner__c', 'u.sfid')
    .innerJoin('surgical_case_products__c AS scpc', function() {
      this.on(
        'c.external_id__c',
        '=',
        'scpc.surgical_case__r__external_id__c'
      ).orOn('c.sfid', '=', 'scpc.surgical_case__c');
    })
    .innerJoin(
      'inventory_product_system__c AS ipsc',
      'scpc.ips_id__c',
      'ipsc.sfid'
    )
    .leftJoin(
      'product_sub_system__c as productSubSystem',
      'ipsc.prosubsysid__c',
      'productSubSystem.sfid'
    )
    .leftJoin(
      'product_system__c as productSystem',
      'productSubSystem.productsystemid__c',
      'productSystem.sfid'
    )
    .where('u.sfid', '=', user_sfid);
}

function findPartsForSets(ipscIDs = [], divisions) {
  let query = herokuConnectClient
    .withSchema('salesforce')
    .distinct(
      'prd.sfid AS product_sfid',
      'prd.sfid AS part_id',
      'prd.inventory_item_id_plain__c AS productOracleId',
      'prd.gtin__c AS gtin',
      'prd.catalog_number__c AS catalog_number',
      'ipc.ipsid__c AS set_id',
      'pbe.lot_serial_control_code__c',
      herokuConnectClient.raw(
        `CONCAT (prd.catalog_number__c, ' - ', prd.description__c) AS part_name`
      ),
      herokuConnectClient.raw(
        `coalesce(prd.description, p2.description) as part_desc`
      ),
      herokuConnectClient.raw(
        `CASE WHEN (pbe.lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      )
    )
    .select()
    .from('invproductcomponent__c AS ipc')
    .innerJoin('product2 AS prd', 'prd.sfid', 'ipc.product__c')
    .innerJoin('pricebookentry AS pbe', function() {
      this.on(function() {
        this.on('pbe.product2id', '=', 'prd.sfid');
        this.on(herokuConnectClient.raw('prd.is_obsolete_in_us__c = false'));
        this.on(herokuConnectClient.raw('prd.isactive = true'));
      });
    })
    .leftOuterJoin(
      'productsubsystemcomponents__c as psc',
      'psc.sfid',
      'ipc.productsubsyscompid__c'
    )
    .leftOuterJoin('product2 as p2', 'p2.sfid', 'psc.product__c')
    .whereIn('ipc.ipsid__c', ipscIDs)
    .where(
      herokuConnectClient.raw(
        'pbe.lot_serial_control_code__c IS NOT NULL AND pbe.product2id IS NOT NULL'
      )
    )
    .orderBy('part_name');
  let productsTypes = ['Spine Products'];
  if (
    divisions.includes('Joint Replacement') ||
    divisions.includes('Trauma & Extremeties') ||
    divisions.includes('Trauma')
  ) {
    query.whereIn('prd.product_status__c', [
      'Active',
      'CUSTOM',
      'DSGN_INPRC',
      'DSGN_REL',
      'Hold',
      'PHASE_OUT',
      'LAUNCH'
    ]);
    productsTypes.push('Ortho Products');
    query
      .innerJoin('pricebook2 as pricebook', function() {
        this.on(function() {
          this.on('pbe.pricebook2id', '=', 'pricebook.sfid');
        });
      })
      .whereIn('pricebook.name', productsTypes);
  }
  return query;
}
