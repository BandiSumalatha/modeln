const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { branchIds, searchText }, _context) => {
  let query = herokuConnectClient
    .withSchema("repsuite")
    .select("branchID", "hospitalId", "hospitalName", "accountNo")
    .from("hospitals_mv");

  if (branchIds && branchIds.length <= 20) {
      query.whereRaw(`"branchID" in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`)
    }

  if (searchText) {
    query = query
      .where("hospitalName", "ilike", `%${searchText}%`)
      .orWhere("hospitalId", "ilike", `%${searchText}%`);
  }

  const hospitals = await query;
  return hospitals || [];
};
