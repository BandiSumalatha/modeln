const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { searchText }, _context) => {
    let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
        'account.sfid as sfid',
        'account.name AS name',
        'account.accountnumber AS accountnumber'
    )
    .from('account')
    .innerJoin('recordtype', 'account.recordtypeid', 'recordtype.sfid')
    .where('recordtype.name', 'Mako Scan Facility');
  if (searchText) {
    query = query.where(function() {
      this
        .where("account.accountnumber", "ilike", `%${searchText}%`)
        .orWhere("account.name", "ilike", `%${searchText}%`);
    });
  }

  const scanFacilites = await query;
  return scanFacilites || [];
}