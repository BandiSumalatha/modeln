const { getBranches } = require('../common/branches');

module.exports = async (_root, _args, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  const branchIds = currentUser.branchIds;
  const branches = await getBranches(user_sfid, branchIds);
  return branches.filter((b) => { return !b.mainBranch; });
};
