const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { case_id }, context) => {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select(
      'sfid',
      'ordernumber AS OrderNumber',
      'aro_number__c as aroNo',
      'salesrep_name__c AS SalesrepName',
      'ponumber AS PoNumber',
      'podate AS PoDate',
      'status AS Status',
      'effectivedate AS OrderBookedDate',
      'invoice_date__c AS InvoiceDate',
      'invoice_number__c AS InvoiceNumber',
      'order_number_oracle__c AS erpNumber',
      'order_other_amount__c'
    )
    .where('order.surgical_cases__c', case_id)
    .from('order');

  let orders = await query;

  const orderSFIds = orders.map(order => order.sfid);
  const lineItems = await getLineItems(orderSFIds);
  orders = orders.map(order => {
    const fetchedLineItems = lineItems.filter(
      lineItem => lineItem.orderid === order.sfid
    );
    const TotalAmount = fetchedLineItems.reduce((accumulator, lineItem) => {
      if (lineItem.rs_usg_total_amount__c) {
        accumulator += lineItem.rs_usg_total_amount__c;
      }
      return accumulator;
    }, 0);
    order.finalbillamount = TotalAmount;
    let orderOtherAmount = 0;
    if (order.order_other_amount__c) {
      orderOtherAmount = order.order_other_amount__c;
    }
    order.TotalAmount = orderOtherAmount;
    order.lineItems = fetchedLineItems;
    return order;
  });

  return orders || [];
};

const getLineItems = async orderSFIds => {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select(
      'status__c AS lineStatus',
      herokuConnectClient.raw(
        `COALESCE(p.catalog_number__c || ' - ', '') || p.name as "partNoName"`
      ),
      'aro_status__c AS AROStatus',
      'aro_ship_to__c AS AROShipTo',
      'aro_shipment_method__c AS AROShipmentMethod',
      'quantity_shipped__c AS ShippedQty',
      'backorder_quantity__c AS BackorderQty',
      'contractprice__c AS Price',
      'quantity AS Requested',
      'rs_usg_total_amount__c',
      'orderid'
    )
    .from('orderitem')
    .innerJoin('product2 as p', function() {
      this.on('orderitem.product2id', '=', 'p.sfid');
    })
    .where(herokuConnectClient.raw('orderitem.product2id IS NOT NULL'))
    .whereIn('orderid', orderSFIds);

  return await query;
};
