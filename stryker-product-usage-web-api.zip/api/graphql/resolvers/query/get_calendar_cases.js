const { herokuConnectClient } = require('../../../services/knex');
const moment = require('moment');

const ROLE_CASES = {
  MY_CASES: 'My Cases',
  COVERING_CASES: 'Covering Cases',
  TEAM_CASES: 'Team Cases',
  BRANCH_CASES: 'Branch Cases'
};

module.exports = async (root, { filters }, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  const {
    status,
    division,
    role,
    filterHospital,
    filterSurgeon,
    filterBranch,
    filterSalesRep,
    startDate,
    endDate,
    filterSalesTeam,
    isWebOpsError,
    procedure,
    timezoneOffset,
    searchText,
    mako,
    as1,
    surgery_date_confirmed
  } = filters || {};
  const { divisions, branchIds } = currentUser || {};
  try {
    let query = herokuConnectClient
      .withSchema('salesforce')
      .select(
        'cases__c.external_id__c AS externalId',
        'cases__c.sfid AS sfId',
        herokuConnectClient.raw(
          `COALESCE(cases__c.name, 'Case ID TBD') as "caseId"`
        ),
        'user.name AS salesRep',
        herokuConnectClient.raw(
          `COALESCE(cases__c.createddate, now() at time zone 'utc') as "createdDate"`
        ),
        'cases__c.surgery_start_date_time__c as surgeryDate',
        'cases__c.patient_info__c as patientId',
        herokuConnectClient.raw(
          `CONCAT (contact.surgeon_erp_code__c, ' - ', contact.name) AS "surgeonName"`
        ),
        'cases__c.status__c AS status',
        herokuConnectClient.raw(
          `CONCAT (account.accountnumber, ' - ', account.name) AS "hospitalName"`
        ),
        herokuConnectClient.raw(
          `(CASE WHEN (
            ("cases__c"."webops_integration_status__c" = 'Failed') or 
            ("cases__c"."webops_create_status__c" = 'Failed') or
            ("cases__c"."webops_completed_status__c" = 'Failed') or
            ("cases__c"."webops_requested_status__c" = 'Failed')) then true else false END) as "isWebOpsError"`
        ),
        'cases__c.favourite__c AS favoriteCase',
        'cases__c.covering_reps__c',
        'procedure__c.sfid as procedure_id',
        'procedure__c.name as procedure_name'
      )
      .from('cases__c')
      .innerJoin('account', 'cases__c.hospitalid__c', 'account.sfid')
      .innerJoin('branch__c', 'cases__c.branchid__c', 'branch__c.sfid')
      .leftJoin('procedure__c', 'procedure__c.sfid', 'cases__c.procedureid__c')
      .leftJoin('user', 'cases__c.kit_assigner__c', 'user.sfid')
      .leftOuterJoin('contact', 'cases__c.hospital_staffid__c', 'contact.sfid')
      .where(
        herokuConnectClient.raw(`"cases__c"."non_usage_orders__c" IS NOT TRUE`)
      )
      .orderBy('cases__c.surgery_start_date_time__c');

    // Filters
    if (division) {
      query.where('cases__c.division__c', '=', division);
    } else {
      query.whereIn('cases__c.division__c', divisions);
    }
    if (status) {
      query.whereRaw(`cases__c.status__c in (VALUES ${status.split(',').map(x => "('" + x + "')").join(',')})`);
    }
    
    if (filterBranch) {
      query.andWhere(function() {
        this
          .where('cases__c.branchid__c', filterBranch)
          .orWhere('cases__c.region_filter__c', filterBranch);
      });
    }
    else if (branchIds && branchIds.length <= 20) {
      query.andWhere(function() {
        this
          .whereRaw(`cases__c.branchid__c in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`)
          .orWhereRaw(`cases__c.region_filter__c in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`);
      });
    }

    if (filterSurgeon) {
      query.where('cases__c.hospital_staffid__c', filterSurgeon);
    }
    if (filterHospital) {
      query.where('cases__c.hospitalid__c', filterHospital);
    }
    if (procedure) {
      query.where('cases__c.procedureid__c', procedure);
    }
    if (filterSalesTeam) {
      query.whereRaw(`"cases__c"."kit_assigner__c" in (select userid__c from
        "salesforce"."branchuserpod__c" where podid__c = '${filterSalesTeam}')
        AND "cases__c"."branchid__c" in (${"branch__c.sfid"})`);
    }
    if (filterSalesRep) {
      query.where('cases__c.kit_assigner__c', filterSalesRep);
    }
    if (startDate) {
      const offset = timezoneOffset ? -timezoneOffset : 0;
      query.whereRaw(
        `date(cases__c.surgery_start_date_time__c + interval '${offset} minutes') >= '${startDate}'`
      );
    }
    if (endDate) {
      const offset = timezoneOffset ? -timezoneOffset : 0;
      query.whereRaw(
        `date(cases__c.surgery_start_date_time__c + interval '${offset} minutes') <= '${endDate}'`
      );
    }
    if (searchText) {
      query.andWhere(function() {
        this.where(
          "cases__c.patient_info__c",
          "ilike",
          `%${searchText}%`
        ).orWhere("cases__c.name", "ilike", `%${searchText}%`);
      });
    }
    if (isWebOpsError) {
      query.where(function() {
        this.where('cases__c.webops_completed_status__c', 'Failed')
          .orWhere('cases__c.webops_create_status__c', 'Failed')
          .orWhere('cases__c.webops_requested_status__c', 'Failed')
          .orWhere('cases__c.webops_integration_status__c', 'Failed');
      });
    }
    if (mako) {
      query.where("cases__c.mako__c", true);
    }
    if (as1) {
      query.where("cases__c.as1__c", true);
    }
    if (surgery_date_confirmed) {
      query.where("cases__c.surgery_date_confirmed__c", true);
    } else if (!surgery_date_confirmed) {
      query.where("cases__c.surgery_date_confirmed__c", false);
    }
    switch (role) {
      case ROLE_CASES.COVERING_CASES: {
        query
          .innerJoin('surgical_case_sales_team__c', function() {
            this.on(
              'cases__c.sfid',
              '=',
              'surgical_case_sales_team__c.surgical_cases__c'
            ).orOn(
              'cases__c.external_id__c',
              '=',
              'surgical_case_sales_team__c.surgical_cases__r__external_id__c'
            );
          })
          .where('surgical_case_sales_team__c.sales_rep__c', user_sfid);
        break;
      }
      case ROLE_CASES.MY_CASES: {
        query.where('cases__c.kit_assigner__c', user_sfid);
        break;
      }
      case ROLE_CASES.BRANCH_CASES: {
        // branch filters are already applied earlier in query
        break;
      }
      case ROLE_CASES.TEAM_CASES: {
        const teammate_sfids = currentUser.teammate_sfids;
        if (teammate_sfids) {
          query.andWhere(function() {
            this.whereExists(function() {
              this.select(1)
                .from('surgical_case_sales_team__c')
                .whereRaw(
                  `cases__c.sfid = surgical_case_sales_team__c.surgical_cases__c`
                )
                .whereIn(
                  'surgical_case_sales_team__c.sales_rep__c',
                  teammate_sfids
                )
                .limit(1);
            })
              .orWhereExists(function() {
                this.select(1)
                  .from('surgical_case_sales_team__c')
                  .whereRaw(
                    `cases__c.external_id__c = surgical_case_sales_team__c.surgical_cases__r__external_id__c`
                  )
                  .whereIn(
                    'surgical_case_sales_team__c.sales_rep__c',
                    teammate_sfids
                  )
                  .limit(1);
              })
              .orWhereIn('cases__c.kit_assigner__c', teammate_sfids);
          });
        }
        break;
      }
    }
    query.limit(1000);
    const myCases = await query;

    if (myCases) {
      myCases.map(myCase => {
        myCase.surgeryDate = moment(myCase.surgeryDate).toISOString();
        myCase.procedures = myCase.procedure_id ? [
          {
            case_external_id: myCase.externalId,
            sfid: myCase.procedure_id,
            name: myCase.procedure_name
          }
        ] : [];
      });
      return [...myCases];
    }

    return [];
  } catch (ex) {
    console.log(ex);
    return [];
  }
};
