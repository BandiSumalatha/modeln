const { herokuConnectClient } = require('../../../services/knex');

module.exports = async(root, { tpr_id }, context) => {
  let tprhistory =  herokuConnectClient
    .withSchema('salesforce')
    .select([
      'treatment_plan_request__history.createddate',
      'treatment_plan_request__history.newvalue',
      'treatment_plan_request__history.oldvalue',
      'treatment_plan_request__history.field',
      'user.name'
    ])
    .from('treatment_plan_request__history')
    .leftJoin("user", "treatment_plan_request__history.createdbyid", "user.sfid")

    tprhistory.where("treatment_plan_request__history.field", "Status__c");
    tprhistory.where("treatment_plan_request__history.parentid", tpr_id);

    return (await tprhistory) 
};


