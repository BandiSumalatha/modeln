const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (
  root,
  { procedure_id, case_branch_sfid, storageExist, case_sales_rep },
  context
) => {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "pc.name as catalog_category",
      herokuConnectClient.raw(
        `array_AGG(CONCAT(ps.productsystemname__c,' , ', ps.sfid)) AS "caseProducts"`
      ),
    ])
    .from("product_system__c AS ps")
    .groupBy("pc.name")
    .innerJoin(
      "product_system_procedure_category__c AS pspc",
      "pspc.product_system__c",
      "ps.sfid"
    )
    .innerJoin(
      "procedure_category__c AS pc",
      "pc.sfid",
      "pspc.procedure_category__c"
    )
    .innerJoin("procedure__c AS p", "p.sfid", "pc.procedure__c")
    .innerJoin("branch__c as branch", "branch.sfid", "pspc.branchid__c")
    .leftJoin(
      "branch__c as mainBranch",
      "mainBranch.sfid",
      "branch.main_branch__c"
    )
    .leftJoin(
      "invlocation__c as inv_location",
      "inv_location.branchid__c",
      "pspc.branchid__c"
    )
    .where("p.sfid", procedure_id)
    .where("pspc.isactive__c", true)
    .where("pc.isactive__c", true)
    .where("p.isactive__c", true)
    .where(function() {
      this
        .whereNotNull("pspc.branchid__c")
        .whereNotNull("pc.branchid__c")
        .orWhere(function() {
          this
            .where("branch.isactive__c", "1")
            .where("mainBranch.isactive__c","1"
          );
        });
    })
    .where(function() {
      this
        .where(function() {
          this
            .where("inv_location.branchid__c", `${case_branch_sfid}`)
            .where("inv_location.userid__c", `${case_sales_rep}`);
        })
        .orWhere(function() {
          this
            .whereNull(`mainBranch.sfid`)
            .where("pspc.branchid__c", `${case_branch_sfid}`)
            .where("pc.branchid__c", `${case_branch_sfid}`);
        })
    });

  let sets = await query;
  return sets || {};
};
