const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, args, context) => {
  const currentUser = await context.currentUser(false);
  const user_sfid = currentUser.sfids[0];
  
  let podsMembers = await herokuConnectClient
    .withSchema("salesforce")
    .select([
     "pod.sfid as sfid",
     "pod.name as name",
     herokuConnectClient.raw(
        `string_agg(distinct podmembers.userid__c, ',') as "members"`
      ),
    ])
    .from("branchuserpod__c as mypods")    
    .innerJoin("branchuserpod__c as podmembers", "podmembers.podid__c", "mypods.podid__c")
    .innerJoin("pod__c as pod", "pod.sfid", "mypods.podid__c")
    .where("mypods.userid__c", user_sfid)
    .groupBy("pod.sfid")
    .groupBy("pod.name");

  return podsMembers || [];
};