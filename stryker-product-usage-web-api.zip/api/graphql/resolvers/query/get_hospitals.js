const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { searchText }, context) => {
  const currentUser = await context.currentUser(true);

  let userid = currentUser.sfids[0];
  if (currentUser.personas) {
    currentUser.personas.forEach(persona => {
      if (persona && (
        persona.toLowerCase().indexOf('in-house') !== -1
        || persona.toLowerCase().indexOf('csr') !== -1
        || persona.toLowerCase().indexOf('branch op') !== -1
      )) {        
        userid = 'ALL';
      }
    });
  }

  let query = herokuConnectClient
    .withSchema("repsuite")
    .select(
      herokuConnectClient.raw('"subBranch" as "branchID"'), 
      herokuConnectClient.raw('"subBranchName" as "branchName"'), 
      herokuConnectClient.raw('hospitalid as "hospitalId"'),
      "hospitalName", 
      "accountNo",
      "mainBranch",
      "mainBranchName")
    .from("hospitals2_mv")
    .where("userid", userid);
  if (searchText) {
    query = query
      .where("hospitalName", "ilike", `%${searchText}%`)
      .orWhere("accountNo", "ilike", `%${searchText}%`);
  }

  const hospitals = await query;
  return hospitals || [];
};
