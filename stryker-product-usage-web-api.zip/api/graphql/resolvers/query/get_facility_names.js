const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { customerIds }, _context) => {
    let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
        'account.sfid as sfid',
        'account.customer_id__c AS customerId',
        'account.name AS customerName'
    )
    .from('account')
    .innerJoin('recordtype', 'account.recordtypeid', 'recordtype.sfid')
    .where('recordtype.developername', 'Mako_Scan_Facility');

    if(customerIds.length) {
        query = query.whereIn('account.customer_id__c', customerIds);
    }

    const facilityNames = await query;
  return facilityNames || [];
}