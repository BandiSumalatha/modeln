const { REDIS } = require('../../../config');
const { getConnection } = require('../../../services/jsforce');
const { get, setEx } = require('../../../services/redis');
const winston = require('winston');

module.exports = async (root, args, context, info) => {
  try {
    let argsRaw = JSON.stringify(args);
    let sanitizedArgs = {
      ...args
    };
    delete sanitizedArgs.refresh_cache;
    winston.info(`Retrieving Salesforce picklist ${argsRaw}`);
    let key = `${info.fieldName}_${JSON.stringify(sanitizedArgs)}`;
    let cachedValueRaw = await get(REDIS.SALESFORCE_API_CACHE, key);

    // Only call out to SFDC if the cached value expired or doesn't exist
    if (!cachedValueRaw || args.refresh_cache) {
      winston.info(`Refreshing cache for Salesforce picklist ${argsRaw}`);
      let type = args.type || 'GlobalValueSet';
      let conn = await getConnection();
      let result = await conn.metadata.read(type, args.name);
      if (type === 'GlobalValueSet' && !result.customValue) {
        throw new Error(
          `${args.name} is not a valid Global Picklist in Salesforce`
        );
      }
      let results = [];

      switch (type) {
        case 'GlobalValueSet':
          // results = result.customValue.map(item => {
          //   return {
          //     id: item.fullName,
          //     label: item.label
          //   };
          // });

          results = result.customValue.reduce((output, item) => {
            if (!item.isActive) {
              output.push({
                id: item.fullName,
                label: item.label
              });
            }
            return output;
          }, []);

          break;
        case 'CustomObject':
          let customObject = result.fields.find(field => {
            return (
              field.fullName.toLowerCase() === args.field_name.toLowerCase()
            );
          });
          if (args.parentPicklistValue) {
            winston.info(`customObject.valueSet.valueSetting.. ${customObject.valueSet.valueSetting}`);
            let parentPicklist = customObject.valueSet.valueSettings;
            results = parentPicklist
              .filter((valueSetting) => {
                if (!valueSetting.isActive) {
                  return true;
                }
                return valueSetting.isActive !== "false";
              })
              .filter((valueSetting) => {
                return (
                  valueSetting.controllingFieldValue === args.parentPicklistValue
                  || valueSetting.controllingFieldValue.includes(args.parentPicklistValue)
                );
              })
              .map((valueSetting) => {
                return {
                  id: valueSetting.valueName || valueSetting.fullName,
                  label: valueSetting.valueName || valueSetting.label,
                };
              });
          } else {
            let picklist = customObject.valueSet.valueSetDefinition.value;

            results = picklist
              .filter(picklistValue => {
                if (!picklistValue.isActive) {
                  return true;
                }
                return picklistValue.isActive !== 'false';
              })
              .map(picklistValue => {
                return {
                  id: picklistValue.valueName || picklistValue.fullName,
                  label: picklistValue.valueName || picklistValue.label
                };
              });
          }
          break;
      }

      // Cache invalidates on default (1 day)
      if (results.length > 0) {
        await setEx(REDIS.SALESFORCE_API_CACHE, key, JSON.stringify(results));
        winston.info(`Successfully cached ${argsRaw}`);
      }
      return results;
    }

    winston.info(`Retrieving Salesforce picklist ${args.name} from cache`);
    let cachedValue = JSON.parse(cachedValueRaw);
    return cachedValue;
  } catch (error) {
    winston.error(error);
    throw error;
  }
};
