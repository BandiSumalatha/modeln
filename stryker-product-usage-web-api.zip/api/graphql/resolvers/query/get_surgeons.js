const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (root, { branchIds, searchText }, context) => {
  const currentUser = await context.currentUser(true);

  let userid = currentUser.sfids[0];
  if (currentUser.personas) {
    currentUser.personas.forEach(persona => {
      if (persona && (
        persona.toLowerCase().indexOf('in-house') !== -1
        || persona.toLowerCase().indexOf('csr') !== -1
        || persona.toLowerCase().indexOf('branch op') !== -1
      )) {        
        userid = 'ALL';
      }
    });
  }

  let query = herokuConnectClient
    .withSchema("repsuite")
    .select(herokuConnectClient.raw('surgeonid as "surgeonID"'), "surgeonName")
    .from("surgeons2_mv")
    .where("userid", userid);
  if (searchText) {
    query = query.where("surgeonName", "ilike", `%${searchText}%`);
  }

  const surgeons = await query;
  return surgeons || [];
};
