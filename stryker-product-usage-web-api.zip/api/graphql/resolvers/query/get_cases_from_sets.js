const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { set_id }, context) => {
  const cases = await herokuConnectClient
    .withSchema('salesforce')
    .select()
    .distinct([
      'c.sfid AS sfId',
      herokuConnectClient.raw(`COALESCE(c.name, 'Case ID TBD') as "caseId"`),
      'u.name AS salesRep',
      'a.name AS hospitalName',
      'c.surgery_start_date_time__c AS surgeryDate'
    ])
    .from('cases__c AS c')
    .innerJoin('account as a', 'c.hospitalid__c', 'a.sfid')
    .innerJoin('user AS u', 'c.kit_assigner__c', 'u.sfid')
    .innerJoin('surgical_case_products__c AS scpc', function() {
      this.on('c.sfid', '=', 'scpc.surgical_case__c')
        .orOn('c.external_id__c', '=', 'scpc.surgical_case__r__external_id__c')
        .andOn(herokuConnectClient.raw(`scpc.ipcid__c IS NULL`));
    })
    .leftJoin(
      'inventory_product_system__c AS ipsc',
      'scpc.ips_id__c',
      'ipsc.sfid'
    )
    .leftJoin('product_system__c AS ps', 'scpc.product_system__c', 'ps.sfid')
    .where('ipsc.sfid', set_id)
    .orWhere('ps.sfid', set_id);

  return cases || [];
};
