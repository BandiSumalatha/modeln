const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { user_sfid }, context) => {
  let notificationPrefs = await herokuConnectClient
    .withSchema('salesforce')
    .select()
    .from('repsuiteapp_settings__c')
    .where('user__c', user_sfid);

  return notificationPrefs[0] || {};
};
