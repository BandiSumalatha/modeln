const { UserFilter } = require('../../../models/UserFilter');

module.exports = async (_root, _args, context) => {
  const currentUser = await context.currentUser(false);
  let user_sfid = currentUser.sfids[0];

  const response = await UserFilter.find({
    user_sfid
  }).exec();

  if (response) for (var filter of response) {
    if (filter.definition && !filter.definition.surgery_date_confirmed && filter.definition.surgeryDateConfirmed) {
      filter.definition.surgery_date_confirmed = filter.definition.surgeryDateConfirmed;
    }
  }

  return response;
};
