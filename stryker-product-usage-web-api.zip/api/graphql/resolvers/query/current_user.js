const { verifyToken } = require('../../../services/jwt');
const { findUser } = require('../../../services/salesforce');
const storageExistCheck = require('../../../common/storageExist');

module.exports = async (root, { access_token }, context) => {
  const { upn } = await verifyToken(access_token);
  let user = await findUser(upn);
  const allowedPersona = process.env.ALLOWED_PERSONA
    ? process.env.ALLOWED_PERSONA.split(';')
    : ['Sales Rep'];
  if (
    user &&
    (user.divisions.includes('Joint Replacement') ||
      user.divisions.includes('Trauma')) &&
    allowedPersona.filter(value => user.personas.includes(value)).length > 0
  ) {
    user.storageExist = await storageExistCheck(user.sfids[0]);
    user.divisions = user.divisions.filter(
      division =>
        division.includes('Joint Replacement') || division.includes('Trauma')
    );

    user.screens = ['Cases', 'Calendar', 'Orders', 'SetLibrary'];
    return user;
  } else {
    throw new Error(`403`);
  }
};
