const { findUserPreferences } = require('../common/preferences');

module.exports = async (root, { userBranchId, filters }, context) => {
  const currentUser = await context.currentUser(true);
  return findUserPreferences(currentUser, filters, userBranchId);
};
