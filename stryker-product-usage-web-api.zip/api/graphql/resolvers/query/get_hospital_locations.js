const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { accountNo }, context) => {
  let query = herokuConnectClient
    .withSchema('salesforce')
    .select()
    .distinct(
      'address__c.address1__c as address1',
      'address__c.sfid as sfid',
      'address__c.oracle_site_number__c as siteNo',
      'address__c.primary_address_flag__c as primary',
      'address__c.subinv_name__c as inventoryName',
      'address__c.subinv_description__c as inventoryDescription'
    )
    .from('address__c')
    .innerJoin('account', function() {
      this.on('account.sfid', '=', 'address__c.account__c');
    })
    .where('address__c.type__c', 'Shipping')
    .andWhere('address__c.business_unit__c', '83')
   .andWhere(function() {
      this.where('address__c.status__c', 'A').orWhere(
        'address__c.status__c',
        'Active'
      );
    })
    .andWhere('account.accountnumber', accountNo);

  const hospitalLocations = await query;
  return hospitalLocations || [];
};
