const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { user_sfid }, context) => {
  const salesTeam = await herokuConnectClient
    .withSchema('salesforce')
    .select()
    .distinct('branchuserpod__c.podid__c as id', 'pod__c.name as label')
    .from('branchuserpod__c')
    .innerJoin('user', function() {
      this.on('branchuserpod__c.userid__c', '=', 'user.sfid');
    })
    .innerJoin('pod__c', function() {
      this.on('branchuserpod__c.podid__c', '=', 'pod__c.sfid');
    })
    .where(
      herokuConnectClient.raw(`branchuserpod__c.userid__c = ?`, [user_sfid])
    )
    .orderBy('pod__c.name', 'asc');

  return salesTeam || [];
};
