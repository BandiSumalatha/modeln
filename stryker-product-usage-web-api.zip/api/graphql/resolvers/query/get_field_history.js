const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { sfid, field_name, object_name }, context) => {
  const history = await herokuConnectClient
    .withSchema('salesforce')
    .select([
      'record_history__c.new_value__c as value',
      'record_history__c.old_value__c as old_value__c',
      'user.name as user_name',
      'record_history__c.update_time__c as updated_date'
    ])
    .from('record_history__c')
    .leftJoin('user', 'record_history__c.updated_by__c', 'user.sfid')
    .where(
      herokuConnectClient.raw(
        `record_history__c.changed_field__c = ? AND record_history__c.parent_object_type__c = ? AND record_history__c.caseid__c = ?`,
        [field_name, object_name, sfid]
      )
    )
    .orderBy('record_history__c.update_time__c', 'desc');
  return history;
};
