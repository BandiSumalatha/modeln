const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { externalRHSIds }, _context) => {
    if (!externalRHSIds || externalRHSIds.length === 0)
        return [];
        
    let tprs = await herokuConnectClient
        .withSchema("salesforce")
        .select([
        "tpr.sfid as tpr_sfid",
        "tpr.external_id__c as tpr_external_id",
        "tpr.external_tpr_id__c as tpr_id",
        "tpr.name as tpr_name",
        "cases__c.sfid as case_sfid",
        "cases__c.external_id__c as case_external_id",
        "cases__c.name as case_name",
        ])
        .from("cases__c")
        .innerJoin(
        "surgical_case_products__c AS product",
        "product.surgical_case__c",
        "cases__c.sfid"
        )
        .innerJoin(
        "treatment_plan_request__c AS tpr",
        "tpr.surgical_case_details__c",
        "product.sfid"
        )
        .whereIn("tpr.external_tpr_id__c", externalRHSIds);
    return tprs;
};
