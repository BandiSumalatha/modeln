const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (_root, { caseId }, _context) => {
  let tprList = await herokuConnectClient
    .withSchema("salesforce")
    .select([
      "tpr.sfid as sfid",
      "tpr.external_id__c as external_id",
      "tpr.external_tpr_id__c as tpr_id",
      "tpr.name as tpr_name",
      "tpr.status__c as tpr_status",
      "tpr.procedure__c as tpr_procedure",
      "tpr.surgery_date__c as surgery_date",
    ])
    .from("cases__c")
    .innerJoin(
      "surgical_case_products__c AS product",
      "product.surgical_case__c",
      "cases__c.sfid"
    )
    .innerJoin(
      "treatment_plan_request__c AS tpr",
      "tpr.surgical_case_details__c",
      "product.sfid"
    )
    .where("cases__c.sfid", caseId);
  return tprList || {};
};
