const { herokuConnectClient } = require('../../../services/knex');

module.exports = async (root, { caseid, case_external_id }, context) => {
  let sets = await herokuConnectClient
    .withSchema('salesforce')
    .select([
      'record_history__c.parent_name__c',
      'record_history__c.updated_by__c',
      'record_history__c.old_value__c',
      'record_history__c.name',
      'record_history__c.parent_record_id__c',
      'record_history__c.new_value__c',
      'record_history__c.changed_field__c',
      'record_history__c.parent_object_type__c'
    ])
    .from('record_history__c')
    .where('record_history__c.caseid__c', caseid)
    .orWhere('record_history__c.caseid__r__external_id__c', case_external_id);
  return sets || {};
};
