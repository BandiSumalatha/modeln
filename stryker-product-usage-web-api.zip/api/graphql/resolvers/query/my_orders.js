const { herokuConnectClient } = require('../../../services/knex');
const moment = require('moment');

module.exports = async (root, args, context) => {
  const currentUser = await context.currentUser(false);
  const user_sfid = currentUser.sfids[0];
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select(
      herokuConnectClient.raw(
        `COALESCE(cases__c.name, 'Case ID TBD') as "caseId"`
      ),
      'order.type AS orderType',
      'order.ordernumber AS orderNumber',
      herokuConnectClient.raw(
        `CONCAT (account.accountnumber, ' - ', account.name) AS "hospitalName"`
      ),
      herokuConnectClient.raw(
        `CONCAT (contact.surgeon_erp_code__c, ' - ', contact.name) AS "surgeonName"`
      ),
      herokuConnectClient.raw(
        `CONCAT (account.accountnumber, ' - ', account.name, ' ', contact.surgeon_erp_code__c, ' - ', contact.name) AS "hospitalSurgeonCombination"`
      ),
      'cases__c.cap_price__c AS capPrice',
      'cases__c.surgery_start_date_time__c AS surgeryDate',
      'order.submitted_date__c AS usageSubmittedDate',
      'order.order_entered_date__c AS erpCreatedDate',
      'order.order_number_oracle__c AS erpNumber',
      'order.status AS status',
      'order.integration_status__c AS integrationStatus',
      'order.ponumber as poNumber',
      'cases__c.po_uploaded__c AS poUploaded',
      'branch__c.name AS branch',
      'branch__c.sfid as branchSfId',
      'cases__c.external_id__c AS externalId',
      'cases__c.sfid AS sfid',
      'order.sfid AS orderSfid',
      'order.order_other_amount__c'
    )
    .from('order')
    .innerJoin('cases__c', function() {
      this.on('order.surgical_cases__c', '=', 'cases__c.sfid');
    })
    .innerJoin('account', function() {
      this.on('cases__c.hospitalid__c', '=', 'account.sfid');
    })
    .innerJoin('branch__c', function() {
      this.on('cases__c.branchid__c', '=', 'branch__c.sfid');
    })
    .leftOuterJoin('contact', function() {
      this.on('cases__c.hospital_staffid__c', '=', 'contact.sfid');
    })
    .where(herokuConnectClient.raw(`cases__c.kit_assigner__c = ?`, [user_sfid]))
    .orderBy('cases__c.surgery_start_date_time__c');

  let orders = await query;

  if (orders) {
    const orderSFIds = orders.map(order => order.orderSfid);
    const lineItems = await getLineItems(orderSFIds);
    orders.map(order => {
      const surgeryDate = moment(order.surgeryDate);
      order.surgeryDate = surgeryDate.toISOString();
      let erpOrderStatus = '';
      if (
        order.integrationStatus &&
        order.integrationStatus !== '' &&
        order.integrationStatus === 'Failed'
      ) {
        erpOrderStatus = 'Failed';
      } else {
        erpOrderStatus = order.status;
      }
      order.erpOrderStatus = erpOrderStatus;
      let orderTypeNumberCombination = '';
      switch (order.orderType) {
        case 'US ORTHO BILL ONLY AND ARO':
        case 'Bill Only':
        case 'US SPINE BILL ONLY AND ARO':
          orderTypeNumberCombination = 'BO-' + order.orderNumber;
          break;
        case 'US ORTHO SHIP&BILL':
        case 'US SPINE SHIP&BILL':
        case 'US Ortho Ship And Bill':
          orderTypeNumberCombination = 'SB-' + order.orderNumber;
          break;
        case 'US Ortho Consignment':
          orderTypeNumberCombination = 'CO-' + order.orderNumber;
          break;
        case 'US Ortho Domestic Instrument':
          orderTypeNumberCombination = 'DI-' + order.orderNumber;
          break;
        case 'Spine BO':
          orderTypeNumberCombination = 'C-' + order.orderNumber;
          break;
        case 'MAN':
          orderTypeNumberCombination = 'MAN-' + order.orderNumber;
          break;
        case 'CAP':
          orderTypeNumberCombination = 'CAP-' + order.orderNumber;
          break;
        case 'Do Not Bill/Replen':
          orderTypeNumberCombination = 'DNBR-' + order.orderNumber;
          break;
      }
      order.orderTypeNumberCombination = orderTypeNumberCombination;
      const fetchedLineItems = lineItems.filter(
        lineItem => lineItem.orderid === order.orderSfid
      );
      const billedAmount = fetchedLineItems.reduce((accumulator, lineItem) => {
        if (lineItem.rs_usg_total_amount__c) {
          accumulator += lineItem.rs_usg_total_amount__c;
        }
        return accumulator;
      }, 0);
      let orderOtherAmount = 0;
      if (order.order_other_amount__c) {
        orderOtherAmount = order.order_other_amount__c;
      }
      order.billedAmount = billedAmount + '/' + orderOtherAmount;
      return order;
    });
  }

  return orders || [];
};

const getLineItems = async orderSFIds => {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select('rs_usg_total_amount__c', 'orderid')
    .from('orderitem')
    .whereIn('orderid', orderSFIds);

  return await query;
};
