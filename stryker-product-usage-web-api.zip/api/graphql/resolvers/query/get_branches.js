const { getBranches } = require('../common/branches');

module.exports = async (root, { branchIds }, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  return await getBranches(user_sfid, branchIds);
};
