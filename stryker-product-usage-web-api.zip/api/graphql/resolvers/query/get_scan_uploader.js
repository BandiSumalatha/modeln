const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (root, { uploader }, context) => {
  try {
    let scanFacility = uploader.startsWith("ORTHO");
    if (scanFacility) {
      let uploaderName = await herokuConnectClient
        .withSchema("salesforce")
        .select()
        .distinct(["account.name as display_name"])
        .from("account")
        .where("account.customer_id__c", uploader);
      return uploaderName || {};
    } else {
      let uploaderName = await herokuConnectClient
        .withSchema("salesforce")
        .select()
        .distinct(["user.name as display_name"])
        .from("user")
        .where("user.federationidentifier", uploader);
      return uploaderName || {};
    }
  } catch (error) {
    throw error;
  }
};
