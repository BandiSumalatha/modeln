const { herokuConnectClient } = require('../../../services/knex');
const moment = require('moment');

const ROLE_CASES = {
  MY_CASES: 'My Cases',
  COVERING_CASES: 'Covering Cases',
  TEAM_CASES: 'Team Cases',
  BRANCH_CASES: 'Branch Cases'
};

module.exports = async (root, { filters }, context) => {
  const currentUser = await context.currentUser(true);
  const user_sfid = currentUser.sfids[0];
  const {
    status,
    division,
    role,
    filterHospital,
    filterSurgeon,
    filterBranch,
    filterSalesRep,
    startDate,
    endDate,
    filterSalesTeam,
    isWebOpsError,
    procedure,
    timezoneOffset
  } = filters || {};
  const offset = timezoneOffset ? -timezoneOffset : 0;
  const { divisions, branchIds } = currentUser || {};
  try {
    let query = herokuConnectClient
      .withSchema('salesforce')
      .select(
        herokuConnectClient.raw(
          `to_char(cases__c.surgery_start_date_time__c + interval '${offset} minutes', 'YYYY-MM-dd') as "surgeryDate"`
        ),
        'cases__c.status__c as status'
      )
      .count('cases__c.id as count')
      .from('cases__c')
      .innerJoin('account', 'cases__c.hospitalid__c', 'account.sfid')
      .innerJoin('branch__c', 'cases__c.branchid__c', 'branch__c.sfid')
      .leftJoin('user', 'cases__c.kit_assigner__c', 'user.sfid')
      .leftOuterJoin('contact', 'cases__c.hospital_staffid__c', 'contact.sfid')
      .where(
        herokuConnectClient.raw(`"cases__c"."non_usage_orders__c" IS NOT TRUE`)
      )      
      .groupBy('surgeryDate', 'cases__c.status__c')
      .orderBy('surgeryDate');

    if (branchIds && branchIds.length <= 20) {
      query.whereRaw(`cases__c.branchid__c in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`)
    }

    // Filters
    if (division) {
      query.where('cases__c.division__c', '=', division);
    } else {
      query.whereIn('cases__c.division__c', divisions);
    }
    if (status) {
      query.whereIn("cases__c.status__c", status.split(','));
    } else {
      query.where(function() {
        this.whereNot('cases__c.status__c', 'Cancelled').andWhereNot(
          'cases__c.status__c',
          'Completed'
        );
      });
    }
    if (filterBranch) {
      query.andWhere(function() {
        this
          .where('branch__c.sfid', filterBranch)
          .orWhere('cases__c.region_filter__c', filterBranch);
      });
    }
    if (filterSurgeon) {
      query.where('contact.sfid', filterSurgeon);
    }
    if (filterHospital) {
      query.where('account.sfid', filterHospital);
    }
    if (procedure) {
      query
        .where('cases__c.procedureid__c', procedure);
    }
    if (filterSalesTeam) {
      query.whereRaw(`"cases__c"."kit_assigner__c" in (select userid__c from
        "salesforce"."branchuserpod__c" where podid__c = '${filterSalesTeam}')
        AND "cases__c"."branchid__c" in (${"branch__c.sfid"})`);
    }
    if (filterSalesRep) {
      query.where('user.sfid', filterSalesRep);
    }
    if (startDate) {
      query.whereRaw(
        `date(cases__c.surgery_start_date_time__c + interval '${offset} minutes') >= '${startDate}'`
      );
    }
    if (endDate) {
      query.whereRaw(
        `date(cases__c.surgery_start_date_time__c + interval '${offset} minutes') <= '${endDate}'`
      );
    }
    if (isWebOpsError) {
      query.where(function() {
        this.where('cases__c.webops_completed_status__c', 'Failed')
          .orWhere('cases__c.webops_create_status__c', 'Failed')
          .orWhere('cases__c.webops_requested_status__c', 'Failed')
          .orWhere('cases__c.webops_integration_status__c', 'Failed');
      });
    }
    switch (role) {
      case ROLE_CASES.COVERING_CASES: {
        query
          .innerJoin('surgical_case_sales_team__c as coveringteam', function() {
            this.on(
              'cases__c.sfid',
              '=',
              'coveringteam.surgical_cases__c'
            ).orOn(
              'cases__c.external_id__c',
              '=',
              'coveringteam.surgical_cases__r__external_id__c'
            );
          })
          .where('coveringteam.sales_rep__c', user_sfid);
        break;
      }
      case ROLE_CASES.MY_CASES: {
        query.where('cases__c.kit_assigner__c', user_sfid);
        break;
      }
      case ROLE_CASES.BRANCH_CASES: {
        const branchIds = currentUser.branchIds;
        query.whereRaw(`cases__c.branchid__c in (VALUES ${branchIds.map(x => "('" + x + "')").join(',')})`);
        break;
      }
      case ROLE_CASES.TEAM_CASES: {
        const teammate_sfids = currentUser.teammate_sfids;
        if (teammate_sfids) {
          query.andWhere(function() {
            this.whereExists(function() {
              this.select(1)
                .from('surgical_case_sales_team__c')
                .whereRaw(
                  `cases__c.sfid = surgical_case_sales_team__c.surgical_cases__c`
                )
                .whereIn(
                  'surgical_case_sales_team__c.sales_rep__c',
                  teammate_sfids
                );
            })
              .orWhereExists(function() {
                this.select(1)
                  .from('surgical_case_sales_team__c')
                  .whereRaw(
                    `cases__c.external_id__c = surgical_case_sales_team__c.surgical_cases__r__external_id__c`
                  )
                  .whereIn(
                    'surgical_case_sales_team__c.sales_rep__c',
                    teammate_sfids
                  );
              })
              .orWhereIn('cases__c.kit_assigner__c', teammate_sfids);
          });
        }
        break;
      }
    }
    const myCases = await query;
    return myCases;
  } catch (ex) {
    console.log(ex);
    return [];
  }
};
