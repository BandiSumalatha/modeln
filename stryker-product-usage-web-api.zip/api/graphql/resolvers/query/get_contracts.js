const { herokuConnectClient } = require('../../../services/knex');
module.exports = async (root, { hospital_id, date, division }, context) => {
  const currentUser = await context.currentUser(false);
  date = !date ? new Date() : date;

  if (!division) {
    division =
      currentUser.divisions && currentUser.divisions.length > 0
        ? currentUser.divisions[0]
        : '';
  }
  const { secrets } = context;
  const nonSpineOrgId = secrets.ORACLE_OTHER_ORG_ID;
  const spineOrgId = secrets.ORACLE_SPINE_ORG_ID;
  const OrgUnitID =
    division && division === 'Spine' ? spineOrgId : nonSpineOrgId;

  let query = herokuConnectClient
    .withSchema('salesforce')
    .select(
      'c.accountid as accountId',
      'c.comments__c as comments',
      'c.contractnumber as contractNumber',
      'c.contract_end_date__c as contractEndDate',
      'c.contract_start_date__c as contractStartDate',
      'c.accountcontract_start_date__c as accountContractStartDate',
      'c.accountcontract_end_date__c as accountContractEndDate',
      'c.description as description',
      'c.enddate as endDate',
      'c.sfid as sfid',
      'c.id as id',
      'c.name as name',
      'c.sfid as priceListHeaderId',
      'c.startdate as startDate',
      'c.status as status'
    )
    .from('contract as c')
    .innerJoin('account as a', 'c.accountid', 'a.sfid')
    .where('c.status', 'Draft')
    .where('c.contract_start_date__c', '<=', date)
    .where(function () {
      this.where('c.contract_end_date__c', '>=', date).orWhere(
        'c.contract_end_date__c',
        null
      );
    })
    .where(function () {
      this.where('c.accountcontract_start_date__c', '<=', date).orWhere(
        'c.accountcontract_start_date__c',
        null
      );
    })
    .where(function () {
      this.where('c.accountcontract_end_date__c', '>=', date).orWhere(
        'c.accountcontract_end_date__c',
        null
      );
    })
    .where('c.business_unit__c', OrgUnitID)
    .whereNotNull('c.pricelist_header_id__c')
    .where(function () {
      this.where('a.sfid', hospital_id).orWhere(function () {
        this.where('a.name', 'like', '%Default%').where(
          'c.external_integration_id__c',
          'like',
          '|%'
        );
      });
    })
    .orderBy('c.name');

  let contracts = await query;
  return contracts || [];
};
