const { herokuConnectClient } = require("../../../services/knex");

module.exports = async (
    _root, 
    { sfid, externalId, searchText }, 
    _context
) => {
    // you *must* specify a case ID
    if (!sfid && !externalId) {
      return [];
    }

    let query = herokuConnectClient
      .withSchema('repsuite')
      .select(
        'set_id',
        'set_name',
        'kit_no__c',
        'surgery_date__c AS Surgery_date__c',
        'case_number__c AS Case_Number__c',
        'status__c AS Status__c',
        'category__c AS Category__c',
        'inventory_type',
        'label',
        'product_sfid',
        'part_id',
        'productoracleid AS productOracleId',
        'gtin',
        'catalog_number',
        'lot_serial_control_code__c',
        'part_name',
        'part_desc',
        herokuConnectClient.raw(
          `CASE WHEN (lot_serial_control_code__c = '2')
            THEN true
            ELSE false END
          AS is_lot_controlled`
        )
      )
      .from('consignmentsets');

    if (searchText) {
        query = query.where(function() {
            this
              .where('part_name', 'ilike', `%${searchText}%`)
              .orWhere('part_desc', 'ilike', `%${searchText}%`);
        });
    }

    if (sfid && externalId) {
        query = query.where(function() {
            this
              .where('case_sfid', sfid)
              .orWhere('case_external_id', externalId)
        });
    }
    else if (sfid) {
        query = query.where('case_sfid', sfid);
    }
    else if (externalId) {
        query = query.where('case_external_id', externalId);
    }
    
    return await query;
  }