const transformSurveyResponse = surveyResponse => {
  return Object.assign(
    {},
    {
      id: surveyResponse.survey_id,
      submission_date__c: surveyResponse.submission_date,
      status__c: surveyResponse.status,
      responses__c: surveyResponse.responses
    }
  );
};

const transformSurvey = survey => {};

module.exports = {
  transformSurveyResponse,
  transformSurvey
};
