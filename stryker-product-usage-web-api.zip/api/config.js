const joi = require('joi');

const envVarsSchema = joi
  .object({
    // TODO: Validate these a little more properly than just strings and numbers
    RATE_LIMIT_REQUESTS_PER_MINUTE: joi
      .number()
      .integer()
      .required(),
    RATE_LIMIT_MINUTES_TILL_RESET: joi
      .number()
      .integer()
      .required(),
    DATABASE_URL: joi.string().required(),
    REDIS_URL: joi.string().required(),
    JWT_SECRET: joi.string().required(),
    AUTH_SAML_ENABLED: joi.boolean().required(),
    POSTGRES_LOGGING: joi.string().required(),
    RECREATE_SCHEMA: joi.string().required(),
    MONGODB_URI: joi.string().required(),
    MONGODB_PREFIX: joi.string(),
    SEED_TRANSLATIONS: joi.boolean().required(),
    CACHE_EXPIRES_IN: joi
      .number()
      .integer()
      .required(),
    CACHE_REFRESH_SCHEDULE: joi.string(),

    // SPA build variables
    REACT_APP_GRAPHQL_HTTP_URI: joi.string().required(),
    REACT_APP_GRAPHQL_WS_URI: joi.string().required(),

    // jsForce OAuth2 flow
    SALESFORCE_CONSUMER_KEY: joi.string().required(),
    SALESFORCE_CONSUMER_SECRET: joi.string().required(),
    SALESFORCE_REDIRECT_URI: joi.string().required(),
    SALESFORCE_LOGIN_URL: joi.string().required(),

    OAUTH_AUTHORIZATION_URL: joi.string().required(),
    OAUTH_TOKEN_URL: joi.string().required(),
    OAUTH_JWKS_URL: joi.string().required(),
    OAUTH_CLIENT_ID: joi.string().required(),
    OAUTH_CLIENT_SECRET: joi.string().required(),
    OAUTH_CODE_SCOPE: joi.string().required(),
    OAUTH_LOGIN_TOKEN_SCOPE: joi.string().required(),
    OAUTH_CALLBACK_URL: joi.string().required(),
    OAUTH_RHS_SCOPE: joi.string().required(),
    OAUTH_RHS_MAKO_SCOPE: joi.string().required(),
    OAUTH_RHS_MAKO_CLIENT_ID: joi.string().required(),
    OAUTH_RHS_MAKO_CLIENT_SECRET: joi.string().required(),
    OAUTH_RHS_AS1_SCOPE: joi.string().required(),
    OAUTH_RHS_AS1_CLIENT_ID: joi.string().required(),
    OAUTH_RHS_AS1_CLIENT_SECRET: joi.string().required(),

    CANVAS_SALESFORCE_URL: joi.string().required(),
    CANVAS_CLIENT_ID: joi.string().required(),
    CANVAS_CALLBACK: joi.string().required(),
    CANVAS_CLIENT_SECRET: joi.string().required(),
    CANVAS_REDIRECT_URL: joi.string().required(),
    SUPPORTED_APP_VERSION: joi.string()
  })
  .unknown()
  .required();

const { error } = joi.validate(process.env, envVarsSchema);
if (error) {
  throw new Error(`Missing environment variables detected! ${error.message}`);
}

const port = process.env.PORT || 3001;
const isLocalDevelopment = port === 3001;

const ENVIRONMENT = {
  IS_PRODUCTION: process.env.NODE_ENV === 'production',
  IS_TRACE_ENABLED: process.env.TRACE_ENABLED === 'true',
  IS_LOCAL_DEVELOPMENT: isLocalDevelopment,
  SALT_ROUNDS: parseInt(process.env.SALT_ROUNDS),
  REDIS_URL: process.env.REDIS_URL,
  REDIS_SUBSCRIPTIONS_URL: process.env.REDIS_SUBSCRIPTIONS_URL,
  PORT: port,
  WS_PORT: isLocalDevelopment ? process.env.WS_PORT : process.env.PORT,
  JWT_SECRET: process.env.JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN,
  LOCAL_WEBCLIENT_ROOT: `http://localhost:3001`,
  DISABLE_AUTH: process.env.DISABLE_AUTH === 'true',
  CACHE_EXPIRES_IN: process.env.CACHE_EXPIRES_IN || 24 * 3600,
  CACHE_REFRESH_SCHEDULE: process.env.CACHE_REFRESH_SCHEDULE || '0 0 * * *',
  LOADERIO_VERIFICATION: process.env.LOADERIO_VERIFICATION || null,
  SUPPORTED_APP_VERSION: process.env.SUPPORTED_APP_VERSION || '0.0.0'
};

const POSTGRES = {
  DATABASE_URL: process.env.DATABASE_URL,
  POSTGRES_LOGGING: process.env.POSTGRES_LOGGING,
  SCHEMA: process.env.POSTGRES_SCHEMA,
  RECREATE_SCHEMA: process.env.RECREATE_SCHEMA === 'true'
};

const HEROKU_CONNECT = {
  DATABASE_URL: process.env.DATABASE_URL
};

const MONGODB = {
  URI: process.env.MONGODB_URI,
  RECREATE_SCHEMA: process.env.RECREATE_SCHEMA === 'true',
  PREFIX: process.env.MONGODB_PREFIX || ""
};

const RATE_LIMITS = {
  REQUESTS_PER_MINUTE: parseInt(process.env.RATE_LIMIT_REQUESTS_PER_MINUTE),
  MINUTES_TILL_RESET: parseInt(process.env.RATE_LIMIT_MINUTES_TILL_RESET)
};

const REDIS = {
  URL: process.env.REDIS_URL,
  RATE_LIMITER_DB: 0,
  REFRESH_TOKENS_DB: 1,
  SALESFORCE_API_CACHE: 2,
  PARTS_SCHEDULER_CACHE: 3,
  LAST_SCHEDULER_RUN: 'last_run_scheduler',
  SALESFORCE_OAUTH_CREDENTIALS: `salesforce:oauth:credentials`
};

const AMQP = {
  CLOUDAMQP_URL: process.env.CLOUDAMQP_URL,
  IMAGE_SYNC: process.env.IMAGE_SYNC || 'SYK:IMAGE_SYNC',
  DELETE_ATTACHMENT: process.env.DELETE_ATTACHMENT || 'SYK:DELETE_ATTACHMENT',
  THUMBNAIL_CREATION_TASK:
    process.env.THUMBNAIL_CREATION_TASK || 'SYK:THUMBNAIL_CREATION_TASK',
  BUILD_CACHE: 'SYK:BUILD_CACHE',
  SETS_COMPLETE: 'SYK:SETS_COMPLETE'
};

const SALESFORCE = {
  CONSUMER_KEY: process.env.SALESFORCE_CONSUMER_KEY,
  CONSUMER_SECRET: process.env.SALESFORCE_CONSUMER_SECRET,
  REDIRECT_URI: process.env.SALESFORCE_REDIRECT_URI,
  LOGIN_URL: process.env.SALESFORCE_LOGIN_URL
};

const CASES_QUERY_DAY_RANGE = process.env.CASES_QUERY_DAY_RANGE;

const AZURE = {
  CONNECTION_STRING: process.env.AZURE_STORAGE_CONNECTION_STRING,
  IMAGE_CONTAINER_NAME: process.env.AZURE_IMAGE_CONTAINER_NAME,
  CACHE_CONTAINER_NAME: process.env.AZURE_CACHE_CONTAINER_NAME,
  BASE_UPLOAD_URL: process.env.AZURE_IMAGE_URL
};

const OAUTH = {
  AUTHORIZATION_URL: process.env.OAUTH_AUTHORIZATION_URL,
  TOKEN_URL: process.env.OAUTH_TOKEN_URL,
  JWKS_URL: process.env.OAUTH_JWKS_URL,
  CALLBACK_URL: process.env.OAUTH_CALLBACK_URL,
  CODE_SCOPE: process.env.OAUTH_CODE_SCOPE,
  TOKEN_SCOPE: process.env.OAUTH_LOGIN_TOKEN_SCOPE,
  CLIENT_ID: process.env.OAUTH_CLIENT_ID,
  CLIENT_SECRET: process.env.OAUTH_CLIENT_SECRET,
  RHS: {
    SCOPE: process.env.OAUTH_RHS_SCOPE,
    MAKO: {
      SCOPE: process.env.OAUTH_RHS_MAKO_SCOPE,
      CLIENT_ID: process.env.OAUTH_RHS_MAKO_CLIENT_ID,
      CLIENT_SECRET: process.env.OAUTH_RHS_MAKO_CLIENT_SECRET
    },
    AS1: {
      SCOPE: process.env.OAUTH_RHS_AS1_SCOPE,
      CLIENT_ID: process.env.OAUTH_RHS_AS1_CLIENT_ID,
      CLIENT_SECRET: process.env.OAUTH_RHS_AS1_CLIENT_SECRET
    }
  }
}

const CANVAS = {
  SALESFORCE_URL: process.env.CANVAS_SALESFORCE_URL, // TODO: switch this to SALESFORCE.LOGIN_URL after SIT setup with canvas app
  CLIENT_ID: process.env.CANVAS_CLIENT_ID,
  CALLBACK: process.env.CANVAS_CALLBACK,
  CLIENT_SECRET: process.env.CANVAS_CLIENT_SECRET,
  REDIRECT_URL: process.env.CANVAS_REDIRECT_URL
}

module.exports = {
  ENVIRONMENT,
  RATE_LIMITS,
  REDIS,
  POSTGRES,
  MONGODB,
  HEROKU_CONNECT,
  SALESFORCE,
  CASES_QUERY_DAY_RANGE,
  AMQP,
  AZURE,
  OAUTH,
  CANVAS
};
