const newrelic = require('newrelic');
const { graphqlExpress, graphiqlExpress } = require('apollo-server-express');
const SwaggerExpress = require('swagger-express-mw');
const winston = require('winston');
const bodyParser = require('body-parser');
const Promise = require('bluebird');
const path = require('path');
const multer = require('multer');
const connectToPassport = require('./middleware/passport');
const connectToCanvas = require('./middleware/canvas');
const cors = require('cors');
const models = require('./models');
const helmet = require('helmet');
const withAuth = require('./middleware/withAuth');
const { assign } = require('lodash');
const { SalesforceServerAuth } = require('./middleware/salesforce');
const { addCacheFlush } = require('./middleware/cache');
const Schema = require('./graphql/schema');

const { redisClient } = require('./services/redis');
const { ENVIRONMENT, RATE_LIMITS, REDIS } = require('./config');
const jwtService = require('./services/jwt');
const { findUser, findUserShort } = require('./services/salesforce');
const compression = require('compression');

const mustacheExpress = require('mustache-express');

Promise.promisifyAll(SwaggerExpress);

module.exports = api;

const loggingPlugin = {

  // Fires whenever a GraphQL request is received from a client.
  requestDidStart(requestContext) {
    console.log('GraphQL Query: ' +
      requestContext.request.query);

    return {

      // Fires whenever Apollo Server will parse a GraphQL
      // request to create its associated document AST.
      parsingDidStart(requestContext) {
        console.log('Parsing started!');
      },

      // Fires whenever Apollo Server will validate a
      // request's document AST against your GraphQL schema.
      validationDidStart(requestContext) {
        console.log('Validation started!');
      },

    }
  },
};

let config = {
  appRoot: path.join(__dirname, '..'),
  configDir: path.join(__dirname, './config'),
  swaggerSecurityHandlers: {
    Bearer: async function(req, authOrSecDef, scopesOrApiKey, next) {
      try {
        newrelic.setTransactionName(req.path);
        // Bypass auth locally for easier debugging of REST Api
        if (ENVIRONMENT.DISABLE_AUTH) {
          return next();
        }
        const tokenRaw = req.headers['authorization'] || '';
        let token = tokenRaw.replace('Bearer ', '');
        if (token && token !== '') {
          let decoded = await jwtService.verifyToken(token);
          let { upn } = decoded;
          if (!upn) {
            throw new Error(`Invalid token detected`);
          }
          req.currentUsername = upn;
          return next();
        }
        throw new Error(`Authentication token missing`);
      } catch (error) {
        winston.error(`Authentication failure: ${JSON.stringify(error)}`);
        return req.res
          .status(401)
          .json({ message: `Unauthorized access detected` });
      }
    }
  }
};

async function api(app) {
  const limiter = require('express-limiter')(app, redisClient);
  limiter({
    path: '*',
    method: 'all',
    lookup: ['connection.remoteAddress'],
    total: RATE_LIMITS.REQUESTS_PER_MINUTE * RATE_LIMITS.MINUTES_TILL_RESET,
    expire: 1000 * 60 * RATE_LIMITS.MINUTES_TILL_RESET
  });
  app.engine('mustache', mustacheExpress());
  app.set('view engine', 'mustache');
  app.set('views', __dirname + '/../views');
  app.use(helmet());
  app.use(bodyParser.urlencoded({ extended: false }));
  app.use(bodyParser.json());
  app.use(cors());
  app.use(compression());
  app.use(helmet.noCache({ noEtag: true }));

  // GraphQL Boilerplate follows
  const schemaFunction =
    Schema.schemaFunction ||
    function() {
      return Schema.schema;
    };
  let schema;
  const rootFunction =
    Schema.rootFunction ||
    function() {
      return schema.rootValue;
    };
  const contextFunction =
    Schema.context ||
    function(headers, secrets) {
      return Object.assign(
        {
          headers: headers
        },
        secrets
      );
    };

  app.use(
    '/api',
    bodyParser.json(),
    withAuth(
      graphqlExpress(async request => {
        const tokenRaw = request.headers['authorization'] || '';
        let token = tokenRaw.replace('Bearer ', '');
        let currentUser;
        if (token && token !== '') {
          let decoded = null;
          try {
            decoded = await jwtService.verifyToken(token);
          } 
          catch(e) {
            // JWT may be invalid if calling refreshJwt
          }
          
          if (decoded) {
            currentUser = ((email) => {
              let full = null;
              let partial = null; 
              return async (needfull) => {
                if (full) return full;
                else if (needfull) {
                  full = findUser(email);
                  return full;
                }
                else if (partial) return partial;
                partial = findUserShort(email);
                return partial;
              } })(decoded.upn);
          }
          else {
            currentUser = async (needfull) => { return null; };
          }
        }
        if (!schema) {
          schema = schemaFunction(process.env);
        }
        const context = await contextFunction(request.headers, process.env);
        const rootValue = await rootFunction(request.headers, process.env);
        const uid = (Date.now() + Math.random()).toString(36);

        let q = request.body.query;
        q = q ? q.split('\n')[0] : 'unknown';
        newrelic.setTransactionName(q);
        winston.log('info', `graphql.operation ${uid} ${q} started`);

        return {
          schema: await schema,
          rootValue,
          context: {
            ...context,
            currentUser,
            startTime: process.hrtime()
          },
          tracing: !ENVIRONMENT.IS_PRODUCTION || ENVIRONMENT.IS_TRACE_ENABLED,
          formatResponse: (response, graphqlContext) => {
            let timeDiff = process.hrtime(graphqlContext.context.startTime);
            timeDiff = (timeDiff[0] * 1e9 + timeDiff[1])/1e6;
            console.log(`measure#graphql.operation${graphqlContext.operationName}=${timeDiff}ms`);
            winston.log('info', `graphql.operation ${graphqlContext.operationName} ${timeDiff}ms`);
            return response;
          }
        };
      })
    )
  );

  app.use(
    '/__/explorer',
    graphiqlExpress({
      endpointURL: '/api',
      subscriptionsEndpoint: !ENVIRONMENT.IS_PRODUCTION
        ? `ws://localhost:${ENVIRONMENT.WS_PORT}/`
        : ENVIRONMENT.WS_URI,
      query: ``
    })
  );

  app = connectToPassport(SalesforceServerAuth(app));
  app = connectToCanvas(app);
  addCacheFlush(app);

  // Swagger is for SurveyJS support only. All other domain-related calls must go through GQL.
  const swaggerExpress = await SwaggerExpress.createAsync(config);

  app.use([
    multer({
      storage: multer.memoryStorage(),
      limits: { fieldSize: 25 * 1024 * 1024 }
    }).array('file'),
    (req, res, next) => {
      next();
    }
  ]);
  swaggerExpress.register(app);

  if (ENVIRONMENT.LOADERIO_VERIFICATION) {
    app.use(`/loaderio-${ENVIRONMENT.LOADERIO_VERIFICATION}.txt`, function(
      req,
      res,
      next
    ) {
      res.send(`loaderio-${ENVIRONMENT.LOADERIO_VERIFICATION}`);
    });
  }

  await models.Migrations.MigrateTranslations();
  await models.Migrations.MigrateCaseImage();
  return app;
}
