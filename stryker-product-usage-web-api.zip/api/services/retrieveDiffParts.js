const { herokuConnectClient } = require('../services/knex');
const { cache } = require('../services/CacheService');

module.exports = {
  retrieveDiffParts
};

// query to get parts from database on the basis of isFullDownload & lastSyncDate
async function retrieveDiffParts(isFullDownload, lastSyncDate) {
  const query = herokuConnectClient
    .withSchema('repsuite')
    .select(
      'parts.part_name',
      'parts.product_sfid',
      'part_desc',
      'lot_serial_control_code__c',
      herokuConnectClient.raw(
        `CASE WHEN (lot_serial_control_code__c = '2')
        THEN true
        ELSE false END
        AS is_lot_controlled`),
      'productOracleId',
      'partsearch__c',
      'part_search_withouthyphen__c',
      'parts.pricebookName',
      'gtin',
      'catalog_number',
      'is_deleted'
    )
    .from('parts')
    .leftJoin(
      'parts_tracker',
      'parts.product_sfid',
      'parts_tracker.product_sfid'
    );
  if (isFullDownload) {
    // getting all parts and saving to cache
    query
      .where('parts_tracker.is_deleted', false)
      .orWhere('parts_tracker.is_deleted', null);
  } else {
    query.where('parts_tracker.last_modified', '>', lastSyncDate);
  }

  const data = new Promise((resolve, reject) => { convertToJson(query, resolve, reject) });

  return `{
    "data": [${await data}],
    "lastsyncdate": ${isFullDownload ? Date.now().valueOf() : lastSyncDate.valueOf()},
    "isFullDownload": ${isFullDownload}
  }`;
}

function convertToJson(query, resolve, reject) {
  const stream = query.stream();
  let data = [];
  let json = '';

  stream.on('data', function(chunk) {
    data.push(chunk);
    if (data.length == 100) {
      let parsed = JSON.stringify(data);
      parsed = parsed.substring(1);
      parsed = parsed.substring(0, parsed.length-1);
      json += ',' + parsed;
      data = [];
    }
  });
 
  stream.on('end',function() {
    if (data.length>0) {
      let parsed = JSON.stringify(data);
      parsed = parsed.substring(1);
      parsed = parsed.substring(0, parsed.length-1);
      json += ',' + parsed;
    }
    resolve(json.substring(1));
  });
 
  stream.on('error', function(err) {
    console.log(err.stack);
    reject(err);
  });
}
