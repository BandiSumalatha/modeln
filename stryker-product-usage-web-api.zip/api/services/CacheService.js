const cacheManager = require('cache-manager');
const fsStore = require('cache-manager-fs-hash');
const { EventEmitter } = require('events');
const { ENVIRONMENT } = require('../config');

async function _get(key) {
  try {
    return this.cache.get(key);
  }
  catch(err) {
    console.log(err);
  }
}

function _set(key, results) {
  this.cache.set(key, results);
}

function _lock() {
  let locked = {};
  const ee = new EventEmitter();
  ee.setMaxListeners(0);

  return {
    acquire: key =>
      new Promise(resolve => {
        if (!locked[key]) {
          locked[key] = true;
          return resolve();
        }
        
        const tryAcquire = value => {
          if (!locked[key]) {
            locked[key] = true;
            ee.removeListener(key, tryAcquire);
            return resolve(value);
          }
        };
        
        ee.on(key, tryAcquire);
      }),

    // If we pass a value, on release this value
    // will be propagated to all the code that's waiting for
    // the lock to release
    release: (key, value) => {
      Reflect.deleteProperty(locked, key);
      setImmediate(() => ee.emit(key, value));
    },
  };
}

class Cache {
  constructor(name, ttlSeconds) {
    this.cache = cacheManager.caching({
      store: fsStore,
      options: {
          ttl: ttlSeconds,
          path: name,
          subdirs: false,
          zip: false
      }
    });
    this.lock = _lock();
  }

  async getOrUpdate(key, generator) {
    let get = _get.bind(this);
    let set = _set.bind(this);

    let value = await get(key);
    if (!value) {
      value = await this.lock.acquire(key);
      try {
        if (!value) {
          value = await generator();
          await set(key, value);
        }
      } catch (err) {
        console.log(err);
      } finally {
        this.lock.release(key, value);
      }
    }
    return value;
  }

  async set(key, results) {
    await this.lock.acquire(key);
    try {
      await this.cache.set(key, results);
      this.lock.release(key, results);
    }
    finally {
      console.log(`Cache store ${key}`);
    }
  }

  async flush() {
    await this.cache.reset();
  }
}

const cache = new Cache('diskcache', ENVIRONMENT.CACHE_EXPIRES_IN);
const procedureCache = new Cache('procedurecache', ENVIRONMENT.CACHE_EXPIRES_IN);
const shortTermCache = new Cache('shortcache', 5 * 60);

module.exports = {
  cache,
  procedureCache,
  shortTermCache
};
