const { SalesforceOAuth2 } = require('../middleware/salesforce');
const { get, set } = require('./redis');
const { REDIS } = require('../config');
const jsforce = require('jsforce');

module.exports = {
  getConnection
};

function getConnection() {
  return new Promise(async (resolve, reject) => {
    let credentialsRaw = await get(
      REDIS.SALESFORCE_API_CACHE,
      REDIS.SALESFORCE_OAUTH_CREDENTIALS
    );
    if (!credentialsRaw) {
      return reject(
        new Error(`Please initiate server-side authentication for Salesforce`)
      );
    }
    let credentials = JSON.parse(credentialsRaw);
    let { instanceUrl, accessToken, refreshToken } = credentials;
    let conn = new jsforce.Connection({
      oauth2: SalesforceOAuth2,
      instanceUrl,
      accessToken,
      refreshToken
    });

    // Update local cache of credentials so we can use this again
    conn.on('refresh', (newAccessToken, res) => {
      let credentials = {
        accessToken: newAccessToken,
        refreshToken,
        instanceUrl
      };

      set(
        REDIS.SALESFORCE_API_CACHE,
        REDIS.SALESFORCE_OAUTH_CREDENTIALS,
        JSON.stringify(credentials)
      );
    });

    return resolve(conn);
  });
}
