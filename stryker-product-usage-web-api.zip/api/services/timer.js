class Timer {
    constructor(timerName, timeout) {
        this.timerName = timerName;
        this.timeout = timeout;
        this.startTime = null;
        this.stopped = false;
        this.timeoutTimer = null;
    }

    async timedout(timerName, timer) {
        console.log(`ERROR: timeout#${timerName}`);
        await timer.stop();
    }

    async start() {
        this.startTime = Date.now();
        if (this.timeout) {
            this.timeoutTimer = setTimeout(this.timedout, this.timeout, this.timerName, this);
        }
    }

    async stop() {
        if (!this.stopped) {
            if (this.timeoutTimer) {
                clearTimeout(this.timeoutTimer);
            }
            this.stopped = true;
            let timing = Date.now() - this.startTime;
            console.log(`measure#${this.timerName}=${timing}ms`);
        }
    }
}

const defaultTimeout = 30000;

module.exports = {
    Timer,
    defaultTimeout
}