jest.mock('./knex', () => {
  const knex = require('knex');
  const mockDb = require('mock-knex');
  const db = knex({
    useNullAsDefault: true,
    client: 'sqlite'
  });
  mockDb.mock(db);
  return {
    herokuConnectClient: db
  };
});

jest.mock('../config', () => ({
  RATE_LIMIT_REQUESTS_PER_MINUTE: 120,
  HEROKU_CONNECT: {
    DATABASE_URL: 'test'
  }
}));

const salesforceService = require('./salesforce');

describe('/services/salesforce', () => {
  it('should sanitize query params before querying Salesforce tables', async () => {
    const queryParams = {
      text_field: 'description__c',
      value_field: 'sfid',
      related_sfid: '12345',
      category: 'some_category'
    };
    let sanitizedQuery = salesforceService.sanitizeSalesforceQuery(queryParams);
    expect(Object.keys(sanitizedQuery).length).toBe(2);
    expect(sanitizedQuery).toHaveProperty('related_sfid', '12345');
    expect(sanitizedQuery).toHaveProperty('category', 'some_category');
  });

  it(`find Salesforce objects from an array of URL's and query appropriately`, async () => {
    let urls = [
      'http://some-api/choices/Account__c?sfid=12345&text_field=name&value_field=sfid',
      'http://some-api/choices/Contact__c?sfid=12345&text_field=name&value_field=sfid',
      'http://some-api/choices/Custom_Object__c?sfid=12345&text_field=name&value_field=sfid'
    ];

    let queries = salesforceService.parseSFObjects(urls);
    let processedQueries = await Promise.all(queries);
    expect(processedQueries.length).toBe(urls.length);
  });

  it(`determine a Salesforce object from a given path`, () => {
    let sfObjectName = 'Custom_Object__c';
    let sfObject = salesforceService.getSFObjectNameFromPath(
      `https://some-api/choices/${sfObjectName}`
    );
    expect(sfObject).toBe(sfObjectName);
  });
});
