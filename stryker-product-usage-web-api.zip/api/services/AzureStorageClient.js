/**
 * Utility module providing modern inteface to Azure Storage client.
 * @module src/util/AzureStorageClient
 */
const { EventEmitter } = require('events');
const { BlobServiceClient, generateBlobSASQueryParameters, BlobSASPermissions } = require('@azure/storage-blob');
const Readable = require('stream');
const { AZURE } = require('../config');

/** Modern interface to Azure Storage client.  */
class AzureStorageClient extends EventEmitter {
  constructor(url, containerName) {
    super();
    this.privateConnected = false;
    this.url = url;
    this.containerName = containerName;
    /** Application's Azure Storage client */
    this.client = BlobServiceClient.fromConnectionString(url);
  }

  get connected() {
    return this.privateConnected;
  }

  async connect() {
    if (this.privateConnected) {
      return;
    }
    let foundContainer = false;
    try {
      const containerClient = await this.client.listContainers();
      let containerItem = await containerClient.next();
      while (!containerItem.done) {
        if (containerItem.value.name === this.containerName) {
          foundContainer = true;
          break;
        }
        // eslint-disable-next-line no-await-in-loop
        containerItem = await containerClient.next();
      }
      //
    } catch (err) {
      throw new Error(`AzureStorageClient: could not connect to ${this.url}`);
    }
    if (!foundContainer) {
      throw new Error(
        `AzureStorageClient: could not find container ${this.containerName}`
      );
    }
    this.privateConnected = true;
  }

  async uploadBlobToAzure(file, blobName) {
    if (!this.privateConnected) {
      return Promise.reject(
        new Error('AzureStorageClient: Client disconnected from Azure')
      );
    }
    try {
      const containerClient = this.client.getContainerClient(
        this.containerName
      );
      const blockBlobClient = containerClient.getBlockBlobClient(blobName);
      const responseBlob = await blockBlobClient.uploadStream(file);

      return {
        requestId: responseBlob.requestId || '',
        imageUrl: blockBlobClient.url
      };
    } catch (err) {
      // Let upload fail first
      setImmediate(() => {
        this.emit(
          'error',
          new Error(`AzureStorageClient: Upload failed for ${blobName} `)
        );
      });
      throw err;
    }
  }

  // migration to azure
  async migrateToAzure(fileUrl, thumbnailFileUrl, blobName, isSignature) {
    if (!this.privateConnected) {
      return Promise.reject(
        new Error('AzureStorageClient: Client disconnected from Azure')
      );
    }
    try {
      const containerClient = await this.client.getContainerClient(
        this.containerName
      );
      const blockBlobClient = await containerClient.getBlockBlobClient(
        blobName
      );
      const responseBlob = await blockBlobClient.syncCopyFromURL(fileUrl);

      const fileIsPdf = blobName.includes('pdf');

      let blockBlobThumbnailClient;
      let responseThumbnailBlob;
      // if the file is not pdf, creating thumbnail
      if (!fileIsPdf && !isSignature) {
        blockBlobThumbnailClient = await containerClient.getBlockBlobClient(
          `thumbnail-${blobName}`
        );
        responseThumbnailBlob = await blockBlobThumbnailClient.syncCopyFromURL(
          thumbnailFileUrl
        );
      }
      // console.log(responseBlob.copyStatus);
      return {
        fileStatus: responseBlob.copyStatus,
        fileUrl: blockBlobClient.url.substring(
          blockBlobClient.url.lastIndexOf('/') + 1
        ),
        thumbnailStatus:
          fileIsPdf || isSignature
            ? 'success'
            : responseThumbnailBlob.copyStatus,
        thumbnailFileUrl:
          fileIsPdf || isSignature
            ? null
            : blockBlobThumbnailClient.url.substring(
                blockBlobThumbnailClient.url.lastIndexOf('/') + 1
              )
      };
    } catch (err) {
      console.err('ERROR occured while uploading image');
      console.err('Blob Name: ', blobName);
    }
  }

  // deleting blob
  async deleteBlobFromAzure(blobName) {
    if (!this.privateConnected) {
      return Promise.reject(
        new Error('AzureStorageClient: Client disconnected from Azure')
      );
    }
    try {
      const containerClient = await this.client.getContainerClient(
        this.containerName
      );
      // deleting blob
      await containerClient.deleteBlob(blobName, {
        deleteSnapshots: 'include'
      });
      return;
    } catch (err) {
      throw err;
    }
  }

  async generateReadSAS(blobName, startDate, endDate) {
    const url = this.client.getContainerClient(this.containerName).getBlobClient(blobName).url;
    return url + '?' + generateBlobSASQueryParameters(
      {
        containerName: this.containerName,
        blobName: blobName,
        startsOn: startDate,
        expiresOn: endDate,
        permissions: BlobSASPermissions.parse('ra')
      }, 
      this.client.credential).toString();
  }
}

const azureStorageClient = new AzureStorageClient(
  AZURE.CONNECTION_STRING,
  AZURE.IMAGE_CONTAINER_NAME
);

module.exports = {
  azureStorageClient,
  AzureStorageClient
};
