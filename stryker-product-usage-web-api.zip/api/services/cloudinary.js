const cloudinary = require('cloudinary');
const Promise = require('bluebird');

const deleteImageCloud = async ids => {
  let result = {};
  if (ids.length > 0) result = await Promise.all(deleteImagePromise(ids));
  else throw new Error('ids not found');
  return result;
};
const uploadImageCloud = async files => {
  return await Promise.all(imageUploadPromise(files));
};

const uploadSignatureToCloud = async body => {
  return await Promise.all([
    signatureUploadPromise('hospital', body.hospitalSignBlob),
    signatureUploadPromise('rep', body.repSignBlob)
  ]);
};

const imageUploadPromise = files =>
  files.map(file => {
    let uploadPayload = { resource_type: 'auto' };
    if (file.mimetype && file.mimetype.includes('image')) {
      uploadPayload = {
        ...uploadPayload
      };
    }
    return new Promise((resolve, reject) => {
      cloudinary.v2.uploader
        .upload_stream({ ...uploadPayload }, (error, result) => {
          if (error) reject(error);
          resolve(result);
        })
        .end(file.buffer);
    });
  });

const uploadBlob = blob =>
  new Promise((resolve, reject) => {
    cloudinary.v2.uploader
      .upload_stream({ resource_type: 'auto' }, (error, res) => {
        if (error) reject(error);
        resolve(res);
      })
      .end(new Buffer.from(blob, 'base64'));
  });

const signatureUploadPromise = (name, signBlob) =>
  new Promise((resolve, reject) => {
    cloudinary.v2.uploader.upload(signBlob, (error, res) => {
      if (error) reject(error);
      resolve({ [name]: res });
    });
  });

const deleteImagePromise = publicIds =>
  publicIds.map(
    publicId =>
      new Promise((resolve, reject) => {
        cloudinary.v2.uploader.destroy(
          publicId,
          { invalidate: true },
          (error, result) => {
            if (error) reject(error);
            resolve(result);
          }
        );
      })
  );

const getImageUrl = publicId =>
  `${AZURE_IMAGE_URL}/${AZURE_IMAGE_CONTAINER_NAME}/${publicId}`;

module.exports = {
  uploadImageCloud,
  uploadSignatureToCloud,
  deleteImageCloud,
  getImageUrl,
  uploadBlob
};
