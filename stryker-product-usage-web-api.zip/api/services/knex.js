const knex = require('knex');
const pg = require('pg');
const { POSTGRES, HEROKU_CONNECT, ENVIRONMENT } = require('../config');

const WORKERS = process.env.WEB_CONCURRENCY || 1;

// Only enable SSL in Heroku
pg.defaults.ssl =
  POSTGRES.DATABASE_URL.indexOf('127.0.0.1') < 0 &&
  POSTGRES.DATABASE_URL.indexOf('app_postgres') < 0;

function createKnexConnection(connection, searchPath) {
  return knex({
    client: 'pg',
    connection,
    searchPath,
    debug: ENVIRONMENT.IS_LOCAL_DEVELOPMENT,
    pool: { min: 1, max: 25, acquireTimeoutMillis: 10000 }
  });
}

const herokuConnectClient = createKnexConnection(
  HEROKU_CONNECT.DATABASE_URL,
  'public,salesforce'
);

module.exports = {
  createKnexConnection,
  herokuConnectClient
};
