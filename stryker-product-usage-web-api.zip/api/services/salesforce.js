const qs = require('qs');
const client = require('./knex').herokuConnectClient;

module.exports = {
  querySFObject,
  sanitizeSalesforceQuery,
  getSFObjectNameFromPath,
  parseSFObjects,
  upsertSFObject,
  batchUpsertSFObject,
  findUser,
  findUserShort,
  batchInsertSFObject
};

const upsert = require('./upsert')(client);
const batchUpsert = require('./batchUpsert')(client);

function batchUpsertSFObject(tableName, data, constraintKey, condition) {
  return batchUpsert({
    table: tableName,
    data,
    constraint: constraintKey,
    condition
  });
}

function batchInsertSFObject(table, values, trx) {
  return trx
    ? client.batchInsert(table, values).transacting(trx)
    : client.batchInsert(table, values);
}

function upsertSFObject(tableName, recordObject, constraintKey, trx) {
  return upsert({
    table: tableName,
    object: recordObject,
    constraint: constraintKey,
    trx
  });
}

/* istanbul ignore next */
async function querySFObject(name, query = {}, limit) {
  let sanitizedQuery = sanitizeSalesforceQuery(query);
  let results = await client
    .withSchema('salesforce')
    .select('*')
    .from(name)
    .where(sanitizedQuery)
    .limit(limit || 50);

  return results || [];
}

async function findUserShort(email = 'invalid@test.org') {
  try {
    let query = client
      .withSchema('repsuite')
      .select(
        'id',
        'division',
        'divisions'
      )
      .from('users_mv')
      .where(
        client.raw(
          'LOWER(email) = ?',
          email.toLowerCase()
        )
      );
    let results = await query;
    if (results.length === 0) {
      throw new Error(`${email.toLowerCase()} not found`);
    }

    const userRecord = results[0];
    let user = {};
    user.sfids = [userRecord.id];
    user.divisions = userRecord.divisions
      ? userRecord.divisions.split(';')
      : [];
    if (
      userRecord.division &&
      !user.divisions.some(x => x === userRecord.division)
    ) {
      user.divisions.push(userRecord.division);
    }

    return user;
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function findUser(email = 'invalid@test.org') {
  try {
    let query = client
      .withSchema('repsuite')
      .select(
        'id',
        'first_name',
        'last_name',
        'email',
        'sales_rep_email',
        'usertype',
        'division',
        'divisions',
        'personas',
        'branchIds',
        'teammate_sfids'
      )
      .from('users_mv')
      .where(
        client.raw(
          'LOWER(email) = ?',
          email.toLowerCase()
        )
      );

    const results = await query;
    if (results.length === 0) {
      throw new Error(`${email.toLowerCase()} not found`);
    }

    const userRecord = results[0];
    let user = {};
    user.sfids = [userRecord.id];
    user.divisions = userRecord.divisions
      ? userRecord.divisions.split(';')
      : [];
    if (
      userRecord.division &&
      !user.divisions.some(x => x === userRecord.division)
    ) {
      user.divisions.push(userRecord.division);
    }
    user.personas = userRecord.personas ? userRecord.personas.split(';') : [];
    user.email = userRecord.email;
    user.sales_rep_email = userRecord.sales_rep_email;
    user.first_name = userRecord.first_name;
    user.last_name = userRecord.last_name;
    user.branchIds = userRecord.branchIds ? userRecord.branchIds.split(',') : [];
    user.teammate_sfids = userRecord.teammate_sfids
      ? userRecord.teammate_sfids.split(',')
      : [];
    return user;
  } catch (error) {
    console.error(error);
    return null;
  }
}

/* istanbul ignore next */
async function insertSFObject(name, query = {}, limit) {
  let sanitizedQuery = sanitizeSalesforceQuery(query);
  let results = await client
    .withSchema('salesforce')
    .select('*')
    .from(name)
    .where(sanitizedQuery)
    .limit(limit || 50);

  return results || [];
}

function parseSFObjects(urls = []) {
  let queries = urls.map(async url => {
    let sfObjectNameParts = getSFObjectNameFromPath(url).split('?');
    let sfObjectName = sfObjectNameParts[0];
    let queryParam = sfObjectNameParts[1];
    let query = qs.parse(queryParam);
    let sfQuery = await querySFObject(sfObjectName, query);
    return {
      url,
      choices: sfQuery.map(result => ({
        text: result[query.text_field],
        value: result[query.value_field]
      }))
    };
  });

  return queries;
}

/**
 * Returns the Salesforce object name based on path
 * @param {String} path - req.path
 */
function getSFObjectNameFromPath(path) {
  let urlParts = path.split('/');
  return urlParts[urlParts.length - 1];
}

/**
 *
 * @param {Object} query - A req.query object
 */
function sanitizeSalesforceQuery(query = {}) {
  return Object.keys(query)
    .filter(queryKey => queryKey !== 'text_field' && queryKey !== 'value_field')
    .reduce((accumulator, queryKey) => {
      accumulator[queryKey] = query[queryKey];
      return accumulator;
    }, {});
}
