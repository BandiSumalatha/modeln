const { POSTGRES } = require('../../config');
const Sequelize = require('sequelize'); //
const enableSSL = POSTGRES.DATABASE_URL.indexOf('app_postgres') < 0;
let options = {
  logging: POSTGRES.POSTGRES_LOGGING === 'true'
};

if (enableSSL) {
  options.ssl = enableSSL;
  options.native = true;
  options.dialectOptions = {
    ssl: {
      required: enableSSL
    }
  };
}
const sequelize = new Sequelize(POSTGRES.DATABASE_URL, options);
module.exports = sequelize;
