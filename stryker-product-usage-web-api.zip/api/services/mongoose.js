const mongoose = require('mongoose');
const { MONGODB } = require('../config');

// Connection
mongoose.connect(MONGODB.URI, {useNewUrlParser: true});

module.exports = mongoose;
