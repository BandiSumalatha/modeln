const { ApolloError } = require('apollo-server-express');
const uuidv1 = require('uuid/v1');
const { connect } = require('amqplib');
const { azureStorageClient } = require('./AzureStorageClient');
const streamifier = require('streamifier');
const { AZURE, AMQP } = require('../config');

const delay = () =>
  new Promise(resolve => {
    setTimeout(() => {
      resolve();
    }, 1000);
  });

const uploadImageFiles = async files => {
  try {
    const imagesUploadData = files.map(async file => {
      const stream = streamifier.createReadStream(file.buffer);
      const imageExt = file.originalname.slice(-3);
      const fileName = `${uuidv1()}.${imageExt}`;
      const { CLOUDAMQP_URL } = AMQP;
      const callbacks = {};

      try {
        if (CLOUDAMQP_URL === undefined) {
          return {};
        }
        const conn = await connect(CLOUDAMQP_URL);
        const ch = await conn.createChannel();
        await ch.assertQueue(AMQP.THUMBNAIL_CREATION_TASK);

        const { queue } = await ch.assertQueue('', {
          exclusive: true
        });

        // CONSUME WORKER RESPONSES
        ch.consume(queue, async msg => {
          if (msg === null) {
            return;
          }
          const {
            content,
            properties: { correlationId }
          } = msg;
          if (callbacks[correlationId] !== undefined) {
            callbacks[correlationId](content.toString());
          }
          ch.ack(msg);
        });

        const correlationId = uuidv1();
        const callback = async content => {
          delete callbacks[correlationId];
        };

        const {
          requestId,
          imageUrl
        } = await azureStorageClient.uploadBlobToAzure(stream, fileName);
        callbacks[correlationId] = callback;
        ch.sendToQueue(AMQP.THUMBNAIL_CREATION_TASK, Buffer.from(imageUrl), {
          correlationId,
          replyTo: queue
        });

        // HANDLE WORKER NOT COMPLETING
        await delay();
        if (callbacks[correlationId] !== undefined) {
          delete callbacks[correlationId];
        }
        const thumbnailUrl = `${imageUrl.slice(
          0,
          imageUrl.lastIndexOf('/') + 1
        )}thumbnail-${imageUrl.slice(imageUrl.lastIndexOf('/') + 1)}`;
        conn.close();
        return {
          requestId,
          imageUrl,
          thumbnailUrl
        };
      } catch (err) {
        console.error('Error: ', err);
        throw new ApolloError('failed to upload file');
      }
    });

    const data = await Promise.all(imagesUploadData);
    return data;
  } catch (err) {
    console.error(err);
  }
};

const signatureUploadPromise = async (name, signBlob) => {
  signBlob = signBlob.split(';base64,', 2).pop();

  try {
    const stream = streamifier.createReadStream(
      new Buffer.from(signBlob, 'base64')
    );
    const { imageUrl } = await azureStorageClient.uploadBlobToAzure(
      stream,
      `${uuidv1()}.png`
    );
    return { [name]: imageUrl };
  } catch (err) {
    console.error('Error: ', err);
    throw new Error(err);
  }
};

const uploadBlob = async blob => {
  try {
    // const blobArray = blob.split(';base64,', 2);

    const stream = streamifier.createReadStream(
      new Buffer.from(blob, 'base64')
    );
    const fileName = `${uuidv1()}`;
    const { CLOUDAMQP_URL } = AMQP;
    const callbacks = {};

    try {
      if (CLOUDAMQP_URL === undefined) {
        return {};
      }
      const conn = await connect(CLOUDAMQP_URL);
      const ch = await conn.createChannel();
      await ch.assertQueue(AMQP.THUMBNAIL_CREATION_TASK);

      const { queue } = await ch.assertQueue('', {
        exclusive: true
      });

      // CONSUME WORKER RESPONSES
      ch.consume(queue, async msg => {
        if (msg === null) {
          return;
        }
        const {
          content,
          properties: { correlationId }
        } = msg;
        if (callbacks[correlationId] !== undefined) {
          callbacks[correlationId](content.toString());
        }
        ch.ack(msg);
      });

      const correlationId = uuidv1();
      const callback = async content => {
        delete callbacks[correlationId];
      };

      const {
        requestId,
        imageUrl
      } = await azureStorageClient.uploadBlobToAzure(stream, fileName);
      callbacks[correlationId] = callback;
      ch.sendToQueue(AMQP.THUMBNAIL_CREATION_TASK, Buffer.from(imageUrl), {
        correlationId,
        replyTo: queue
      });

      // HANDLE WORKER NOT COMPLETING
      await delay();
      if (callbacks[correlationId] !== undefined) {
        delete callbacks[correlationId];
      }
      const thumbnailUrl = `${imageUrl.slice(
        0,
        imageUrl.lastIndexOf('/') + 1
      )}thumbnail-${imageUrl.slice(imageUrl.lastIndexOf('/') + 1)}`;
      conn.close();
      return {
        requestId,
        imageUrl,
        thumbnailUrl
      };
    } catch (err) {
      console.error('Error: ', err);
      throw new ApolloError('failed to upload file');
    }
  } catch (err) {
    console.error(err);
  }
};

const blobSignatureUpload = async body => {
  const hospitalResult = await signatureUploadPromise(
    'hospital',
    body.hospitalSignBlob
  );
  const repResult = await signatureUploadPromise('rep', body.repSignBlob);
  return [hospitalResult, repResult];
};

const deleteImageBlob = async blobNameArray => {
  for (const blobName of blobNameArray) {
    await azureStorageClient.deleteBlobFromAzure(blobName);
  }
};

const getImageUrl = publicId =>
  `${AZURE.BASE_UPLOAD_URL}/${AZURE.IMAGE_CONTAINER_NAME}/${publicId}`;

module.exports = {
  uploadImageFiles,
  blobSignatureUpload,
  getImageUrl,
  deleteImageBlob,
  uploadBlob
};
