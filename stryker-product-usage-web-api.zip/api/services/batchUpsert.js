const returning =
  " 'updated' = set_config('upsert.action', 'updated', true) returning *, CASE WHEN current_setting('upsert.action', true) = 'updated' THEN 'updated' ELSE 'inserted' END as upsert";

module.exports = function batchInsert(knex) {
  return ({ table, data, constraint, condition }) => {
    const queries = data.map(item => {
      const insert = knex(table)
        .insert(item)
        .toString();
      let update = knex
        .queryBuilder()
        .update(item)
        .toString();
      if (condition) {
        update = `${update} where ${condition} and`;
      } else {
        update = `${update} where`;
      }
      return `${insert} ON CONFLICT (${constraint}) DO ${update} ${returning}`;
    });
    const query = queries.join(';');
    return knex.raw(query).then(result => result);
  };
};
