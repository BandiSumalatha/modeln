// copied from https://gist.github.com/timhuff/f4f0814b0eb048784e44e744aa8e41f5

const returning =
  " WHERE 'updated' = set_config('upsert.action', 'updated', true) returning *, CASE WHEN current_setting('upsert.action', true) = 'updated' THEN 'updated' ELSE 'inserted' END as upsert";

module.exports = function upsert(knex) {
  return ({ table, object, constraint, trx }) => {
    const insert = trx ? knex(table)
      .insert(object)
      .transacting(trx)
      .toString() : knex(table)
        .insert(object)
        .toString();
    const update = trx ? knex
      .update(object).transacting(trx)
      .toString() : knex.queryBuilder().update(object).toString();
    return trx ? knex
      .raw(`${insert} ON CONFLICT (${constraint}) DO ${update} ${returning}`)
      .then(result => result.rows[0]) : knex
      .raw(`${insert} ON CONFLICT (${constraint}) DO ${update} ${returning}`)
      .transacting(trx)
      .then(result => result.rows[0]);
  };
};
