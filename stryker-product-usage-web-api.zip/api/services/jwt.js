const jwt = require('jsonwebtoken');
const jwksClient = require('jwks-rsa');
const { OAUTH } = require('../config');

module.exports = {
  verifyToken
};

async function verifyToken(token) {
  var client = jwksClient({
    cache: true,
    cacheMaxEntries: 10,
    cacheMaxAge: 12 * 60 * 60 * 1000, // 12 hours in millis
    jwksUri: OAUTH.JWKS_URL
  });

  let { header } = jwt.decode(token, {complete:true});

  let skey = await new Promise( (resolve, reject) => {
    client.getSigningKey(header.kid, function(err, key) {
      if (key) {
        var signingKey = key.publicKey || key.rsaPublicKey;
        resolve(signingKey); 
      }
      else {
        resolve(null);
      }      
    });
  });

  return new Promise((resolve, reject) => {
    if (skey) {
      jwt.verify(token, skey, { algorithms: ['RS256']}, function(err, decoded) {
        if (err) reject(err);
        resolve(decoded);
      });
    }
    else {
      resolve(jwt.decode(token));
    }
  });
}