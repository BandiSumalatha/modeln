const amqp = require('amqplib');
const { herokuConnectClient } = require('../services/knex');
const { AMQP } = require('./../config');

const createUploadImageJob = async (
  caseExternalId,
  case_sfid,
  imagesToCount
) => {
  if (imagesToCount.length > 0) {
    await enqueueImageSync({ caseExternalId, case_sfid, imagesToCount });
  }
};

const createDeleteImageJob = async (
  caseSfid,
  caseExternalId,
  shouldDeleteSignatures,
  imageIdsToKeep,
  imageIdsToDelete
) => {
  const query = herokuConnectClient('case_images')
    .withSchema('salesforce')
    .select(
      'case_images.attachment_id',
      'case_images.azure_image_url',
      'case_images.thumbnail_url'
    );

  if (caseExternalId) {
    query.where('case_images.case_external_id', caseExternalId);
  } else if (caseSfid) {
    query.where('case_images.case_sfid', caseSfid);
  } else {
    return;
  }

  query
    // TODO remove while creating PR
    .whereNotNull('case_images.attachment_id')
    .whereNotNull('case_images.azure_image_url');
  if (imageIdsToKeep && imageIdsToKeep.length > 0) {
    query.whereNotIn('case_images.azure_image_url', imageIdsToKeep);
  }
  if (imageIdsToDelete && imageIdsToDelete.length > 0) {
    query.whereIn('case_images.azure_image_url', imageIdsToDelete);
  }

  if (!shouldDeleteSignatures) {
    query.whereNull('signature_by');
  }

  const images = await query;

  if (images.length > 0) {
    await enqueueDeleteRequest({ attachments: images });
  }
};

const enqueueImageSync = async caseIds => {
  try {
    const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
    const channel = await conn.createChannel();
    await channel.assertQueue(AMQP.IMAGE_SYNC, { durable: true });
    await channel.sendToQueue(
      AMQP.IMAGE_SYNC,
      new Buffer(JSON.stringify(caseIds))
    );

    await channel.close();
    await conn.close();
  } catch (ex) {
    console.log(` Error in enqueueImageSync: `, ex);
    throw new Error(`Error in enqueueImageSync for image ${image}`);
  }
};

const enqueueDeleteRequest = async image => {
  try {
    const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
    const channel = await conn.createChannel();
    await channel.assertQueue(AMQP.DELETE_ATTACHMENT, { durable: true });
    await channel.sendToQueue(
      AMQP.DELETE_ATTACHMENT,
      new Buffer(JSON.stringify(image))
    );
    await channel.close();
    await conn.close();
  } catch (ex) {
    console.log(
      ` Error in enqueueDeleteRequest for image ${image} and error is : `,
      ex
    );
    throw new Error(`Error in enqueueDeleteRequest for image ${image} `);
  }
};

const enqueueBuildCache = async () => {
  try {
    const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
    const channel = await conn.createChannel();
    await channel.assertQueue(AMQP.BUILD_CACHE, { durable: true });
    await channel.sendToQueue(
      AMQP.BUILD_CACHE,
      Buffer.from('')
    );
    await channel.close();
    await conn.close();
  } catch (ex) {
    console.log(
      ` Error in enqueueBuildCache and error is : `,
      ex
    );
    throw new Error('Error in enqueueBuildCache');
  }
};

const dequeue = async (queue, processSync) => {
    const channel = await getChannel();
    await channel.assertQueue(queue);
    await channel.consume(queue, processSync(channel));
}

const dequeueBuildCache = async processSync => {
  try {
    await dequeue(AMQP.BUILD_CACHE, processSync);
  } catch (ex) {
    console.log(` Error in dequeueBuildCache `, ex);
  }
};

const dequeueImageSync = async processSync => {
  try {
    await dequeue(AMQP.IMAGE_SYNC, processSync);
  } catch (ex) {
    console.log(` Error in dequeueImageSync `, ex);
  }
};

const dequeueDeleteRequest = async processSync => {
  try {
    await dequeue(AMQP.DELETE_ATTACHMENT, processSync);
  } catch (ex) {
    console.log(` Error in dequeueDeleteRequest `, ex);
  }
};

const dequeueThumbnailCreationSync = async processSync => {
  try {
    await dequeue(AMQP.THUMBNAIL_CREATION_TASK, processSync);
  } catch (ex) {
    console.log(` Error in dequeueThumbnailCreationSync `, ex);
  }
};
const getChannel = async () => {
  const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
  return await conn.createChannel();
};

module.exports = {
  createUploadImageJob,
  createDeleteImageJob,
  enqueueBuildCache,
  dequeueBuildCache,
  dequeueImageSync,
  dequeueDeleteRequest,
  dequeueThumbnailCreationSync,
  getChannel
};
