const axios = require('axios').default;
const qs = require('qs');
const { OAUTH } = require('../config');
const { RHS } = OAUTH;

const RHS_SCOPES = {
    MAKO: 1,
    AS1: 2
};

module.exports = { RHS_SCOPES, getRHSToken }

async function getMakoClientToken(refreshToken) {
    const clientAccessTokenRequest = {
        "grant_type": "refresh_token",
        "refresh_token": refreshToken,
        "scope": RHS.MAKO.SCOPE,
        "client_id": OAUTH.CLIENT_ID,
        "client_secret": OAUTH.CLIENT_SECRET
    };
    const { data: { access_token } } = await axios.post(OAUTH.TOKEN_URL, qs.stringify(clientAccessTokenRequest));
    return await swapToken(RHS.MAKO.CLIENT_ID, RHS.MAKO.CLIENT_SECRET, RHS.SCOPE, access_token);
}

async function getAS1ClientToken(refreshToken) {
    const clientAccessTokenRequest = {
        "grant_type": "refresh_token",
        "refresh_token": refreshToken,
        "scope": RHS.AS1.SCOPE,
        "client_id": OAUTH.CLIENT_ID,
        "client_secret": OAUTH.CLIENT_SECRET
    };
    const { data: { access_token } } = await axios.post(OAUTH.TOKEN_URL, qs.stringify(clientAccessTokenRequest));
    return await swapToken(RHS.AS1.CLIENT_ID, RHS.AS1.CLIENT_SECRET, RHS.SCOPE, access_token);
}

async function swapToken(client_id, client_secret, scope, assertion) {
    const rhsTokenRequest = {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "requested_token_use": "on_behalf_of",
        assertion,
        client_id,
        client_secret,
        scope
    }
    const { data: { access_token } } = await axios.post(OAUTH.TOKEN_URL, qs.stringify(rhsTokenRequest));
    return access_token;
}

async function getRHSToken(refreshToken, scope) {
    let clientAccessToken = null;
    switch(scope) {
        case RHS_SCOPES.MAKO: 
            clientAccessToken = await getMakoClientToken(refreshToken);
            break;        
        case RHS_SCOPES.AS1:
            clientAccessToken = await getAS1ClientToken(refreshToken);
            break;
        default: break;
    }

    return clientAccessToken;
}