const winston = require('winston');
const { herokuConnectClient } = require('../services/knex');
const JSONStream = require('JSONStream');
const { findUserShort } = require('../services/salesforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = { getConsignmentSets };

async function findConsignmentSets(user_sfid, divisions) {
  const timer = new Timer('controller.consignmentSets.find', defaultTimeout);
  await timer.start();

  let query = herokuConnectClient
    .withSchema('repsuite')
    .select(
      'set_id',
      'set_name',
      'kit_no__c',
      'Surgery_date__c',
      'Case_Number__c',
      'Status__c',
      'Category__c',
      'inventory_type',
      'label',
      'product_sfid',
      'part_id',
      'productOracleId',
      'gtin',
      'catalog_number',
      'lot_serial_control_code__c',
      'is_lot_controlled',
      'part_name',
      'part_desc'
    )
    .from('consignmentsets_v')
    .where('kit_assigner__c', '=', user_sfid)
    .orderBy('set_id');

  let result = await query;

  await timer.stop();
  
  return result;
}

async function getConsignmentSets(req, res) {
  const timer = new Timer('controller.consignmentSets.get', defaultTimeout);
  await timer.start();
  
  const currentUser = await findUserShort(req.currentUsername);
  const { divisions } = currentUser;
  const [user_sfid] = currentUser.sfids;

  res.setHeader('Content-Type', 'text/json');

  let interval = setInterval(() => {
    res.write(' ');
  }, 5000);

  const consignmentSetParts = await findConsignmentSets(user_sfid, divisions);

  let set = null;
  const transformStream = JSONStream.stringify();
  transformStream.pipe(res);

  clearInterval(interval);

  for (const setPart of consignmentSetParts) {
    const recordSetId = setPart.set_id;
    const recordCaseNumber = setPart.Case_Number__c;

    if (set == null || set.set_id != recordSetId ||
      set.Case_Number__c != recordCaseNumber) {
      if (set != null) transformStream.write(set);

      set = {
        set_id: setPart.set_id,
        set_name: setPart.set_name,
        kit_no__c: setPart.kit_no__c,
        Surgery_date__c: setPart.Surgery_date__c,
        Case_Number__c: setPart.Case_Number__c,
        Status__c: setPart.Status__c,
        Category__c: setPart.Category__c,
        inventory_type: setPart.inventory_type,
        label: setPart.label,
        parts: []
      };
    }

    set.parts.push({
      product_sfid: setPart.product_sfid,
      part_id: setPart.part_id,
      productOracleId: setPart.productOracleId,
      gtin: setPart.gtin,
      catalog_number: setPart.catalog_number,
      set_id: setPart.set_id,
      lot_serial_control_code__c: setPart.lot_serial_control_code__c,
      part_name: setPart.part_name,
      part_desc: setPart.part_desc,
      is_lot_controlled: setPart.is_lot_controlled
    });
  }

  // send very last set
  if (set != null) transformStream.write(set);
  transformStream.end();

  await timer.stop();
}
