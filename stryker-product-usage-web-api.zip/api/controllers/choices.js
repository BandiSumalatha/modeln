const {
  querySFObject,
  parseSFObjects,
  getSFObjectNameFromPath
} = require('../services/salesforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  find,
  cache
};

async function find(req, res) {
  const timer = new Timer('controller.choices.find', defaultTimeout);
  await timer.start();
  try {
    let sfObjectName = getSFObjectNameFromPath(req.path);
    let results = await querySFObject(sfObjectName, req.query);
    await timer.stop();
    /* istanbul ignore next */
    return res.json(
      results.map(result => ({
        text: result[req.query.text_field],
        value: result[req.query.value_field]
      }))
    );
  } catch (error) {
    await timer.stop();
    return res.status(500).json(error);
  }
}

async function cache(req, res) {
  const timer = new Timer('controller.choices.cache', defaultTimeout);
  await timer.start();
  let queries = parseSFObjects(req.body.urls);
  let response = await Promise.all(queries);
  await timer.stop();
  return res.json(response);
}
