const { fetchCases } = require('./../common/fetchCases');
const { findUserShort } = require('../services/salesforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  getCaseById
};

// get case detail
async function getCaseById(req, res) {
  const timer = new Timer('controller.case', defaultTimeout);
  await timer.start();

  try {
    const currentUser = await findUserShort(req.currentUsername);
    if (currentUser && currentUser.sfids.length > 0) {
      const { externalId, sfId, name } = req.query;
      if (externalId || sfId || name) {
        const myCases = await fetchCases({
          externalId,
          sfId,
          name
        });
        res.json(myCases ? myCases[0] : {});
      } else {
        let code = 401;
        let error = 'externalId, sfId, or name is required';
        return res.status(code).json(error);
      }
    } else {
      res.json({});
    }
    await timer.stop();
  } catch (error) {
    let code = 500;
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}
