const winston = require('winston');
const { herokuConnectClient } = require('../services/knex');
const JSONStream = require('JSONStream');
const { findUserShort } = require('../services/salesforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = { getSetCatalogs };

async function getSetCatalogs(req, res) {
  const timer = new Timer('controller.setCatalogs', defaultTimeout);
  await timer.start();

  const currentUser = await findUserShort(req.currentUsername);
  const [user_sfid] = currentUser.sfids;

  res.setHeader('Content-Type', 'text/json');

  let interval = setInterval(() => {
    res.write(' ');
  }, 5000);

  let query = herokuConnectClient
    .withSchema('salesforce')
    .distinct([
      'product_system__c.productsystemname__c as catalog_category',
      'product_system__c.category__c AS catalog_item_name',
      'product_system__c.sfid as catalog_item_sfid'
    ])
    .select()
    .from('product_system__c')
    .innerJoin(
      'user',
      'product_system__c.division__c',
      'user.multiselect_division__c'
    )
    .where('user.sfid', user_sfid);
  let sets = query.stream();

  clearInterval(interval);

  res.on('close', sets.end.bind(sets));
  sets.pipe(JSONStream.stringify()).pipe(res);

  await timer.stop();
}
