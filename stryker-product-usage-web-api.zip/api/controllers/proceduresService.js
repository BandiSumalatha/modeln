const winston = require('winston');
const { findUserShort } = require('../services/salesforce');
const storage = require("@azure/storage-blob");
const { AZURE } = require("../config");
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = { getProcedures };

async function getProcedures(req, res) {
  const timer = new Timer('controller.procedures', defaultTimeout);
  await timer.start();
  const currentUser = await findUserShort(req.currentUsername);
  const { divisions } = currentUser;

  res.setHeader('Content-Type', 'text/json');

  let procedureUrls = [];
  divisions.forEach(division => {
    const blobServiceClient = storage.BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
    const containerName = AZURE.CACHE_CONTAINER_NAME;
    const client = blobServiceClient.getContainerClient(containerName)
    const blobName = `procedure-${division}.json`;
    const blobClient = client.getBlobClient(blobName);

    const blobSAS = storage.generateBlobSASQueryParameters({
      containerName,
      blobName,
      permissions: storage.BlobSASPermissions.parse("r"),
      startsOn: new Date(Date.now() - 3600 * 1000),
      expiresOn: new Date(Date.now() + 3600 * 1000)
    }, blobServiceClient.credential).toString();
  
    const sasUrl = blobClient.url + "?" + blobSAS;
    procedureUrls.push(sasUrl);
  });

  res.write(JSON.stringify(procedureUrls));
  res.end();

  await timer.stop();
}