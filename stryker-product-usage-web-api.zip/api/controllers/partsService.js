
const storage = require("@azure/storage-blob");
const { AZURE } = require("../config");
const moment = require('moment');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  getDiffParts
};

async function getDiffParts(req,res) {
  const timer = new Timer('controller.parts', defaultTimeout);
  await timer.start();

  const lastSyncQuery = req.query.lastsyncdate;
  const parsedSync = lastSyncQuery ? moment(Number.parseInt(lastSyncQuery)) : null;
  const from = parsedSync && parsedSync.utc().isAfter(moment().utc().subtract(9, 'days')) ? parsedSync.utc() : null;

  const blobServiceClient = storage.BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
  const containerName = AZURE.CACHE_CONTAINER_NAME;
  const client = blobServiceClient.getContainerClient(containerName)
  const blobName = `parts${from ? '.' + from.format("YYYY-MM-DD") : ''}.json`;
  const blobClient = client.getBlobClient(blobName);

  const blobSAS = storage.generateBlobSASQueryParameters({
    containerName,
    blobName,
    permissions: storage.BlobSASPermissions.parse("r"),
    startsOn: new Date(Date.now() - 3600 * 1000),
    expiresOn: new Date(Date.now() + 3600 * 1000)
  }, blobServiceClient.credential).toString();

  const sasUrl = blobClient.url + "?" + blobSAS;
  await timer.stop();

  res.redirect(302, sasUrl);
}