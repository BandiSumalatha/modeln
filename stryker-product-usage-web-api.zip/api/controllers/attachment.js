const { azureStorageClient } = require('../services/AzureStorageClient');

module.exports = { retrieve };

async function retrieve(req, res) {
    const { file } = req.query;
    if (!file) {
        res.status(404).send('Not found');
        return;
    }

    const url = await azureStorageClient.generateReadSAS(file, new Date(new Date().getTime() - 86400), new Date(new Date().getTime() + 86400));
    res.redirect(url);
}