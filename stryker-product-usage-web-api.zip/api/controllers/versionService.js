const { ENVIRONMENT } = require('../config');

module.exports = {
    getVersion
}

async function getVersion(req, res) {
    return res.status(200).send(ENVIRONMENT.SUPPORTED_APP_VERSION);
}