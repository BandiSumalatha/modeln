const winston = require('winston');
const { herokuConnectClient } = require('../services/knex');
const { findUserShort } = require('../services/salesforce');
const JSONStream = require('JSONStream');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = { getLoanerSets };

async function getLoanerSets(req, res) {
  const timer = new Timer('controller.loanerSets', defaultTimeout);
  await timer.start();

  const currentUser = await findUserShort(req.currentUsername);
  const [user_sfid] = currentUser.sfids;

  res.setHeader('Content-Type', 'text/json');

  let interval = setInterval(() => {
    res.write(' ');
  }, 5000);

  let query = herokuConnectClient
    .withSchema('salesforce')
    .select([
      'product_system__c.category__c as set_name',
      'product_system__c.sfid as set_id'
    ])
    .from('product_system__c')
    .innerJoin('user', function() {
      this.on(
        herokuConnectClient.raw(
          `"user".multiselect_division__c LIKE '%' || product_system__c.division__c || '%'`
        )
      );
    })
    .where('user.sfid', user_sfid);

  let sets = query.stream();
  clearInterval(interval);
  res.on('close', sets.end.bind(sets));
  sets.pipe(JSONStream.stringify()).pipe(res);
  await timer.stop();
}
