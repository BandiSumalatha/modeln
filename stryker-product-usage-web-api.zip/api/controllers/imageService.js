const { isEmpty } = require('lodash');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const {
  uploadImageFiles,
  blobSignatureUpload,
  deleteImageBlob,
  uploadBlob
} = require('../services/blobImageUpload');

const { herokuConnectClient } = require('../services/knex');
const { upsertSFObject } = require('../services/salesforce');

const { Timer, defaultTimeout } = require('../services/timer');

let publicKey = process.env.SF_API_KEY;

if (!process.env.SF_API_KEY && process.env.SF_API_KEY_PATH) {
  publicKey = fs.readFileSync(
    path.join(__dirname, '../../', process.env.SF_API_KEY_PATH),
    'utf-8'
  );
}

async function uploadImage(req, res, next) {
  const timer = new Timer('controller.image.upload', defaultTimeout);
  try {
    await timer.start();
    let result = [],
      resultSign = [];
    if (!isEmpty(req.files)) result = await uploadImageFiles(req.files);
    if (!isEmpty(req.body)) resultSign = await blobSignatureUpload(req.body);
    console.log('imageService result', { images: result, signatures: resultSign });
    await timer.stop();
    return res.status(200).json({ images: result, signatures: resultSign });
  } catch (error) {
    let code = 500;
    console.log(error);
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}

async function uploadImageFromSalesforce(req, res, next) {
  const timer = new Timer('controller.image.uploadSalesforce', defaultTimeout);
  try {
    await timer.start();

    const signature = req.headers.signature || '';
    const verifier = crypto.createVerify('sha256');

    const {
      id = '',
      caseExternalId = null,
      caseSfid = '',
      contentName = ''
    } = req.body;

    verifier.update(
      JSON.stringify({
        id: id.trim(),
        caseExternalId:
          caseExternalId && caseExternalId !== 'null'
            ? caseExternalId.trim()
            : null,
        caseSfid: caseSfid.trim()
      })
    );
    verifier.end();

    if (!verifier.verify(publicKey, signature, 'hex')) {
      await timer.stop();
      return res.status(401).json({ result: 'Error: Invalid signature.' });
    }

    const image = await uploadBlob(req.body.file);
    const imageUrlArr = image.imageUrl.split('/');
    const thumbnailUrlArr = image.thumbnailUrl.split('/');

    await upsertSFObject(
      'salesforce.case_images',
      {
        case_sfid: caseSfid.trim(),
        case_external_id:
          caseExternalId && caseExternalId !== 'null'
            ? caseExternalId.trim()
            : null,
        attachment_id: id.trim(),
        azure_image_url: imageUrlArr[imageUrlArr.length - 1],
        thumbnail_url: thumbnailUrlArr[thumbnailUrlArr.length - 1],
        attachment_name: contentName,
        created_at: new Date(),
        updated_at: new Date()
      },
      'azure_image_url'
    );

    await timer.stop();

    return res.status(200).json({ result: 'OK' });
  } catch (error) {
    let code = 500;
    console.log(error);
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}

async function deleteImages(req, res, next) {
  const timer = new Timer('controller.image.delete', defaultTimeout);
  await timer.start();

  try {
    const { id = '' } = req.query;
    const signature = req.headers.signature || '';

    const verifier = crypto.createVerify('sha256');
    verifier.update(JSON.stringify({ id: id.trim() }));
    verifier.end();

    if (!verifier.verify(publicKey, signature, 'hex')) {
      await timer.stop();
      return res.status(401).json({ result: 'Error: Invalid signature.' });
    }
    const attachment_id = id.trim();
    const images = await herokuConnectClient('case_images')
      .withSchema('salesforce')
      .select('azure_image_url', 'thumbnail_url')
      .where({ attachment_id });
    if (images.length == 0) {
      await timer.stop();
      throw new Error(
        `No related image found with attachment id - ${attachment_id}`
      );
    }
    
    const deleteImageIds = images[0].thumbnail_url
      ? [images[0].thumbnail_url, images[0].azure_image_url]
      : [images[0].azure_image_url];
    const result = await deleteImageBlob(deleteImageIds);
    await herokuConnectClient('case_images')
      .withSchema('salesforce')
      .where({ attachment_id })
      .del();
    await timer.stop();
    return res.status(200).json(result);
  } catch (error) {
    let code = 500;
    console.log(error);
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}

module.exports = {
  uploadImage,
  deleteImages,
  uploadImageFromSalesforce
};
