const http_mocks = require('node-mocks-http');

function buildResponse() {
  return http_mocks.createResponse({
    eventEmitter: require('events').EventEmitter
  });
}

jest.mock('../config', () => ({
  RATE_LIMIT_REQUESTS_PER_MINUTE: 120,
  HEROKU_CONNECT: {
    DATABASE_URL: 'test'
  }
}));

jest.mock('../services/knex', () => {
  const knex = require('knex');
  const mockDb = require('mock-knex');
  const db = knex({
    useNullAsDefault: true,
    client: 'sqlite'
  });
  mockDb.mock(db);
  return db;
});

const controller = require('./choices');
describe('/controllers/choices', () => {
  it('should find', async () => {
    let req = http_mocks.createRequest({
      url: 'http://somehost/surveyjs/choices/SomeObject__c?id=1&related_id=2'
    });
    let res = buildResponse();
    controller.find(req, res);
  });

  it('should cache', async () => {
    let req = http_mocks.createRequest({
      url: 'http://somehost/surveyjs/choices/cache',
      body: {
        urls: [
          'http://some-api/choices/Account__c?sfid=12345&text_field=name&value_field=sfid',
          'http://some-api/choices/Contact__c?sfid=12345&text_field=name&value_field=sfid',
          'http://some-api/choices/Custom_Object__c?sfid=12345&text_field=name&value_field=sfid'
        ]
      }
    });
    let res = buildResponse();
    controller.cache(req, res);
  });
});
