const { findUserShort } = require('../services/salesforce');
const axios = require('axios');
const winston = require('winston');
const { herokuConnectClient } = require('../services/knex');
const moment = require('moment');
const { map, find, merge } = require('lodash');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
    getOraclePrices
};

const _getCustomerId = async hospital_id => {
  const row = await herokuConnectClient
    .withSchema('salesforce')
    .select('customer_id__c')
    .from('account')
    .where('sfid', hospital_id);
  const customerId = row[0].customer_id__c;
  const customerIdSegments = customerId ? customerId.split('|', 2) : [];
  return customerIdSegments.length == 2 ? customerIdSegments[1] : customerId;
};

const _getProductsUOM = async (products, divForUOM) => {
  const data = await herokuConnectClient
    .withSchema('salesforce')
    .select([
      'product2.inventory_item_id_plain__c as productId'
    ])
    .max('pricebookentry.unit_of_measurement__c as uom')
    .max('product2.sfid as sfid')
    .from('product2')
    .leftJoin('pricebookentry', 'pricebookentry.product2id', 'product2.sfid')
    .leftJoin('pricebook2', 'pricebookentry.pricebook2id', 'pricebook2.sfid')    
    .where('pricebook2.name', divForUOM)
    .whereIn('product2.sfid', products)
    .groupBy('product2.inventory_item_id_plain__c');
  return data || [];
};

const _getContracts = async (contracts) => {
    const data = await herokuConnectClient
        .withSchema('salesforce')
        .select(['sfid', 'pricelist_header_id__c'])
        .from('contract')
        .whereIn('sfid', contracts);
    return data || [];
}

const _getMessageInfo = ({ messageId, senderIdentifier, receiverIdentifier }) => {
  return {
    v1$MessageID: { $t: messageId },
    v1$SenderIdentifier: { $t: senderIdentifier },
    v1$ReceiverIdentifier: { $t: receiverIdentifier }
  };
};

const _getHeaderInfo = (customerId, OrgUnitID, date) => {
  return {
    v1$SourceRefIdentifier: {
      $t: 'calledFromHerokuMobile'
    },
    v1$CustomerID: {
      $t: customerId
    },
    v1$EffectiveDate: {
      $t: moment.utc(date).format('YYYY-MM-DD hh:mm:ss')
    },
    v1$OrgUnitID: {
      $t: OrgUnitID
    }
  };
};

const _getRealTimePricingLines = async (contracts, products) => {
  return contracts.reduce((acc, contract) => acc.concat(products.map(product => {
    return {
      v1$ProductID: {
        $t: product.productId
      },
      v1$UOM: {
        $t: product.uom
      },
      v1$ContractNumber: {
        $t: contract.pricelist_header_id__c
      }
    };
  })), []);
};

const _getPayLoad = async (
  oracleCredentials,
  division,
  hospital_id,
  contracts,
  products,
  date
) => {
  const { spineOrgId, nonSpineOrgId } = oracleCredentials;

  const OrgUnitID =
    division && division === 'Spine' ? spineOrgId : nonSpineOrgId;

  const customerId = await _getCustomerId(hospital_id);

  if (!customerId) {
    return null;
  }

  const messageInfo = _getMessageInfo(oracleCredentials);
  const haderInfo = _getHeaderInfo(customerId, OrgUnitID, date);
  const realTimePricingLines = await _getRealTimePricingLines(
    contracts,
    products
  );
  const payload = {
    xmlns$v1: 'http://schemas.stryker.com/LocalRealTimePricing/V1',
    v1$RealTimePricingRequest: {
      v1$IntegrationHeader: messageInfo,
      v1$RealTimePricingDetails: {
        v1$RealTimePricing: [
          {
            ...haderInfo,
            v1$RealTimePricingLines: {
              v1$RealTimePricingLine: realTimePricingLines
            }
          }
        ]
      }
    }
  };
  return JSON.stringify(payload);
};

const _sendRequest = async (payload, { userName, password, endPoint }) => {
  let headerValue = Buffer.from(userName + ':' + password).toString('base64');
  let response = {};
  try {
    response = await axios({
      method: 'POST',
      url: endPoint,
      headers: {
        Authorization: `Basic ${headerValue}`,
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      data: payload,
      timeout: 90000
    });
    if (
      response &&
      response.status === 200 &&
      response.data &&
      response.data.RealTimePricingResponse &&
      response.data.RealTimePricingResponse.ResolvedPriceDetails
    ) {
      let priceDetails =
        response.data.RealTimePricingResponse.ResolvedPriceDetails;

      if (!Array.isArray(priceDetails)) {
        //it's not mandatory that oracle return always array
        priceDetails = [priceDetails];
      }
      const responsePrices = priceDetails.map(priceDetail => {
        return {
          productId: priceDetail.ProductID.$t,
          price: priceDetail.ResolvedPrice.$t,
          contractNumber: priceDetail.ContractIDNumber.$t
        };
      });
      return responsePrices;
    } else {
      return [];
    }
  } catch (error) {
    winston.error("Problem calling API.");
    throw error;
  }
};

const _combineRequestAndResponse = (products, contracts, response) => {
  return response.map(price => {
    return {
      ...price,
      productId: products.find(p => p.productId == price.productId).sfid,
      contractNumber: contracts.find(c => c.pricelist_header_id__c == price.contractNumber).sfid
    };
  });
};

async function getOraclePrices(req, res) {
    const timer = new Timer('controller.oraclePrices', defaultTimeout);
    await timer.start();

    const currentUser = await findUserShort(req.currentUsername);
    
    const { hospital_id, contracts, products, date } = req.body;
    let { division } = req.body;
    
    if (!hospital_id || !contracts || !products || !date) {
        res.status(400).send('Bad Request');
        await timer.stop();
        return;
    }

    const timeout = setInterval(() => {res.write(' \n'); res.flush();}, 5000);

    if (!division) {
      division =
        currentUser.divisions && currentUser.divisions.length > 0
          ? currentUser.divisions[0]
          : '';
    }
    const divForUOM =
      division && division === 'Spine' ? 'Spine Products' : 'Ortho Products';
  
    const timerPre = new Timer('controller.oraclePrices.preprocess', defaultTimeout);
    await timerPre.start();
    let resolvedProducts = await _getProductsUOM(products, divForUOM);
    let resolvedContracts = await _getContracts(contracts);
    
    const oracleCredentials = {
      userName: process.env.ORACLE_PRICING_API_USERNAME,
      password: process.env.ORACLE_PRICING_API_PASSWORD,
      endPoint: process.env.ORACLE_PRICING_API_ENDPOINT,
      spineOrgId: process.env.ORACLE_SPINE_ORG_ID,
      nonSpineOrgId: process.env.ORACLE_OTHER_ORG_ID,
      messageId: process.env.ORACLE_MESSAGE_ID,
      senderIdentifier: process.env.ORACLE_SENDER_IDENTIFIER,
      receiverIdentifier: process.env.ORACLE_RECEIVER_IDENTIFIER
    };

    const payLoad = await _getPayLoad(
      oracleCredentials,
      division,
      hospital_id,
      resolvedContracts,
      resolvedProducts,
      date
    );
    await timerPre.stop();

    try {
      if (payLoad) {
        const timerRTP = new Timer('controller.oraclePrices.rtp', defaultTimeout);
        await timerRTP.start();
        const response = await _sendRequest(payLoad, oracleCredentials);
        await timerRTP.stop();

        const timerPost = new Timer('controller.oraclePrices.post', defaultTimeout);
        await timerPost.start();
        const processedResponse = _combineRequestAndResponse(resolvedProducts, resolvedContracts, response).filter(x => x.price != null);
        await timerPost.stop();

        clearInterval(timeout);
        res.write(JSON.stringify(processedResponse));
      }
      else {
        clearInterval(timeout);
        res.write('[]');
      }
      await timer.stop();
    }
    catch(error) {
        await timer.stop();
        clearInterval(timeout);
        res.write('[]');
    }
    
    res.end();
}