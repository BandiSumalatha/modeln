const http_mocks = require('node-mocks-http');
const mockingoose = require('mockingoose').default;
const translationSeed = require('../models/Translations.seed');

const _translationDocs = [
  {
    _id: 123,
    locales: translationSeed
  }
];

function buildResponse() {
  return http_mocks.createResponse({
    eventEmitter: require('events').EventEmitter
  });
}

jest.mock('../config', () => ({
  RATE_LIMIT_REQUESTS_PER_MINUTE: 120,
  MONGODB: {
    URI: 'http://faketest.com'
  }
}));

describe('/controllers/translations', () => {
  const controller = require('./translations');

  it('get translations when query has locale(en) only', async () => {
    mockingoose.Translations.toReturn(_translationDocs, 'find');
    let req = http_mocks.createRequest({
      url: 'http://somehost/surveyjs/translations?locale=en'
    });
    let res = buildResponse();
    const a = await controller.findTranslation(req, res);

    expect(res._getStatusCode()).toBe(200);
    expect(res._getData()).toBe(JSON.stringify(_translationDocs[0].locales.en));
  });

  it('get translations when query has locale(en) and ns both', async () => {
    mockingoose.Translations.toReturn(_translationDocs, 'find');
    let req = http_mocks.createRequest({
      url: 'http://somehost/surveyjs/translations?locale=en&ns=nvj'
    });
    let res = buildResponse();
    const a = await controller.findTranslation(req, res);

    expect(res._getStatusCode()).toBe(200);
    expect(res._getData()).toBe(
      JSON.stringify(_translationDocs[0].locales.en.nvj)
    );
  });
});
