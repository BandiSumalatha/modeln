const winston = require('winston');
const { REDIS } = require('../config');
const { get, setEx } = require('../services/redis');
const { getConnection } = require('../services/jsforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = { getPicklists };

async function getPicklists(req, res) {
  const timer = new Timer('controller.picklists', defaultTimeout);
  const key =
    "get_picklist_values_{ type: 'GlobalValueSet', name: 'ERP_QQ_Reason_Codes', refresh_cache: false }";

  winston.info('Retrieving Salesforce picklist ERP_QQ_Reason_Codessss');

  let interval = setInterval(() => {
    res.write(' ');
  }, 5000);

  let cachedValueRaw = await get(REDIS.SALESFORCE_API_CACHE, key);

  console.log("cachedValueRaw.."+cachedValueRaw);

  if (!cachedValueRaw) {
    winston.info(
      'Refreshing cache for Salesforce picklist ERP_QQ_Reason_Codes'
    );
    const timerRefresh = new Timer('controller.picklists.cacheRefresh', defaultTimeout);
    await timerRefresh.start();
    let conn = await getConnection();
    let result = await conn.metadata.read(
      'GlobalValueSet',
      'ERP_QQ_Reason_Codes'
    );

    if (!result.customValue) {
      winston.error(
        'Failed to retrieve Salesforce picklist ERP_QQ_Reason_Codes: ERP_QQ_Reason_Codes is not a valid Global Picklist in Salesforce'
      );
      throw new Error(
        'ERP_QQ_Reason_Codes is not a valid Global Picklist in Salesforce'
      );
    }

    let results = result.customValue.reduce((output, item) => {
      if (!item.isActive) {
        output.push({
          id: item.fullName,
          label: item.label
        });
      }
      console.log("output.."+ output);
      return output;
    }, []);

    // Cache invalidates on default (1 day)
    if (results.length > 0) {
      cachedValueRaw = JSON.stringify(results);
      await setEx(REDIS.SALESFORCE_API_CACHE, key, cachedValueRaw);
      winston.info(
        'Successfully cached Salesforce picklist ERP_QQ_Reason_Codes'
      );
    }

    await timerRefresh.stop();
  }

  clearInterval(interval);

  res.write(cachedValueRaw);
  res.end();
  await timer.stop();
}
