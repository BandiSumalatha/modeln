const { Translations } = require('../models/Translations');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  findTranslation
};

async function findTranslation(req, res) {
  const timer = new Timer('controller.translations', defaultTimeout);
  await timer.start();

  try {
    const translations = await Translations.find({});
    if (req.query.locale) {
      let locale = translations[0].locales[req.query.locale];
      await timer.stop();
      if (req.query.ns) {
        return res.json(locale[req.query.ns]);
      }
      return res.json(locale);
    } else {
      return res.json(translations);
    }
  } catch (error) {
    let code = 500;
    if (error.name && error.name == 'TokenExpiredError') {
        code = 401;
    }
    return res.status(code).json(error);
  }
}
