const winston = require('winston');
const { findUser } = require('../services/salesforce');
const storage = require("@azure/storage-blob");
const { AZURE } = require("../config");
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  getJRTSetCatalogsNoneStorage
};

async function getJRTSetCatalogsNoneStorage(req, res) {
  const timer = new Timer('controller.jrtSetCatalogsNoStorage', defaultTimeout);
  await timer.start();

  const currentUser = await findUser(req.currentUsername);
  const branchIds = req.query.branchIds && typeof req.query.branchIds === 'string' ? req.query.branchIds.split(',') : currentUser.branchIds;

  res.setHeader('Content-Type', 'text/json');

  let branchUrls = [];
  for (let branchId of branchIds) {
    const blobServiceClient = storage.BlobServiceClient.fromConnectionString(AZURE.CONNECTION_STRING);
    const containerName = AZURE.CACHE_CONTAINER_NAME;
    const client = blobServiceClient.getContainerClient(containerName)
    const blobName = `sets-users-${branchId}.json`;
    const blobClient = client.getBlobClient(blobName);

    const blobSAS = storage.generateBlobSASQueryParameters({
      containerName,
      blobName,
      permissions: storage.BlobSASPermissions.parse("r"),
      startsOn: new Date(Date.now() - 3600 * 1000),
      expiresOn: new Date(Date.now() + 3600 * 1000)
    }, blobServiceClient.credential).toString();

    const sasUrl = blobClient.url + "?" + blobSAS;
    branchUrls.push(sasUrl);
  }

  res.write(JSON.stringify(branchUrls));
  res.end();

  await timer.stop();
}
