const winston = require('winston');
const { getConnection } = require('../services/jsforce');
const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  sendEmail
};

async function sendEmail(req, res) {
  const timer = new Timer('controller.email.send', defaultTimeout);

  try {    
    await timer.start();

    const conn = await getConnection();
    const response = await conn.requestPost(
      `/services/apexrest/EmailService`,
      req.body
    );

    await timer.stop();

    return res.status(response.status).json(response);
  } catch (error) {
    let code = 500;
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}
