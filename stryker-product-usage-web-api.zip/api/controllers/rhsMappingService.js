module.exports = { getRHSMappings };
const { Timer, defaultTimeout } = require('../services/timer');

async function getRHSMappings(req, res) {
    const timer = new Timer('controller.rhsMappings', defaultTimeout);
    await timer.start();

    const { herokuConnectClient } = require('../services/knex');
    const dbMappings = await herokuConnectClient
        .withSchema('repsuite')
        .select('salesforce', 'rhs')
        .from('rhsmapping')
        .orderBy('salesforce');

    let toRHS = {};
    let toRHSSimple = {};
    let fromRHS = {};
    
    for (const dbMapping of dbMappings) {
        const salesforce = dbMapping.salesforce.split('|');
        let sfdcObject = {};
        if (salesforce.length > 0) sfdcObject.procedure = salesforce[0];
        if (salesforce.length > 1) sfdcObject.type = salesforce[1];
        if (salesforce.length > 2) sfdcObject.value = salesforce[2];

        toRHSSimple[dbMapping.salesforce] = dbMapping.rhs;
        fromRHS[dbMapping.rhs] = sfdcObject;

        if (salesforce.length == 1) {
            toRHS[sfdcObject.procedure] = { value: dbMapping.rhs };
        }

        if (salesforce.length == 2) {
            if (!toRHS[sfdcObject.procedure]) toRHS[sfdcObject.procedure] = {};
            toRHS[sfdcObject.procedure][sfdcObject.type] = { value: dbMapping.rhs };
        }

        if (salesforce.length == 3) {
            if (!toRHS[sfdcObject.procedure]) toRHS[sfdcObject.procedure] = {};
            if (!toRHS[sfdcObject.procedure][sfdcObject.type]) toRHS[sfdcObject.procedure][sfdcObject.type] = {};
            toRHS[sfdcObject.procedure][sfdcObject.type][sfdcObject.value] = { value: dbMapping.rhs };
        }
    }

    await timer.stop();

    return res.status(200).json({ fromRHS, toRHS, toRHSSimple });
}