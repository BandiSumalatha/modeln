const axios = require('axios');
const winston = require('winston');
const path = require('path');
const fs = require('fs');

const { REDIS } = require('../config');
const { get } = require('../services/redis');
const { getConnection } = require('../services/jsforce');

const { Timer, defaultTimeout } = require('../services/timer');

module.exports = {
  getInvoiceWithPrice,
  getInvoiceWithoutPrice
};

async function getInvoiceWithPrice(req, res) {
  const timer = new Timer('controller.invoiceWithPrice', defaultTimeout);
  await timer.start();
  try {
    res.removeHeader('x-frame-options');
    winston.info(`Retrieving Salesforce pdf ${req.query.case_id}`);

    let conn = await getConnection();
    await conn.identity();

    let credentialsRaw = await get(
      REDIS.SALESFORCE_API_CACHE,
      REDIS.SALESFORCE_OAUTH_CREDENTIALS
    );
    if (!credentialsRaw) {
      return reject(
        new Error(`Please initiate server-side authentication for Salesforce`)
      );
    }
    let credentials = JSON.parse(credentialsRaw);
    let { instanceUrl, accessToken } = credentials;
    const url = `${instanceUrl}/apex/Ortho_SurgerySheetPdf?id=${
      req.query.case_id
    }&WithOrWithoutPriceString=_SurgSheet_WPrice&showHidePriceFlag=${
      req.query.toggle_price_flag
    }&showImages=true`;
    const pdfStream = await axios({
      method: 'get',
      url,
      responseType: 'stream',
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename="SurgerySheet.pdf"');

    pdfStream.data.pipe(res);
    await timer.stop();
  } catch (error) {
    let code = 500;
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}

async function getInvoiceWithoutPrice(req, res) {
  const timer = new Timer('controller.invoiceWithoutPrice', defaultTimeout);
  await timer.start();
  try {
    res.removeHeader('x-frame-options');
    winston.info(`Retrieving Salesforce pdf ${req.query.case_id}`);

    let conn = await getConnection();
    await conn.identity();

    let credentialsRaw = await get(
      REDIS.SALESFORCE_API_CACHE,
      REDIS.SALESFORCE_OAUTH_CREDENTIALS
    );
    if (!credentialsRaw) {
      return reject(
        new Error(`Please initiate server-side authentication for Salesforce`)
      );
    }
    let credentials = JSON.parse(credentialsRaw);
    let { instanceUrl, accessToken } = credentials;
    const url = `${instanceUrl}/apex/Ortho_SurgerySheetPdf?id=${
      req.query.case_id
    }&WithOrWithoutPriceString=_SurgSheet_WoPrice_&showHidePriceFlag=${
      req.query.toggle_price_flag
    }&showImages=true`;
    const pdfStream = await axios({
      method: 'get',
      url,
      responseType: 'stream',
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'inline; filename="SurgerySheet.pdf"');

    pdfStream.data.pipe(res);
    await timer.stop();
  } catch (error) {
    let code = 500;
    if (error.name && error.name == 'TokenExpiredError') {
      code = 401;
    }
    await timer.stop();
    return res.status(code).json(error);
  }
}
