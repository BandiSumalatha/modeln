const { herokuConnectClient } = require('./../services/knex');

module.exports = async function storageExistCheck(userRep) {
  const storageExists = await herokuConnectClient
    .withSchema('salesforce')
    .select(1)
    .from('invlocation__c')
    .where('userid__c', userRep)
    .whereNotNull('branchid__c');
  return storageExists.length > 0;
};
