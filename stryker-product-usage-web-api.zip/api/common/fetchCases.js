const moment = require("moment");

const { herokuConnectClient } = require("./../services/knex");
const storageExistCheck = require("./storageExist");
module.exports = {
  fetchCases,
  findCaseProcedures,
  getScansForTPR,
  findSetsWithParts,
  findSetsWithPartsByExternalIds,
};
async function fetchCases(singleFilter) {
  let { externalId, sfId, name } = singleFilter || {};
  if (externalId && externalId !== "null") {
    sfId = null;
    name = null;
  } else if (sfId && sfId !== "null") {
    externalId = null;
    name = null;
  } else {
    sfId = null;
    externalId = null;
    if (name && name.split('-').length > 2) {
      const sections = name.split('-');
      name = sections[0] + '-' + sections[1];
    }
  }
  if (!externalId && !sfId && !name) {
    return [];
  }
  try {
    let query = herokuConnectClient
      .withSchema("salesforce")
      .select(
        "cases__c.external_id__c AS externalId",
        "cases__c.sfid AS sfId",
        herokuConnectClient.raw(
          `COALESCE(cases__c.name, 'Case ID TBD') as "caseId"`
        ),
        "user.name AS salesRep",
        herokuConnectClient.raw(`CASE WHEN cases__c.webops_create_status__c like 'Failed%' THEN
            cases__c.webops_create_errormsg__c end as "webOpsCreatedErrorMessage"`),
        herokuConnectClient.raw(`CASE WHEN cases__c.webops_requested_status__c like 'Failed%' THEN
            cases__c.webops_requested_errormsg__c end AS "webOpsRequestedErrorMessage"`),
        herokuConnectClient.raw(`CASE WHEN cases__c.webops_completed_status__c like 'Failed%' THEN
          cases__c.webops_completed_errormsg__c end AS "webOpsCompletedErrorMessage"`),
        herokuConnectClient.raw(`CASE WHEN cases__c.webops_integration_status__c like 'Failed%' 
          AND NOT cases__c.webops_create_status__c like 'Failed%'
          AND NOT cases__c.webops_requested_status__c like 'Failed%'
          AND NOT cases__c.webops_completed_status__c like 'Failed%'
          THEN cases__c.webops_integrity_error_message__c end AS "webOpsIntegrityErrorMessage"`),
        herokuConnectClient.raw(
          `COALESCE(cases__c.createddate, now() at time zone 'utc') as "createdDate"`
        ),
        "cases__c.surgery_start_date_time__c as surgeryDate",
        "cases__c.patient_info__c as patientId",
        "cases__c.urgentreplenish__c as urgentreplenish",
        herokuConnectClient.raw(
          `CONCAT (contact.surgeon_erp_code__c, ' - ', contact.name) AS "surgeonName"`
        ),
        herokuConnectClient.raw(
          `CONCAT (contact.surgeon_erp_code__c, ' - ', contact.name) AS "surgeonNoName"`
        ),
        "branch__c.name AS branch",
        "branch__c.sfid as branchSfId",
        "cases__c.status__c AS status",
        "cases__c.cap_price__c AS capPrice",
        "cases__c.adapt__c AS adapt",
        "cases__c.ship_to__c AS shipTo",
        "cases__c.shipping_date__c AS shippingDate",
        herokuConnectClient.raw(`CONCAT_WS('\n', "shipAddress"."oracle_site_number__c",
         CONCAT_WS(' ',"shipAddress"."subinv_description__c"), 
         CONCAT_WS(' ',"shipAddress"."address1__c", "shipAddress"."address2__c"),
         CONCAT_WS(' ', "shipAddress"."city__c", "shipAddress"."state_province__c", "shipAddress"."postalcode__c")) AS "shippingAddress"`),
        herokuConnectClient.raw(`CONCAT_WS('\n', "billingAddress"."oracle_site_number__c",
         CONCAT_WS(' ',"billingAddress"."subinv_description__c"),         
         CONCAT_WS(' ',"billingAddress"."address1__c", "billingAddress"."address2__c"),
         CONCAT_WS(' ', "billingAddress"."city__c", "billingAddress"."state_province__c", "billingAddress"."postalcode__c")) AS "billingToAddress"`),
        "shipAddress.name AS address_name",
        "shipAddress.oracle_site_number__c AS address_site_number",
        "shipAddress.address1__c",
        "shipAddress.address2__c",
        "shipAddress.city__c",
        "shipAddress.state_province__c",
        "shipAddress.postalcode__c",
        "shipAddress.subinv_name__c",
        "shipAddress.subinv_description__c",
        "cases__c.kitdelivery_date__c AS deliveryDate",
        "cases__c.return_date_text__c AS returnDate",
        herokuConnectClient.raw(
          `CONCAT (account.accountnumber, ' - ', account.name) AS "hospitalName"`
        ),
        herokuConnectClient.raw(
          `CONCAT (account.accountnumber, ' - ', account.name) AS "hospitalNoName"`
        ),
        "cases__c.division__c AS division",
        "cases__c.delivery_options__c AS deliveryOption",
        "cases__c.case_coverage__c AS internalComment",
        "cases__c.revisions__c AS revision",
        "cases__c.kit_assigner__c AS userRep",
        "cases__c.cancel_reason__c AS cancelReason",
        "cases__c.cancel_comment__c AS cancelComment",
        "cases__c.left__c AS left",
        "cases__c.right__c AS right",
        "cases__c.mako__c AS mako",
        "cases__c.as1__c AS as1",
        "cases__c.charges__c AS freightCharges",
        "cases__c.is_hospital_owned__c AS is_hospital_owned",
        "cases__c.community_case__c AS communityCase",
        "cases__c.favourite__c AS favoriteCase",
        "cases__c.hospitalid__c",
        "cases__c.hospital_staffid__c",
        "cases__c.hospital_location__c",
        "cases__c.patient_gender__c AS patient_gender",
        "account.accountnumber as hospSiteNo",
        "hospLocation.address1__c as hospAddress",
        "hospLocation.oracle_site_number__c as hospAddrSiteNo",
        "hospLocation.primary_address_flag__c as hospAddrPrimary",
        "hospLocation.subinv_name__c as subInvName",
        "hospLocation.subinv_description__c as subInvDesc",
        "cases__c.ship_toaddress__r__external_id__c",
        "cases__c.ship_toaddress__c",

        herokuConnectClient.raw(
          `COALESCE(contact.lastname, 'N/A') AS "surgeonLastName"`
        ),
        herokuConnectClient.raw(
          `COALESCE(contact.firstname, 'N/A') AS "surgeonFirstName"`
        ),
        herokuConnectClient.raw(
          `COALESCE(contact.email, 'N/A') AS "surgeonEmail"`
        ),
        "cases__c.branchid__c AS caseBranchId",
        herokuConnectClient.raw(
          `"lastModifiedUser".name AS "lastModifiedByUser"`
        ),
        'cases__c.lastmodifieddate AS lastModifiedDate',
        'cases__c.hospital_printed_name__c AS signatureHospitalRepName',
        'cases__c.rep_printed_name__c AS signatureSalesRepName',
        'cases__c.external_comments__c AS externalComments',
        'cases__c.po_uploaded__c AS pouploaded',
        'cases__c.quickquote_code__c AS QuickQuoteCode',
        'cases__c.quickquote_rationale__c AS QuickQuoteRationale',
        'cases__c.signature_source__c',
        'cases__c.covering_reps__c',
        'cases__c.usgreject_comments__c',
        'cases__c.total_cap_price__c',
        'cases__c.usage_finalamount__c',
        'cases__c.quickquote_code__c',
        'cases__c.quickquote_rationale__c',
        'cases__c.webops_id__c',
        'cases__c.region_filter__c AS subBranch',
        'subBranch.name AS subBranchName',
        'cases__c._hc_lastop',
        'cases__c.surgery_date_confirmed__c',
        'cases__c.procedureid__c',
        'cases__c.procedure_list__c'
      )
      .from('cases__c')
      .innerJoin('account', 'cases__c.hospitalid__c', 'account.sfid')
      .innerJoin('branch__c', 'cases__c.branchid__c', 'branch__c.sfid')
      .leftJoin('branch__c as subBranch', 'cases__c.region_filter__c', 'subBranch.sfid')
      .innerJoin(
        "user AS lastModifiedUser",
        "cases__c.lastmodifiedbyid",
        "lastModifiedUser.sfid"
      )
      .leftJoin("user", "cases__c.kit_assigner__c", "user.sfid")
      .leftOuterJoin(
        "address__c as hospLocation",
        "hospLocation.sfid",
        "cases__c.hospital_location__c"
      )
      .leftOuterJoin("contact", "cases__c.hospital_staffid__c", "contact.sfid")
      .leftOuterJoin("address__c as shipAddress", function() {
        this.on(
          herokuConnectClient.raw(`("cases__c"."ship_toaddress__c" = "shipAddress"."sfid" AND "shipAddress"."external_id__c" IS NULL)
        OR ("cases__c"."ship_toaddress__r__external_id__c" = "shipAddress"."external_id__c" AND "shipAddress"."external_id__c" IS NOT NULL)
        OR ("cases__c"."ship_toaddress__c" IS NULL and "hospLocation".sfid = "shipAddress".sfid)`)
        );
      })
      .leftOuterJoin("address__c as billingAddress", function() {
        this.on(
          herokuConnectClient.raw(`("cases__c"."billing_toaddress__c" = "billingAddress"."sfid"  AND "billingAddress"."external_id__c" IS NULL
        )
        OR ("cases__c"."billing_toaddress__r__external_id__c" = "billingAddress"."external_id__c" AND "billingAddress"."external_id__c" IS NOT NULL)`)
        );
      })
      .orderBy("cases__c.surgery_start_date_time__c");

    if (externalId) {
      query.where("cases__c.external_id__c", externalId);
    } else if (sfId) {
      // sfid
      query.where("cases__c.sfid", sfId);
    } else {
      // name
      query.where("cases__c.name", name.toUpperCase());
    }

    let myCases = await query;
    if (myCases) {
      if (myCases.length === 1) {
        const userRep = myCases[0].userRep;
        if (userRep) {
          myCases[0].storageExist = await storageExistCheck(userRep);
        }
        if (!externalId && !sfId) {
          if (myCases[0].sfId) {
            sfId = myCases[0].sfId
          }
          else {
            externalId = myCases[0].externalId;
          }
        }
      }

      let casesMap = new Map();
      for (const caseObj of myCases) {
        caseObj.salesTeamsSFIDs = "";
        caseObj.coveringRepsSFIDs = "";
        caseObj.coveringRep = "";

        const surgeryDate = moment(caseObj.surgeryDate);
        caseObj.surgeryDate = surgeryDate.toISOString();

        caseObj.procedures = [];
        caseObj.caseRepsData = [];
        caseObj.tprId = [];
        caseObj.scanDetails = [];
        caseObj.sets = [];
        caseObj.parts = [];
        caseObj.usages = [];
        caseObj.additionalFees = [];
        caseObj.image = [];

        if (caseObj.externalId) {
          casesMap.set(caseObj.externalId, caseObj);
        }
        if (caseObj.sfId) {
          casesMap.set(caseObj.sfId, caseObj);
        }
        if (caseObj.userRep) {
          casesMap.set(caseObj.userRep, caseObj);
        }
      }

      /**
       * Sales team
       */

      const caseSalesTeamWithExternalIds = externalId
        ? await findSalesTeamByExternalIds({ externalId })
        : [];

      for (const team of caseSalesTeamWithExternalIds) {
        const myCase = casesMap.get(team.case_external_id);
        if (myCase) {
          myCase.salesTeamsSFIDs =
            team.salesTeamsSFIDs && team.salesTeamsSFIDs.length > 0
              ? team.salesTeamsSFIDs
                  .filter((salesTeamId) => salesTeamId)
                  .join(",")
              : "";
        }
      }

      const caseSalesTeam = sfId ? await findSalesTeam({ sfId }) : [];

      for (const team of caseSalesTeam) {
        const myCase = casesMap.get(team.case_sfid);
        if (myCase) {
          myCase.salesTeamsSFIDs =
            team.salesTeamsSFIDs && team.salesTeamsSFIDs.length > 0
              ? team.salesTeamsSFIDs
                  .filter((salesTeamId) => salesTeamId)
                  .join(",")
              : "";
        }
      }

      /**
       * Covering rep
       */

      const coveringRepsWithExternalIds = externalId
        ? await findCaseCoveringRepsByExternalIds({ externalId })
        : [];

      for (const rep of coveringRepsWithExternalIds) {
        const myCase = casesMap.get(rep.case_external_id);
        if (myCase) {
          myCase.coveringRepsSFIDs = rep.coveringRepsSFIDs;
          myCase.coveringRep = rep.coveringRep;
        }
      }

      const coveringReps = sfId ? await findCaseCoveringReps({ sfId }) : [];

      for (const rep of coveringReps) {
        const myCase = casesMap.get(rep.case_sfid);
        if (myCase) {
          myCase.coveringRepsSFIDs = rep.coveringRepsSFIDs;
          myCase.coveringRep = rep.coveringRep;
        }
      }

      /**
       * Set procedure in case
       */

      const caseProceduresWithExternalIds = externalId
        ? await findCaseProceduresByExternalIds({ externalId })
        : [];

      for (const procedure of caseProceduresWithExternalIds) {
        const { case_external_id, sfid, name, cap_price__c } = procedure;
        const myCase = casesMap.get(case_external_id);
        if (myCase) {
          myCase.procedures.push({
            sfid,
            name,
            cap_price__c,
          });
        }
      }

      const caseProcedures = sfId ? await findCaseProcedures({ sfId }) : [];

      for (const procedure of caseProcedures) {
        const { case_sfid, sfid, name: caseName, cap_price__c } = procedure;
        const myCase = casesMap.get(case_sfid);
        if (myCase) {
          myCase.procedures.push({
            sfid,
            name: caseName,
            cap_price__c,
          });
        }
      }

      for (const caseObj of myCases) {
        if (caseObj.procedures.length == 0) {
          const procedureIds = caseObj.procedureid__c ? caseObj.procedureid__c.split(',') : [];
          const procedureNames = caseObj.procedure_list__c ? caseObj.procedure_list__c.split(',') : [];
          if (procedureIds.length == procedureNames.length) {
            for(let i=0; i<procedureIds.length; i++) {
              caseObj.procedures.push({
                case_sfid: caseObj.sfId,
                case_external_id: caseObj.externalId,
                name: procedureNames[i],
                sfid: procedureIds[i],
                cap_price__c: null
              });
            }
          }
        }
      }

      const caseRepsDetails = sfId
        ? await findCaseRepsDetails({
            sfId,
          })
        : [];

      for (const caseRep of caseRepsDetails) {
        const {
          case_sfid,
          user_id,
          full_name,
          first_name,
          last_name,
          email,
          sales_rep_email
        } = caseRep;
        const myCase = casesMap.get(case_sfid);
        if (myCase) {
          let rep_type;
          if (myCase.userRep === user_id) {
            if (myCase.coveringRepsSFIDs.indexOf(user_id) !== -1) {
              myCase.caseRepsData.push({
                user_id,
                full_name,
                first_name,
                last_name,
                email,
                sales_rep_email,
                rep_type: 'Covering Rep',
              });              
            }
            rep_type = "Sales Rep";
          } else {
            rep_type = "Covering Rep";
          }
          myCase.caseRepsData.push({
            user_id,
            full_name,
            first_name,
            last_name,
            email,
            sales_rep_email,
            rep_type,
          });
        }
      }

      const caseRepsDetailsByExtId = externalId
        ? await findCaseRepsDetailsByExternalId({
            externalId,
          })
        : [];

      for (const caseRep of caseRepsDetailsByExtId) {
        const {
          case_external_id,
          user_id,
          full_name,
          first_name,
          last_name,
          email,
          sales_rep_email
        } = caseRep;
        const myCase = casesMap.get(case_external_id);
        if (myCase) {
          let rep_type;
          if (myCase.userRep === user_id) {
            if (myCase.coveringRepsSFIDs.indexOf(user_id) !== -1) {
              myCase.caseRepsData.push({
                user_id,
                full_name,
                first_name,
                last_name,
                email,
                sales_rep_email,
                rep_type: 'Covering Rep',
              });              
            }
            rep_type = "Sales Rep";
          } else {
            rep_type = "Covering Rep";
          }
          myCase.caseRepsData.push({
            user_id,
            full_name,
            first_name,
            last_name,
            email,
            sales_rep_email,
            rep_type,
          });
        }
      }

      const tprExternalIds = sfId
        ? await getTPRonCase({
            sfId,
          })
        : [];

      for (const tprExtId of tprExternalIds) {
        const {
          case_sfid,
          tpr_rhs_id,
          tpr_sfid,
          external_id,
          tpr_name,
          tpr_status,
          tpr_opened,
          tpr_internal_comments,
          treatment_plan_id
        } = tprExtId;
        const myCase = casesMap.get(case_sfid);
        if (myCase) {
          myCase.tprId.push({
            tpr_rhs_id,
            tpr_sfid,
            external_id,
            tpr_name,
            tpr_status,
            tpr_opened,
            tpr_internal_comments,
            treatment_plan_id,
            scans: []
          });
        }
      }

      const tprExternalIdsWithExtId = externalId
        ? await getTPRonCaseByExternalId({
            externalId,
          })
        : [];

      for (const tprExtId of tprExternalIdsWithExtId) {
        const {
          case_external_id,
          tpr_rhs_id,
          tpr_sfid,
          external_id,
          tpr_name,
          tpr_status,
          tpr_opened,
          tpr_internal_comments,
          treatment_plan_id
        } = tprExtId;
        const myCase = casesMap.get(case_external_id);
        if (myCase) {
          myCase.tprId.push({
            tpr_rhs_id,
            tpr_sfid,
            external_id,
            tpr_name,
            tpr_status,
            tpr_opened,
            tpr_internal_comments,
            treatment_plan_id,
            scans: []
          });
        }
      }

      const scan_details = sfId ? await getScanOnTPR({ sfId }) : [];
      const scanMap = {};

      for (const scan_detail of scan_details) {
        const {
          case_sfid,
          scan_rhs_id,
          scan_sfid,
          external_id,
          scan_name,
          upload_by,
          upload_date,
          active,          
          patient_scan_id,
          patient_scan_modified_date,
          referring_physician,
          total_number_of_images,
          isManualUpload,
          tpr_name,
          ispatientscan__c,
          issurgicalplan__c
        } = scan_detail;
        const myCase = casesMap.get(case_sfid);
        if (myCase) {
          const scan = {
            scan_rhs_id,
            scan_sfid,
            external_id,
            scan_name,
            upload_by,
            upload_date,
            active,
            patient_scan_id,
            patient_scan_modified_date,
            referring_physician,
            total_number_of_images,
            isManualUpload,
            tpr_name,
            ispatientscan__c,
            issurgicalplan__c
          };
          myCase.scanDetails.push(scan);
          if (scanMap[tpr_name]) {
            scanMap[tpr_name].push(scan);
          }
          else {
            scanMap[tpr_name] = [ scan ];
          }
        }
      }

      const scan_details_extid = externalId
        ? await getScanOnTPRByExternalId({ externalId })
        : [];

      for (const scan_detail of scan_details_extid) {
        const {
          case_external_id,
          scan_rhs_id,
          scan_sfid,
          external_id,
          scan_name,
          upload_by,
          upload_date,
          active,
          patient_scan_id,
          patient_scan_modified_date,
          referring_physician,
          total_number_of_images,
          isManualUpload,
          tpr_name,
          ispatientscan__c,
          issurgicalplan__c
        } = scan_detail;
        const myCase = casesMap.get(case_external_id);
        if (myCase) {
          const scan = {
            scan_rhs_id,
            scan_sfid,
            external_id,
            scan_name,
            upload_by,
            upload_date,
            active,
            patient_scan_id,
            patient_scan_modified_date,
            referring_physician,
            total_number_of_images,
            isManualUpload,
            tpr_name,
            ispatientscan__c,
            issurgicalplan__c
          };
          myCase.scanDetails.push(scan);
          if (scanMap[tpr_name]) {
            scanMap[tpr_name].push(scan);
          }
          else {
            scanMap[tpr_name] = [ scan ];
          }
        }
      }

      for (const myCase of myCases) {
        for (const tpr of myCase.tprId) {
          if (scanMap[tpr.tpr_name]) {
            tpr.scans = [ ...scanMap[tpr.tpr_name] ];
          }
        }
      }

      /**
       * Sets
       */
      const casesSetsWithExternalIds = externalId
        ? await findSetsWithPartsByExternalIds({ externalId })
        : [];

      for (const set of casesSetsWithExternalIds) {
        const {
          category__c,
          productsystemname__c,
          setType,
          set_name,
          set_id,
        } = set;

        // we can get records with set_id as null due to unkonwn reasons from salesforce
        if (set_id) {
          const myCase = casesMap.get(externalId);
          if (myCase) {
            const setName =
              setType === "Consignment"
                ? set_name
                : myCase.division && myCase.division !== "Spine"
                  ? productsystemname__c
                  : category__c;

            myCase.sets.push({
              ...set,
              set_name: setName,
            });
          }
        }
      }

      const casesSets = sfId ? await findSetsWithParts({ sfId }) : [];

      for (const set of casesSets) {
        const {
          category__c,
          productsystemname__c,
          setType,
          set_name,
          set_id,
        } = set;

        // we can get records with set_id as null due to unkonwn reasons from salesforce
        if (set_id) {
          const myCase = casesMap.get(sfId);
          if (myCase) {
            const setName =
              setType === "Consignment"
                ? set_name
                : myCase.division && myCase.division !== "Spine"
                  ? productsystemname__c
                  : category__c;

            myCase.sets.push({
              ...set,
              set_name: setName,
            });
          }
        }
      }

      /**
       * Parts
       */

      const casesPartsWithExternalIds = externalId
        ? await findPartsByExternalIds({ externalId })
        : [];

      for (const part of casesPartsWithExternalIds) {
        const myCase = casesMap.get(externalId);
        if (myCase) {
          myCase.parts.push(part);
        }
      }

      const casesParts = sfId
        ? await findParts({
            sfId,
          })
        : [];

      for (const part of casesParts) {
        const myCase = casesMap.get(sfId);
        if (myCase) {
          myCase.parts.push(part);
        }
      }

      /**
       * Usages
       */

      const casesUsagesWithExternalIds = externalId
        ? await findCaseUsagesByExternalIds({ externalId })
        : [];

      for (const caseUsage of casesUsagesWithExternalIds) {
        const myCase = casesMap.get(
          caseUsage.surgical_cases__r__external_id__c
        );
        if (myCase) {
          myCase.usages.push(caseUsage);
        }
      }

      const casesUsages = sfId ? await findCaseUsages({ sfId }) : [];

      for (const caseUsage of casesUsages) {
        const myCase = casesMap.get(caseUsage.surgical_cases__c);
        if (myCase) {
          myCase.usages.push(caseUsage);
        }
      }

      /**
       * additionalFees
       */

      const additionalFeesWithExternalIds = externalId
        ? await findCaseUsagesOtherFeeByExternalIds({ externalId })
        : [];

      for (const fee of additionalFeesWithExternalIds) {
        const myCase = casesMap.get(fee.surgical_case__r__external_id__c);
        if (myCase) {
          myCase.additionalFees.push(fee);
        }
      }

      const additionalFees = sfId ? await findCaseUsagesOtherFee({ sfId }) : [];

      for (const fee of additionalFees) {
        const myCase = casesMap.get(fee.surgical_case__c);
        if (myCase) {
          myCase.additionalFees.push(fee);
        }
      }

      /**
       * Image
       */

      const imagesWithExternalIds = externalId
        ? await findCaseUsageImagesByExternalIds({ externalId })
        : [];

      for (const addImage of imagesWithExternalIds) {
        const myCase = casesMap.get(addImage.CaseExternalId);
        if (myCase) {
          myCase.image.push(addImage);
        }
      }

      const images = sfId ? await findCaseUsageImages({ sfId }) : [];

      for (const addImage of images) {
        const myCase = casesMap.get(addImage.CaseSfid);
        if (myCase) {
          myCase.image.push(addImage);
        }
      }
      return [...myCases];
    }
  } catch (ex) {
    console.log(ex);
    return [];
  }
}

function queryFilterAppender({ query, sfId, externalId }) {
  if (sfId) {
    query.where("cases__c.sfid", sfId);
  } else {
    query.where("cases__c.external_id__c", externalId);
  }
}

function findSalesTeam({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.sfid AS case_sfid",
      herokuConnectClient.raw(
        `array_agg(DISTINCT "teammates".podid__c) AS "salesTeamsSFIDs"`
      )
    )
    .from("cases__c")

    .innerJoin("surgical_case_sales_team__c", function() {
      this.on(
        "surgical_case_sales_team__c.surgical_cases__c",
        "=",
        "cases__c.sfid"
      );
    })
    .innerJoin("branch__c", "branch__c.sfid", "cases__c.branchid__c")
    .innerJoin("branchuserpod__c as teammates", function() {
      this.on(
        "teammates.userid__c",
        "=",
        "surgical_case_sales_team__c.sales_rep__c"
      ).andOn("teammates.branch__c", "=", "branch__c.sfid");
    });
  queryFilterAppender({ query, sfId });

  query.groupBy("cases__c.sfid");
  return query;
}

function findSalesTeamByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.external_id__c AS case_external_id",
      herokuConnectClient.raw(
        `array_agg(DISTINCT "teammates".podid__c) AS "salesTeamsSFIDs"`
      )
    )
    .from("cases__c")
    .innerJoin("surgical_case_sales_team__c", function() {
      this.on(
        "surgical_case_sales_team__c.surgical_cases__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("branch__c", "branch__c.sfid", "cases__c.branchid__c")
    .innerJoin("branchuserpod__c as teammates", function() {
      this.on(
        "teammates.userid__c",
        "=",
        "surgical_case_sales_team__c.sales_rep__c"
      ).andOn("teammates.branch__c", "=", "branch__c.sfid");
    });
  queryFilterAppender({ query, externalId });

  query.groupBy("cases__c.external_id__c");
  return query;
}

function findCaseProcedures({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.sfid AS case_sfid",
      "procedure__c.name",
      "procedure__c.sfid",
      "cases__c.total_cap_price__c AS cap_price__c"
    )
    .from("cases__c")
    .innerJoin(
      "procedure__c",
      "cases__c.procedureid__c",
      "procedure__c.sfid"
    );
  queryFilterAppender({ query, sfId });

  return query;
}

function findCaseProceduresByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.external_id__c AS case_external_id",
      "procedure__c.name",
      "procedure__c.sfid",
      "cases__c.total_cap_price__c AS cap_price__c"
    )
    .from("cases__c")
    .innerJoin(
      "procedure__c",
      "cases__c.procedureid__c",
      "procedure__c.sfid"
    );
  queryFilterAppender({ query, externalId });

  return query;
}

function findCaseCoveringReps({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "surgical_cases__c AS case_sfid",
      herokuConnectClient.raw(
        `string_agg(DISTINCT "coveringReps".name, ', ' ORDER BY "coveringReps".name ASC) AS "coveringRep"`
      ),
      herokuConnectClient.raw(
        `string_agg(DISTINCT "coveringReps".sfid, ',') AS "coveringRepsSFIDs"`
      )
    )
    .from("surgical_case_sales_team__c")
    .innerJoin(
      "cases__c",
      "cases__c.sfid",
      "surgical_case_sales_team__c.surgical_cases__c"
    )
    .leftJoin(
      "user AS coveringReps",
      "surgical_case_sales_team__c.sales_rep__c",
      "coveringReps.sfid"
    );
  queryFilterAppender({ query, sfId });
  query.groupBy("surgical_case_sales_team__c.surgical_cases__c");
  return query;
}

function findCaseCoveringRepsByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "surgical_cases__r__external_id__c AS case_external_id",
      herokuConnectClient.raw(
        `string_agg(DISTINCT "coveringReps".name, ', ' ORDER BY "coveringReps".name ASC) AS "coveringRep"`
      ),
      herokuConnectClient.raw(
        `string_agg(DISTINCT "coveringReps".sfid, ',') AS "coveringRepsSFIDs"`
      )
    )
    .from("surgical_case_sales_team__c")
    .innerJoin(
      "cases__c",
      "cases__c.external_id__c",
      "surgical_case_sales_team__c.surgical_cases__r__external_id__c"
    )
    .leftJoin(
      "user AS coveringReps",
      "surgical_case_sales_team__c.sales_rep__c",
      "coveringReps.sfid"
    );
  queryFilterAppender({ query, externalId });
  query.groupBy(
    "surgical_case_sales_team__c.surgical_cases__r__external_id__c"
  );
  return query;
}

function findCaseRepsDetails({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "surgical_cases__c AS case_sfid",
      "user.sfid AS user_id",
      "user.name AS full_name",
      "user.firstname AS first_name",
      "user.lastname AS last_name",
      "user.federationidentifier AS email",
      "user.email AS sales_rep_email"
    ])
    .from("surgical_case_sales_team__c")
    .innerJoin(
      "cases__c",
      "cases__c.sfid",
      "surgical_case_sales_team__c.surgical_cases__c"
    )
    .leftJoin("user", "surgical_case_sales_team__c.sales_rep__c", "user.sfid");
  queryFilterAppender({ query, sfId });
  return query;
}

function findCaseRepsDetailsByExternalId({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "surgical_cases__r__external_id__c AS case_external_id",
      "user.sfid AS user_id",
      "user.name AS full_name",
      "user.firstname AS first_name",
      "user.lastname AS last_name",
      "user.federationidentifier AS email",
      "user.email AS sales_rep_email"
    ])
    .from("surgical_case_sales_team__c")
    .innerJoin(
      "cases__c",
      "cases__c.external_id__c",
      "surgical_case_sales_team__c.surgical_cases__r__external_id__c"
    )
    .leftJoin("user", "surgical_case_sales_team__c.sales_rep__c", "user.sfid");
  queryFilterAppender({ query, externalId });
  return query;
}

function getTPRonCase({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.sfid AS case_sfid",
      "tpr.external_tpr_id__c AS tpr_rhs_id",
      "tpr.sfid AS tpr_sfid",
      "tpr.external_id__c AS external_id",
      "tpr.name AS tpr_name",
      "tpr.status__c AS tpr_status",
      "tpr.tpr_opened__c AS tpr_opened",
      "tpr.internal_comments__c AS tpr_internal_comments",
      "tpr.treatment_plan_id__c AS treatment_plan_id",
    )
    .from("cases__c")
    .innerJoin("surgical_case_products__c AS product", function() {
      this.on("product.surgical_case__c", "=", "cases__c.sfid").orOn(
        "product.surgical_case__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("treatment_plan_request__c AS tpr", function() {
      this.on("tpr.surgical_case_details__c", "=", "product.sfid").orOn(
        "tpr.surgical_case_details__r__external_id__c",
        "=",
        "product.external_id__c"
      );
    });
  queryFilterAppender({ query, sfId });
  return query;
}

function getTPRonCaseByExternalId({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.external_id__c AS case_external_id",
      "tpr.external_tpr_id__c AS tpr_rhs_id",
      "tpr.sfid AS tpr_sfid",
      "tpr.external_id__c AS external_id",
      "tpr.name AS tpr_name",
      "tpr.status__c AS tpr_status",
      "tpr.tpr_opened__c AS tpr_opened",
      "tpr.internal_comments__c AS tpr_internal_comments",
      "tpr.treatment_plan_id__c AS treatment_plan_id",
    )
    .from("cases__c")
    .innerJoin("surgical_case_products__c AS product", function() {
      this.on("product.surgical_case__c", "=", "cases__c.sfid").orOn(
        "product.surgical_case__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("treatment_plan_request__c AS tpr", function() {
      this.on("tpr.surgical_case_details__c", "=", "product.sfid").orOn(
        "tpr.surgical_case_details__r__external_id__c",
        "=",
        "product.external_id__c"
      );
    });
  queryFilterAppender({ query, externalId });
  return query;
}

function getScansForTPR({ tprSfid, tprExternalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.sfid AS case_sfid",
      "cases__c.external_id__c AS case_external_id__c",
      "tpr.name AS tpr_name",
      "scan.patientscanid__c AS scan_rhs_id",
      "scan.sfid AS scan_sfid",
      "scan.external_id__c AS external_id",
      "scan.descriptor__c AS scan_name",
      "scan.patient_scan_uploaded_by__c AS upload_by",
      "scan.patient_scan_uploaded_date__c AS upload_date",
      "scan.is_active__c AS active",
      "scan.ispatientscan__c",
      "scan.issurgicalplan__c"
    )
    .from("cases__c")
    .innerJoin("surgical_case_products__c AS product", function() {
      this.on("product.surgical_case__c", "=", "cases__c.sfid").orOn(
        "product.surgical_case__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("treatment_plan_request__c AS tpr", function() {
      this.on("tpr.surgical_case_details__c", "=", "product.sfid").orOn(
        "tpr.surgical_case_details__r__external_id__c",
        "=",
        "product.external_id__c"
      );
    })
    .innerJoin("patient_scan__c AS scan", function() {
      this.on("scan.tpr_id__c", "=", "tpr.sfid").orOn(
        "scan.tpr_id__r__external_id__c",
        "=",
        "tpr.external_id__c"
      );
    });

  if (tprSfid) {
    query = query.where('tpr.sfid', tprSfid);
    return query;
  }
  else if (tprExternalId) {
    query = query.where('tpr.external_id__c', tprExternalId);
    return query;
  } 

  return Promise.resolve([]);
}

function getScanOnTPR({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.sfid AS case_sfid",
      "tpr.name AS tpr_name",
      "scan.patientscanid__c AS scan_rhs_id",
      "scan.sfid AS scan_sfid",
      "scan.external_id__c AS external_id",
      "scan.descriptor__c AS scan_name",
      "scan.patient_scan_uploaded_by__c AS upload_by",
      "scan.patient_scan_uploaded_date__c AS upload_date",
      "scan.is_active__c AS active",
      "scan.ispatientscan__c",
      "scan.issurgicalplan__c"
    )
    .from("cases__c")
    .innerJoin("surgical_case_products__c AS product", function() {
      this.on("product.surgical_case__c", "=", "cases__c.sfid").orOn(
        "product.surgical_case__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("treatment_plan_request__c AS tpr", function() {
      this.on("tpr.surgical_case_details__c", "=", "product.sfid").orOn(
        "tpr.surgical_case_details__r__external_id__c",
        "=",
        "product.external_id__c"
      );
    })
    .innerJoin("patient_scan__c AS scan", function() {
      this.on("scan.tpr_id__c", "=", "tpr.sfid").orOn(
        "scan.tpr_id__r__external_id__c",
        "=",
        "tpr.external_id__c"
      );
    });
  queryFilterAppender({ query, sfId });
  return query;
}

function getScanOnTPRByExternalId({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "cases__c.external_id__c AS case_external_id",
      "tpr.name AS tpr_name",
      "scan.patientscanid__c AS scan_rhs_id",
      "scan.sfid AS scan_sfid",
      "scan.external_id__c AS external_id",
      "scan.descriptor__c AS scan_name",
      "scan.patient_scan_uploaded_by__c AS upload_by",
      "scan.patient_scan_uploaded_date__c AS upload_date",
      "scan.is_active__c AS active",
      "scan.patientscanid__c AS patient_scan_id",
      "scan.patient_scan_modified_date__c AS patient_scan_modified_date",
      "scan.referring_physician__c AS referring_physician",
      "scan.total_number_of_images__c AS total_number_of_images",
      "scan.ismanualupload__c AS isManualUpload",
      "scan.ispatientscan__c",
      "scan.issurgicalplan__c"
    )
    .from("cases__c")
    .innerJoin("surgical_case_products__c AS product", function() {
      this.on("product.surgical_case__c", "=", "cases__c.sfid").orOn(
        "product.surgical_case__r__external_id__c",
        "=",
        "cases__c.external_id__c"
      );
    })
    .innerJoin("treatment_plan_request__c AS tpr", function() {
      this.on("tpr.surgical_case_details__c", "=", "product.sfid").orOn(
        "tpr.surgical_case_details__r__external_id__c",
        "=",
        "product.external_id__c"
      );
    })
    .innerJoin("patient_scan__c AS scan", function() {
      this.on("scan.tpr_id__c", "=", "tpr.sfid").orOn(
        "scan.tpr_id__r__external_id__c",
        "=",
        "tpr.external_id__c"
      );
    });
  queryFilterAppender({ query, externalId });
  return query;
}

function findCaseUsageImages({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "case_sfid AS CaseSfid",
      herokuConnectClient.raw(`COALESCE(signature_by, 'Images') AS Signature`),
      herokuConnectClient.raw(`string_agg(azure_image_url, ',') AS imageUrl`),
      herokuConnectClient.raw(`string_agg(thumbnail_url, ',') AS thumbnailUrl`),
      herokuConnectClient.raw(
        `string_agg(attachment_name, ',') AS attachmentname`
      ),
      herokuConnectClient.raw(`string_agg(attachment_id, ',') AS attachmentid`)
    )
    .from("case_images")
    .innerJoin("cases__c", "cases__c.sfid", "case_images.case_sfid");
  queryFilterAppender({ query, sfId });

  query.groupBy("case_images.case_sfid").groupBy("case_images.signature_by");

  return query;
}

function findCaseUsageImagesByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select(
      "case_external_id AS CaseExternalId",
      herokuConnectClient.raw(`COALESCE(signature_by, 'Images') AS Signature`),
      herokuConnectClient.raw(`string_agg(azure_image_url, ',') AS imageUrl`),
      herokuConnectClient.raw(`string_agg(thumbnail_url, ',') AS thumbnailUrl`),
      herokuConnectClient.raw(
        `string_agg(attachment_name, ',') AS attachmentname`
      ),
      herokuConnectClient.raw(`string_agg(attachment_id, ',') AS attachmentid`)
    )
    .from("case_images")
    .innerJoin(
      "cases__c",
      "cases__c.external_id__c",
      "case_images.case_external_id"
    );

  queryFilterAppender({ query, externalId });

  query
    .groupBy("case_images.case_external_id")
    .groupBy("case_images.signature_by");
  return query;
}

function findSetsWithParts({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "scpc.surgical_case__c AS case_sfid",
      herokuConnectClient.raw(`coalesce(ipsc.sfid,ps.sfid) AS set_id`),
      herokuConnectClient.raw(
        `coalesce(ipsc.name,ps.category__c, ps.productsystemname__c) AS "set_name"`
      ),
      herokuConnectClient.raw(
        `coalesce(ps.category__c, ps.productsystemname__c) AS "requested_set_name"`
      ),
      "ipsc.kit_no__c AS kit_no__c",
      "ps.category__c AS category__c",
      "ps.productsystemname__c AS productsystemname__c",
      "scpc.loaner__c AS loaner__c",
      "scpc.status__c AS status__c",
      "scpc.quantity__c AS quantity__c",
      "scpc.surgical_case__r__external_id__c AS external_id",
      "scpc.is_preference_product__c",
      "ps.sfid AS productSfid",
      herokuConnectClient.raw(
        `CASE 
         WHEN ipsc.sfid IS NOT NULL THEN 'Consignment' 
         ELSE 'Loaner'
        END AS "setType"`
      ),
    ])
    .from("surgical_case_products__c AS scpc")
    .innerJoin("cases__c", function() {
      this
        .on('cases__c.sfid', '=', 'scpc.surgical_case__c')
        .orOn('cases__c.external_id__c', '=', 'scpc.surgical_case__r__external_id__c')
    })
    .leftJoin(
      "inventory_product_system__c AS ipsc",
      "scpc.ips_id__c",
      "ipsc.sfid"
    )
    .leftJoin("product_system__c AS ps", "scpc.product_system__c", "ps.sfid")
    .innerJoin(
      "product_system_procedure_category__c as pspc",
      "pspc.product_system__c",
      "ps.sfid"
    )
    .innerJoin(
      "procedure_category__c as pc",
      "pc.sfid",
      "pspc.procedure_category__c"
    )
    .innerJoin("procedure__c as p", "p.sfid", "pc.procedure__c");

  query.where("cases__c.sfid", sfId);

  query.whereNull("scpc.product__c");
  query.where(function() {
    this
      .where("scpc.inactive__c", false)
      .orWhereNull("scpc.inactive__c")
  });
  query.where("pc.isactive__c", true);

  return query;
}

function findSetsWithPartsByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      herokuConnectClient.raw(`coalesce(ipsc.sfid,ps.sfid) AS set_id`),
      herokuConnectClient.raw(
        `coalesce(ipsc.name,ps.category__c, ps.productsystemname__c) AS "set_name"`
      ),
      herokuConnectClient.raw(
        `coalesce(ps.category__c, ps.productsystemname__c) AS "requested_set_name"`
      ),
      "ipsc.kit_no__c AS kit_no__c",
      "ps.category__c AS category__c",
      "ps.productsystemname__c AS productsystemname__c",
      "scpc.loaner__c AS loaner__c",
      "scpc.status__c AS status__c",
      "scpc.quantity__c AS quantity__c",
      "scpc.surgical_case__r__external_id__c AS external_id",
      "scpc.is_preference_product__c",
      "ps.sfid AS productSfid",
      herokuConnectClient.raw(
        `CASE 
         WHEN ipsc.sfid IS NOT NULL THEN 'Consignment' 
         ELSE 'Loaner'
        END AS "setType"`
      ),
    ])
    .from("surgical_case_products__c AS scpc")
    .innerJoin("cases__c", function() {
      this
        .on('cases__c.sfid', '=', 'scpc.surgical_case__c')
        .orOn('cases__c.external_id__c', '=', 'scpc.surgical_case__r__external_id__c')
    })
    .leftJoin("product_system__c AS ps", "scpc.product_system__c", "ps.sfid")
    .leftJoin(
      "inventory_product_system__c AS ipsc",
      "scpc.ips_id__c",
      "ipsc.sfid"
    )
    .innerJoin(
      "product_system_procedure_category__c as pspc",
      "pspc.product_system__c",
      "ps.sfid"
    )
    .innerJoin(
      "procedure_category__c as pc",
      "pc.sfid",
      "pspc.procedure_category__c"
    )
    .innerJoin("procedure__c as p", "p.sfid", "pc.procedure__c");

  query.where("cases__c.external_id__c", externalId);

  query.whereNull("scpc.product__c");
  query.where(function() {
    this
      .where("scpc.inactive__c", false)
      .orWhereNull("scpc.inactive__c")
  });
  query.where("pc.isactive__c", true);

  return query;
}

function findParts({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "scpc.surgical_case__c AS case_sfid",
      "p2.sfid AS product_sfid",
      "ic.sfid AS part_ipc_sfid",
      "ic.ipsid__c as set_id",
      herokuConnectClient.raw(
        `CONCAT (p2.catalog_number__c, ' - ', p2.description__c) AS part_name`
      ),
      "p2.lot_serial_control_code__c AS lot_serial_control_code__c",
      herokuConnectClient.raw(
        `CASE WHEN (p2.lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      ),
      "ic.quantity__c AS unit",
      herokuConnectClient.raw("COALESCE(ic.missing_quantity__c, 0) AS missingQty"),
      "ic.lot_number__c AS lot_number",
      "ic.itemcode__c AS serial",
      "ic.expiration_date__c AS expiration_date",
      "scpc.loaner__c AS loaner__c",
      "scpc.status__c AS status__c",
      "scpc.quantity__c AS quantity__c",
      "scpc.is_preference_product__c",
      herokuConnectClient.raw(
        `coalesce(p2.description, p3.description) as part_desc`
      ),
    ])
    .from("surgical_case_products__c AS scpc")
    .innerJoin("cases__c", function() {
      this
        .on('cases__c.sfid', '=', 'scpc.surgical_case__c')
        .orOn('cases__c.external_id__c', '=', 'scpc.surgical_case__r__external_id__c')
    })
    .innerJoin("invproductcomponent__c AS ic", "scpc.ips_id__c", "ic.ipsid__c")
    .innerJoin("product2 as p2", "p2.sfid", "ic.product__c")
    .leftOuterJoin(
      "productsubsystemcomponents__c as psc",
      "psc.sfid",
      "ic.productsubsyscompid__c"
    )
    .leftOuterJoin("product2 as p3", "p3.sfid", "psc.product__c");

  queryFilterAppender({ query, sfId });

  return query;
}

function findPartsByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "p2.sfid AS product_sfid",
      "ic.sfid AS part_ipc_sfid",
      "ic.ipsid__c as set_id",
      herokuConnectClient.raw(
        `CONCAT (p2.catalog_number__c, ' - ', p2.description__c) AS part_name`
      ),
      "p2.lot_serial_control_code__c AS lot_serial_control_code__c",
      herokuConnectClient.raw(
        `CASE WHEN (p2.lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      ),
      "ic.quantity__c AS unit",
      herokuConnectClient.raw("COALESCE(ic.missing_quantity__c, 0) AS missingQty"),
      "ic.lot_number__c AS lot_number",
      "ic.itemcode__c AS serial",
      "ic.expiration_date__c AS expiration_date",
      "scpc.loaner__c AS loaner__c",
      "scpc.status__c AS status__c",
      "scpc.quantity__c AS quantity__c",
      "scpc.surgical_case__r__external_id__c AS external_id",
      "scpc.is_preference_product__c",
      herokuConnectClient.raw(
        `coalesce(p2.description, p3.description) as part_desc`
      ),
    ])
    .from("surgical_case_products__c AS scpc")
    .innerJoin("cases__c", function() {
      this
        .on('cases__c.sfid', '=', 'scpc.surgical_case__c')
        .orOn('cases__c.external_id__c', '=', 'scpc.surgical_case__r__external_id__c')
    })
    .innerJoin("invproductcomponent__c AS ic", "scpc.ips_id__c", "ic.ipsid__c")
    .innerJoin("product2 as p2", "p2.sfid", "ic.product__c")
    .leftOuterJoin(
      "productsubsystemcomponents__c as psc",
      "psc.sfid",
      "ic.productsubsyscompid__c"
    )
    .leftOuterJoin("product2 as p3", "p3.sfid", "psc.product__c");

  queryFilterAppender({ query, externalId });

  return query;
}

function findCaseUsages({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "cuc.surgical_cases__c AS case_sfid",
      "p.sfid AS product_sfid",
      "ic.sfid AS part_ipc_sfid",
      "p.sfid AS part_id",
      "ic.sfid AS part_psfid",
      "ic.ipsid__c as set_id",
      herokuConnectClient.raw(
        `CONCAT (p.catalog_number__c, ' - ', p.description__c) AS part_name`
      ),
      'p.lot_serial_control_code__c AS lot_serial_control_code__c',
      herokuConnectClient.raw(
        `CASE WHEN (p.lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      ),
      'ic.quantity__c AS unit',
      'ic.missing_quantity__c AS missingQty',
      'cuc.name as usageName',
      'cuc.quantity__c AS quantity__c',
      'cuc.lot_number__c AS lot_number__c',
      'cuc.wasteds__c AS wasted',
      'cuc.side__c AS side__c',
      'cuc.usg_price__c AS usg_price__c',
      'cuc.used_from__c AS set_usages_id',
      'cuc.lot_controlled__c AS lot_controlled__c',
      'cuc.ship_to__c AS ship_to__c',
      'cuc.shipto_location__c AS shipto_location__c',
      'cuc.replenish__c AS replenish__c',
      'cuc.procedure__c AS procedure__c',
      'procedure__c.name AS procedureName',
      'cuc.surgical_cases__c',
      'cuc.sfid',
      'cuc.external_id__c',
      'cuc.price_override__c',
      'cuc.procedure__c AS procedureid__c',
      'cuc.used_from__c',
      'cuc.inventory_product_system__c',
      'cuc.aro_ship_to__r__external_id__c',
      'p.inventory_item_id_plain__c AS productOracleId',
      'cuc.usg_total_amount__c',
      'cuc.override_price__c',
      'cuc.contract__c',
      'cuc.csr_contract__c',
      'cuc.csr_usage_price__c',
      'cuc.csr_price_override__c',
      'cuc.serial_number__c AS serialNumber',
      'cuc.expiry_date__c AS expirationDate',
      'cuc.unit_number__c as unitNumber',
      'repAdd.name as replenishAddressName',
      'repAdd.address1__c as replenishAddressAddressField',
      'repAdd.city__c as replenishAddressCityField',
      'repAdd.postalcode__c as replenishAddressZipField',
      'repAdd.state_province__c as replenishAddressStateField',
      'repAdd.external_id__c as replenishAddressExternalIdField',
      'contract.comments__c as contractComments',
      'contract.contract_end_date__c as contractEndDate',
      'contract.contract_start_date__c as contractStartDate',
      'contract.description as contractDescription',
      'contract.name as contractName',
      herokuConnectClient.raw(
        `coalesce(p.description, p2.description) as part_desc`
      ),
    ])
    .from("casesusage__c AS cuc")
    .innerJoin("cases__c", "cases__c.sfid", "cuc.surgical_cases__c")
    .leftJoin("procedure__c", function() {
      this.on("cuc.procedure__c", "=", "procedure__c.sfid");
    })
    .leftJoin("contract", function() {
      this.on("cuc.contract__c", "=", "contract.sfid");
    })
    .leftOuterJoin(
      "invproductcomponent__c AS ic",
      "cuc.invproductcomponent__c",
      "ic.sfid"
    )
    .innerJoin("product2 AS p", "p.sfid", "cuc.product__c")
    .leftJoin(
      "address__c AS repAdd",
      "repAdd.external_id__c",
      "cuc.aro_ship_to__r__external_id__c"
    )
    .leftOuterJoin(
      "productsubsystemcomponents__c as psc",
      "psc.sfid",
      "ic.productsubsyscompid__c"
    )
    .leftOuterJoin("product2 as p2", "p2.sfid", "psc.product__c");

  queryFilterAppender({ query, sfId });

  query.orderBy("cuc.name");

  return query;
}

function findCaseUsagesByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "p.sfid AS product_sfid",
      "ic.sfid AS part_ipc_sfid",
      "p.sfid AS part_id",
      "ic.sfid AS part_psfid",
      "ic.ipsid__c as set_id",
      herokuConnectClient.raw(
        `CONCAT (p.catalog_number__c, ' - ', p.description__c) AS part_name`
      ),
      'p.lot_serial_control_code__c AS lot_serial_control_code__c',
      herokuConnectClient.raw(
        `CASE WHEN (p.lot_serial_control_code__c = '2')
          THEN true
          ELSE false END
         AS is_lot_controlled`
      ),
      'ic.quantity__c AS unit',
      'ic.missing_quantity__c AS missingQty',
      'cuc.name as usageName',
      'cuc.quantity__c AS quantity__c',
      'cuc.lot_number__c AS lot_number__c',
      'cuc.wasteds__c AS wasted',
      'cuc.side__c AS side__c',
      'cuc.usg_price__c AS usg_price__c',
      'cuc.used_from__c AS set_usages_id',
      'cuc.lot_controlled__c AS lot_controlled__c',
      'cuc.ship_to__c AS ship_to__c',
      'cuc.shipto_location__c AS shipto_location__c',
      'cuc.replenish__c AS replenish__c',
      'cuc.procedure__c AS procedure__c',
      'procedure__c.name AS procedureName',
      'cuc.surgical_cases__r__external_id__c',
      'cuc.sfid',
      'cuc.external_id__c',
      'cuc.price_override__c',
      'cuc.procedure__c AS procedureid__c',
      'cuc.used_from__c',
      'cuc.inventory_product_system__c',
      'cuc.aro_ship_to__r__external_id__c',
      'p.inventory_item_id_plain__c AS productOracleId',
      'cuc.usg_total_amount__c',
      'cuc.override_price__c',
      'cuc.contract__c',
      'cuc.csr_contract__c',
      'cuc.csr_usage_price__c',
      'cuc.csr_price_override__c',
      'cuc.serial_number__c AS serialNumber',
      'cuc.expiry_date__c AS expirationDate',
      'cuc.unit_number__c as unitNumber',
      'repAdd.name as replenishAddressName',
      'repAdd.address1__c as replenishAddressAddressField',
      'repAdd.city__c as replenishAddressCityField',
      'repAdd.postalcode__c as replenishAddressZipField',
      'repAdd.state_province__c as replenishAddressStateField',
      'repAdd.external_id__c as replenishAddressExternalIdField',
      'contract.comments__c as contractComments',
      'contract.contract_end_date__c as contractEndDate',
      'contract.contract_start_date__c as contractStartDate',
      'contract.description as contractDescription',
      'contract.name as contractName',
      herokuConnectClient.raw(
        `coalesce(p.description, p2.description) as part_desc`
      ),
    ])
    .from("casesusage__c AS cuc")
    .innerJoin(
      "cases__c",
      "cases__c.external_id__c",
      "cuc.surgical_cases__r__external_id__c"
    )
    .leftJoin("procedure__c", function() {
      this.on("cuc.procedure__c", "=", "procedure__c.sfid");
    })
    .leftJoin("contract", function() {
      this.on("cuc.contract__c", "=", "contract.sfid");
    })
    .leftOuterJoin(
      "invproductcomponent__c AS ic",
      "cuc.invproductcomponent__c",
      "ic.sfid"
    )
    .innerJoin("product2 AS p", "p.sfid", "cuc.product__c")
    .leftJoin(
      "address__c AS repAdd",
      "repAdd.external_id__c",
      "cuc.aro_ship_to__r__external_id__c"
    )
    .leftOuterJoin(
      "productsubsystemcomponents__c as psc",
      "psc.sfid",
      "ic.productsubsyscompid__c"
    )
    .leftOuterJoin("product2 as p2", "p2.sfid", "psc.product__c");
  queryFilterAppender({ query, externalId });

  query.orderBy("cuc.name");

  return query;
}

function findCaseUsagesOtherFee({ sfId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "asf.surgical_case__c AS case_sfid",
      "asf.surgical_case__c",
      "asf.external_id__c",
      "asf.value__c",
      "asf.name",
    ])
    .from("additional_surgery_fee__c AS asf")
    .innerJoin("cases__c", "cases__c.sfid", "asf.surgical_case__c");

  queryFilterAppender({ query, sfId });

  return query;
}

function findCaseUsagesOtherFeeByExternalIds({ externalId }) {
  let query = herokuConnectClient
    .withSchema("salesforce")
    .select()
    .distinct([
      "asf.surgical_case__r__external_id__c",
      "asf.external_id__c",
      "asf.value__c",
      "asf.name",
    ])
    .from("additional_surgery_fee__c AS asf")
    .innerJoin(
      "cases__c",
      "cases__c.external_id__c",
      "asf.surgical_case__r__external_id__c"
    );

  queryFilterAppender({ query, externalId });

  return query;
}
