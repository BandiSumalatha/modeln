const herokuConnectClient = require('../services/knex').herokuConnectClient;
const { CASE_ACTION_CHANGED_BY_SYSTEM } = require('../constants');

module.exports = async (user, action, caseSfid, caseExternalId, tprId) => {
  try {
    //To check whether already a record is there
    const mostRecentRecord = herokuConnectClient('caseaction_tracking__c')      
      .withSchema('salesforce')
      .select('action__c')
      .where(function() {
        this.where({ surgical_case__c: caseSfid });
        this.orWhere({ surgical_case__r__external_id__c: caseExternalId });
      })      
      .orderBy('id','desc')
      .limit(1);

    if (tprId) {
      mostRecentRecord.where({ treatment_plan_request__r__external_id__c: tprId });
    }

    const res = await mostRecentRecord;
    
    //Insert only if there is no record with same values
    if (res.length == 0 || res[0].action__c != action) {
      let actionObj = {
        changed_by__c: `${user.first_name} ${user.last_name}`,
        action__c: action,
        surgical_case__c: caseSfid,
        surgical_case__r__external_id__c: caseExternalId,
        changed_by_system__c: CASE_ACTION_CHANGED_BY_SYSTEM,
        changed_date__c: `NOW()`
      };

      if (tprId) {
        actionObj.treatment_plan_request__r__external_id__c = tprId;
      }

      const query = herokuConnectClient(
        'salesforce.caseaction_tracking__c'
      ).insert(actionObj);
      await query;
    }
  } catch (err) {
    console.log(err);
  }
};
