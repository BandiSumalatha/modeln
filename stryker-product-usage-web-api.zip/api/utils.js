const getUpdatedData = (
  object,
  base,
  matchingKeyApp,
  matchingKeyDb,
  fieldsToMatch
) => {
  return object.filter(obj => {
    const baseObj = base.find(
      obj2 => obj[matchingKeyApp] === obj2[matchingKeyDb]
    );
    if (baseObj) {
      return fieldsToMatch.find(
        filter =>
          `${obj[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
      );
    } else {
      return false;
    }
  });
};

const getInsertedData = (object, base, matchingKeyApp, matchingKeyDb) => {
  return object.filter(
    obj =>
      !base.find(obj2 => `${obj[matchingKeyApp]}` === `${obj2[matchingKeyDb]}`)
  );
};

const getDeleteData = (object, base, matchingKeyApp, matchingKeyDb) => {
  return base.filter(obj => {
    return !object.find(
      obj2 => `${obj[matchingKeyDb]}` === `${obj2[matchingKeyApp]}`
    );
  });
};

const getDeleteDataOnMultipleKey = (object, base, matchingKey) =>
  base.filter(
    obj =>
      !object.some(
        obj2 =>
          matchingKey.filter(
            mkey =>
              `${getUndefinedForBlank(obj[mkey.db])}` ===
              `${getUndefinedForBlank(obj2[mkey.app])}`
          ).length == matchingKey.length
      )
  );
const getInsertDataOnMultipleKey = (object, base, matchingKey = []) =>
  object.filter(
    obj =>
      !base.some(
        obj2 =>
          matchingKey.filter(
            mkey =>
              `${getUndefinedForBlank(obj[mkey.app])}` ===
              `${getUndefinedForBlank(obj2[mkey.db])}`
          ).length == matchingKey.length
      )
  );
const getUpdatedDataOnMultipleKey = (
  object,
  base,
  matchingKey = [],
  fieldsToMatch = []
) => {
  return object.filter(obj => {
    const baseObj = base.find(
      obj2 =>
        matchingKey.filter(
          mkey =>
            `${getUndefinedForBlank(obj[mkey.app])}` ===
            `${getUndefinedForBlank(obj2[mkey.db])}`
        ).length == matchingKey.length
    );
    if (baseObj) {
      return fieldsToMatch.find(
        filter =>
          `${obj[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
      );
    } else {
      return false;
    }
  });
};

const getUndefinedForBlank = value =>
  value == null || value === '' ? null : value;

const getCUFilteredData = (
  object,
  base,
  matchingKeyApp,
  matchingKeyDb,
  fieldsToMatch
) => {
  return object.reduce(
    (acc, item) => {
      let updateItem = null;
      const baseObj = base.find(
        obj2 => item[matchingKeyApp] === obj2[matchingKeyDb]
      );
      if (baseObj) {
        updateItem = fieldsToMatch.find(
          filter =>
            `${item[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
        );
      }
      if (updateItem) {
        item.external_id__c = baseObj.external_id__c;
        item.sfid = baseObj.sfid;
        acc.updateElements.push(item);
      } else if (!baseObj) {
        acc.insertElements.push(item);
      }
      return acc;
    },
    { updateElements: [], insertElements: [] }
  );
};

const getCUFilteredDataOnMultipleKey = (
  object,
  base,
  matchingKey = [],
  fieldsToMatch = []
) => {
  return object.reduce(
    (acc, item) => {
      let updateItem = null;
      const baseObj = base.find(
        obj2 =>
          matchingKey.filter(
            mkey =>
              `${getUndefinedForBlank(item[mkey.app])}` ===
              `${getUndefinedForBlank(obj2[mkey.db])}`
          ).length == matchingKey.length
      );
      if (baseObj) {
        updateItem = fieldsToMatch.find(
          filter =>
            `${item[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
        );
      }
      if (updateItem) {
        acc.updateElements.push(item);
      } else if (!baseObj) {
        acc.insertElements.push(item);
      }
      return acc;
    },
    { updateElements: [], insertElements: [] }
  );
};

const getCUFilteredDataOnConditions = (
  object,
  base,
  matchingKey = { or: [], and: [] },
  fieldsToMatch = []
) => {
  return object.reduce(
    (acc, item) => {
      let updateItem = null;
      const baseObj = base.find(
        obj2 =>
          matchingKey.or.filter(
            mkey =>
              `${getUndefinedForBlank(item[mkey.app])}` ===
              `${getUndefinedForBlank(obj2[mkey.db])}`
          ).length > 0 &&
          matchingKey.and.filter(
            mkey =>
              `${getUndefinedForBlank(item[mkey.app])}` ===
              `${getUndefinedForBlank(obj2[mkey.db])}`
          ).length == matchingKey.and.length
      );
      if (baseObj) {
        updateItem = fieldsToMatch.find(
          filter =>
            `${item[filter.matchingApp]}` !== `${baseObj[filter.matchingDb]}`
        );
      }
      if (updateItem) {
        updateItem.external_id__c = baseObj.external_id__c;
        updateItem.sfid = baseObj.sfid;
        acc.updateElements.push(item);
      } else if (!baseObj) {
        const { external_id__c, ...rest } = item;
        acc.insertElements.push(rest);
      }
      return acc;
    },
    { updateElements: [], insertElements: [] }
  );
};

const getCUDeleteDataOnConditions = (
  object,
  base,
  matchingKey = { or: [], and: [] }
) =>
  base.filter(
    obj =>
      !object.some(
        obj2 =>
          matchingKey.or.filter(
            mkey =>
              `${getUndefinedForBlank(obj[mkey.db])}` ===
              `${getUndefinedForBlank(obj2[mkey.app])}`
          ).length == matchingKey.or.length &&
          matchingKey.and.filter(
            mkey =>
              `${getUndefinedForBlank(obj[mkey.app])}` ===
              `${getUndefinedForBlank(obj2[mkey.db])}`
          ).length == matchingKey.and.length
      )
  );

module.exports = {
  getUpdatedData,
  getInsertedData,
  getDeleteData,
  getInsertDataOnMultipleKey,
  getUpdatedDataOnMultipleKey,
  getDeleteDataOnMultipleKey,
  getUndefinedForBlank,
  getCUFilteredData,
  getCUFilteredDataOnMultipleKey,
  getCUFilteredDataOnConditions,
  getCUDeleteDataOnConditions
};
