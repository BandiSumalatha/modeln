const passport = require('passport');
const OAuth2Provider = require('./oauth2');

module.exports = connectToPassport;

function connectToPassport(app) {
  passport.use('oauth2', OAuth2Provider(app));
  app.use(passport.initialize());
  app.get("/token", (req, res, next) => {
    const accessToken = req.query && req.query.access_token ? req.query.access_token : 'N/A';
    const refreshToken = req.query && req.query.refresh_token ? req.query.refresh_token : 'N/A';

    res.render('token', {accessToken, refreshToken});
  });
  return app;
}

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});
