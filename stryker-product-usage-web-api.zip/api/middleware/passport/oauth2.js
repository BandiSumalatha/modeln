const OAuth2Strategy = require("passport-azure-oauth2");
const passport = require("passport");
const jwt = require("jsonwebtoken");
const { ENVIRONMENT, OAUTH } = require("../../config");
const qs = require("qs");
const { findUser } = require("../../services/salesforce");
const { getRHSToken, RHS_SCOPES } = require("../../services/rhsAuthentication");

module.exports = OAuth2Provider;

function OAuth2Provider(app) {
  const authorizationURL = OAUTH.AUTHORIZATION_URL;
  const tokenURL = OAUTH.TOKEN_URL;
  const clientID = OAUTH.CLIENT_ID;
  const clientSecret = OAUTH.CLIENT_SECRET;
  const callbackURL = OAUTH.CALLBACK_URL;
  const codeScope = OAUTH.CODE_SCOPE;
  const tokenScope = OAUTH.TOKEN_SCOPE;

  app.get("/__/auth/oauth2", (req, res, next) => {
    const popup = req.query && req.query.popup && req.query.popup == "true";
    const popped = req.query && req.query.popped && req.query.popped == "true";
    if (popup) {
      res.removeHeader("X-Frame-Options");
      res.render("oauth-popup");
    } else {
      passport.authenticate(
        "oauth2",
        {
          state: !!popped + "|" + (req.query.redirect_uri || ""),
          prompt: !!popped ? undefined : "login",
          login_hint: !!req.query.username ? req.query.username : undefined,
        },
        async (err, user, info) => {
          if (err || !user) return res.redirect("/__/auth/oauth/error");
          return res.json(user);
        }
      )(req, res, next);
    }
  });

  app.get(
    "/__/auth/oauth2/callback",
    passport.authenticate("oauth2", {
      failureRedirect: "/__/auth/oauth2/error",
      session: false,
      scope: tokenScope
    }),
    async (req, res, next) => {
      try {
        if (req.user) {
          let decodedToken = req.user.accessToken
            ? jwt.decode(req.user.accessToken)
            : null;
          let expires = decodedToken ? decodedToken.exp : null;
          let tokenPayload = {
            access_token: req.user.accessToken,
            refresh_token: req.user.refreshToken,
            expires
          };
          let redirectUrl = ENVIRONMENT.IS_LOCAL_DEVELOPMENT
            ? `${ENVIRONMENT.LOCAL_WEBCLIENT_ROOT}/token`
            : "/token";
          tokenPayload.pathname = "/";

          const popped = req.user.redirectUri
            ? req.user.redirectUri.startsWith("true")
            : false;
          const providedUrl =
            req.user.redirectUri && req.user.redirectUri.indexOf("|") >= 0
              ? req.user.redirectUri.split("|", 2)[1]
              : "";
          redirectUrl =
            providedUrl && providedUrl !== "" ? providedUrl : redirectUrl;
          let querySeparator = redirectUrl.indexOf('?') > -1 ? '&' : '?';
          if (popped) {
            return res.render("oauth-closed", {
              url: `${redirectUrl}${querySeparator}${qs.stringify(tokenPayload)}`,
            });
          } else {
            return res.redirect(`${redirectUrl}${querySeparator}${qs.stringify(tokenPayload)}`);
          }
        } else {
          return res.error(`Unrecognized user`);
        }
      } catch (error) {
        console.log(`Problem authenticating user; ${error}.`);
        return res.error(`Unrecognized user`);
      }
    }
  );

  app.get("/__/auth/oauth2/error", (req, res) => {
    let errorMessage =
      req.error || `You entered invalid credentials, please try again.`;
    res.render("login-error", {
      errorMessage: errorMessage
    });
  });

  var oauth2 = new OAuth2Strategy(
    {
      authorizationURL,
      tokenURL,
      clientID,
      clientSecret,
      callbackURL,
      scope: codeScope,
      passReqToCallback: true,
    },
    function(req, accessToken, refreshToken, params, profile, next) {
      let redirectUri =
        req && req.query && req.query.state ? req.query.state : undefined;
      if (profile && accessToken) {
        profile["redirectUri"] = redirectUri;
        profile["accessToken"] = accessToken;
        profile["refreshToken"] = refreshToken;
        const decodedToken = jwt.decode(accessToken);
        profile["email"] = decodedToken["upn"];

        (async () => {
          let email = profile["email"];

          // TODO: Lock down roles using environment variables once we have the full hierarchy list from SFDC
          let user = await findUser(email);

          // TODO: Persist a list of these based on the finalized permissions from SFDC
          if (user) {
            user.accessToken = profile.accessToken;
            user.refreshToken = profile.refreshToken;
            user.redirectUri = profile.redirectUri;

            user.user_permissions = [
              {
                code: "ORTHO_USER",
                metadata: {
                  routes: [
                    { path: "/", name: "ortho:dashboard:home" },
                    { path: "/ortho", name: "ortho:dashboard:ortho" },
                    { path: "/ortho/metrics", name: "ortho:dashboard:metrics" },
                    { path: "/ortho/survey", name: "ortho:dashboard:survey" },
                    { path: "/survey", name: "ortho:dashboard:survey" },
                    {
                      path: "/survey_editor",
                      name: "ortho:dashboard:surveyEditor",
                    },
                    {
                      path: "/user/language_settings",
                      name: "ortho:dashboard:languageSettings",
                    },
                  ],
                  screens: ["Cases", "Calendar", "Orders", "SetLibrary"],
                },
                label: "A Stryker Ortho User",
              },
            ];
          }

          return next(null, user);
        })();
      } else {
        return next(null, null);
      }
    }
  );

  oauth2.tokenParams = function(options) {
    const { scope } = options;
    return { scope };
  }

  return oauth2;
}
