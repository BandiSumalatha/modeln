const crypto = require("crypto");
const { CANVAS } = require("../../config");

module.exports = connectToCanvas;

function connectToCanvas(app) {
  app.get("/__/canvas", (req, res, next) => {
    res.removeHeader("X-Frame-Options");
    res.render("canvas-auth", {
      salesforceUrl: CANVAS.SALESFORCE_URL,
      clientId: CANVAS.CLIENT_ID,
      canvasCallback: CANVAS.CALLBACK,
    });
  });

  app.post("/__/canvas", (req, res, next) => {
    res.removeHeader("X-Frame-Options");
    let consumerSecretApp = CANVAS.CLIENT_SECRET;
    let bodyRequest = req.body.signed_request.split(".");
    let consumerSecret = bodyRequest[0];
    let encodedEnvelope = bodyRequest[1];
    let check = crypto
      .createHmac("sha256", consumerSecretApp)
      .update(encodedEnvelope)
      .digest("base64");
    if (check === consumerSecret) {
      let envelope = JSON.parse(
        new Buffer.from(encodedEnvelope, "base64").toString("ascii")
      );
      let caseId = envelope.context.environment.parameters.ExternalId;
      let username = envelope.context.user.email;
      if (caseId) {
        res.redirect(
          `${
            CANVAS.REDIRECT_URL
          }?ExternalId=${caseId}&canvas=true&username=${encodeURIComponent(
            username
          )}`
        );
      } else {
        res.redirect(
          `${CANVAS.REDIRECT_URL}?canvas=true&username=${encodeURIComponent(
            username
          )}`
        );
      }
    }
  });

  app.get("/__/canvas/oauthCallback", (req, res, next) => {
    res.removeHeader("X-Frame-Options");
    res.render("canvas-callback", {
      salesforceUrl: CANVAS.SALESFORCE_URL,
    });
  });

  return app;
}
