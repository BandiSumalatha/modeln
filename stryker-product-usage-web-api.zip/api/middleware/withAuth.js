const winston = require('winston');
const jwtService = require('../services/jwt');
const { ENVIRONMENT } = require('../config');

module.exports = function withAuth(routeHandler) {
  return async (req, res) => {
    try {
      // Bypass auth locally for easier debugging of GQL or let refreshJwt through
      if (
        ENVIRONMENT.DISABLE_AUTH ||
        req.body.query.indexOf('refreshJwt') > -1
      ) {
        return routeHandler(req, res);
      }
      let authorization = req.headers['authorization'] || '';
      let token = authorization.replace('Bearer ', '');
      let decoded = await jwtService.verifyToken(token);
      let { upn } = decoded;
      if (!upn) {
        throw new Error(`Invalid token detected`);
      }
      return routeHandler(req, res);
    } catch (error) {
      winston.error(`Authentication failure: ${JSON.stringify(error)}`);
      return res.status(401).json({ message: `Unauthorized access detected` });
    }
  };
};
