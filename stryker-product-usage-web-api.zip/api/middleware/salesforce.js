const { SALESFORCE, REDIS } = require('../config');
const jsforce = require('jsforce');
const { redisClient, set } = require('../services/redis');

let oauth2 = new jsforce.OAuth2({
  clientId: SALESFORCE.CONSUMER_KEY,
  clientSecret: SALESFORCE.CONSUMER_SECRET,
  redirectUri: SALESFORCE.REDIRECT_URI,
  loginUrl: SALESFORCE.LOGIN_URL
});

module.exports = {
  SalesforceServerAuth,
  SalesforceOAuth2: oauth2
};

function SalesforceServerAuth(app) {
  app.get('/__/auth/salesforce', (req, res) => {
    res.redirect(oauth2.getAuthorizationUrl({ scope: 'full refresh_token' }));
  });

  app.get('/__/auth/salesforce/callback', async (req, res) => {
    let connection = new jsforce.Connection({ oauth2 });
    const code = req.param('code');
    let credentials = await authorizeWithCode(connection, code);
    await set(
      REDIS.SALESFORCE_API_CACHE,
      REDIS.SALESFORCE_OAUTH_CREDENTIALS,
      JSON.stringify(credentials)
    );
    return res.json({
      message:
        'Successfully authenticated server to Salesforce and cached credentials',
      payload: { ...credentials }
    });
  });

  return app;
}

function authorizeWithCode(connection, code) {
  return new Promise((resolve, reject) => {
    connection.authorize(code, (err, userInfo) => {
      if (err) {
        return reject(err);
      }

      let { accessToken, refreshToken, instanceUrl } = connection;
      return resolve({
        userInfo,
        accessToken,
        refreshToken,
        instanceUrl
      });
    });
  });
}
