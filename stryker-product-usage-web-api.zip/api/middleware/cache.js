const amqp = require('amqplib');
const { AMQP } = require('./../config');
const { shortTermCache, procedureCache } = require('./../services/CacheService');
const { enqueueBuildCache } = require('./../services/cloudAMQP');

const CACHECONTROL_QUEUE_NAME = 'cachecontrol';

function addCacheFlush(app) {
    app.get('/__/flush', async (req, res) => {
        res.status(200).send('Cache is being flushed.  This may take up to ten minutes.');
        await enqueueBuildCache();
    });
}

async function listenForFlushRequest() {
    const conn = await amqp.connect(AMQP.CLOUDAMQP_URL);
    const channel = await conn.createChannel();
    await channel.assertExchange(CACHECONTROL_QUEUE_NAME, 'fanout');
    const { queue } = await channel.assertQueue('', { exclusive: true });
    console.log(`Established queue: ${queue}`);
    await channel.bindQueue(queue, CACHECONTROL_QUEUE_NAME, '');
    console.log(`Bound queue ${queue} to ${CACHECONTROL_QUEUE_NAME}`);
    await channel.consume(queue, async (msg) => {
        channel.ack(msg);
        try {
            await procedureCache.flush();
            await shortTermCache.flush();
            console.log("Cache flushed.");
        } catch (e) {
            console.log('Cache already flushed by another node.');
        }
        console.log("Repopulated cache.");
    });
}

module.exports = {
    addCacheFlush,
    listenForFlushRequest
}