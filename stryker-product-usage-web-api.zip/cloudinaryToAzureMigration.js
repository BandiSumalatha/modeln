const cloudinary = require('cloudinary').v2;
const { azureStorageClient } = require('./api/services/AzureStorageClient');
const { herokuConnectClient } = require('./api/services/knex');

// creating azure connection
const createAzureConnection = async () => {
  await azureStorageClient.connect();
  azureStorageClient.on('error', err => {
    console.log(err);
    process.exit(1);
  });
  return;
};

// getting records from db to be migrated
const getCloudinaryPublicIdsFromDb = async () => {
  const data = await herokuConnectClient
    .withSchema('salesforce')
    .select('cloudinary_image_url', 'signature_by')
    .from('case_images')
    .whereNot('cloudinary_image_id', null);
  return data.map(item => {
    // splitting cloudinary_image_url to get public_id
    const data = item.cloudinary_image_url;
    return {
      url: data.substring(data.lastIndexOf('/') + 1),
      isSignature: item.signature_by
    };
  });
};

// updating DB
const updateCaseImagePathFromDb = async (
  azureFileUrl,
  azureThumbnailUrl,
  cloudinaryPublicId
) => {
  return await herokuConnectClient('case_images')
    .withSchema('salesforce')
    .update({
      azure_image_url: azureFileUrl,
      thumbnail_url: azureThumbnailUrl
    })
    .where('cloudinary_image_url', 'like', `%${cloudinaryPublicId}%`);
};

// uploading file to azure blob
const uploadFileToAzure = async cloudinaryPublicId => {
  const cloudinarySecureUrl = `https://res.cloudinary.com/${
    process.env.CLOUDINARY_CLOUD_NAME
  }/image/upload/${cloudinaryPublicId.url}`;
  const cloudinarySecureThumbnailUrl = `https://res.cloudinary.com/${
    process.env.CLOUDINARY_CLOUD_NAME
  }/image/upload/w_320/${cloudinaryPublicId.url}`;
  const {
    fileStatus: azureFileStatus,
    fileUrl: azureFileUrl,
    thumbnailStatus: azureThumbnailStatus,
    thumbnailFileUrl: azureThumbnailUrl
  } = await azureStorageClient.migrateToAzure(
    cloudinarySecureUrl,
    cloudinarySecureThumbnailUrl,
    cloudinaryPublicId.url,
    cloudinaryPublicId.isSignature
  );
  return {
    cloudinaryPublicId: cloudinaryPublicId.url,
    azureFileUrl,
    azureFileStatus,
    azureThumbnailStatus,
    azureThumbnailUrl
  };
};

// getting data from cloudinary
const getDataFromCloudinary = async batch => {
  const { resources } = await cloudinary.api.resources_by_ids(batch);
  return resources;
};

// starting migration process from Cloudinary to Azure Blob Storage
const startMigration = async () => {
  await createAzureConnection();
  // getting data to be migrated from DB
  const cloudinaryData = await getCloudinaryPublicIdsFromDb();
  console.log('Total items to be migrated: ', cloudinaryData.length);

  // uploading one by one each file to Azure and if uploading is successfull, updating data in DB at azure_image_url
  for (const cloudinaryPublicIdData of cloudinaryData) {
    if (cloudinaryPublicIdData && cloudinaryPublicIdData.url !== 'undefined') {
      const {
        cloudinaryPublicId,
        azureFileUrl,
        azureFileStatus,
        azureThumbnailStatus,
        azureThumbnailUrl
      } = await uploadFileToAzure(cloudinaryPublicIdData);
      if (azureFileStatus === 'success' && azureThumbnailStatus === 'success') {
        // updating data in DB at azure_image_url
        await updateCaseImagePathFromDb(
          azureFileUrl,
          azureThumbnailUrl,
          cloudinaryPublicId
        );
      }
    }
  }
  console.log('Completed');
  process.exit();
};

startMigration();
