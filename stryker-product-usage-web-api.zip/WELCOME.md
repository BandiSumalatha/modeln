# Stryker Product Usage Web

## Onboarding Videos

1. [Local Developer Setup and Onboarding](https://www.useloom.com/share/74e85ccbca194fbe9eb715bb7e8e0bff)
1. [Heroku and Salesforce Onboarding](https://www.useloom.com/share/970043da03d8495090951f3f9eab9470)
1. [Pull Requests](https://www.useloom.com/share/89060d3955e5473092a68592006e0fe9)

## Welcome

If you are reading this, you have been selected as a developer for the Stryker Product Usage web application, welcome to the team! This document outlines this project's purpose and rules for the development team.

## Purpose

The Stryker Product Usage Web application's primary goal is to be a centralized survey collection application for Stryker's salespeople and clients. The surveys conducted primarily revolve around what Stryker (or non-Stryker) products are being used for specific medical procedures. This helps to better inform Stryker of potential sales opportunities or feedback on their products.

## Architecture

The Stryker Product Usage Web application will be a Universal JavaScript application utilizing React.js SPA on the front-end and Node.js on the backend. GraphQL will be the primary form of data communication from client and server. The exception is a few one-off REST routes to support SurveyJS, the survey engine chosen for this project.

## Development Team Rules

1. Any feature(s) introduced will be created as a Pull Request, and the PR template **must be completed in its entirety**.
2. Any feature that doesn't introduce external dependencies with side effects must have 100% test coverage. If a feature does introduce external dependencies with side effects, user-created code must be 100% covered (e.g. don't kill yourself mocking things like GQL or React Router)
3. The _overall_ project test coverage must be over 70% at all times
3. Code Reviewers will be Rick Arnett, Eric Nograles, Sandeep Kumar, or Edison Jimenez
4. All Code Review items identified by the reviewer must be addressed before a PR is accepted

## Setup Your Development Environment

1. [Visual Studio Code](https://code.visualstudio.com/)
1. [Docker](https://www.docker.com/)
1. [Node Version Manager](https://github.com/creationix/nvm#installation)
1. `nvm install 8.11.1`
1. `nvm alias default 8.11.1`
1. `npm i -g yarn`
