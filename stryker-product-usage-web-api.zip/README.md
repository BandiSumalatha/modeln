# Stryker Product Usage Web
## Overview

The SPA and Web API project for the Product Usage application. If you are just starting on this project, please read [the welcome guide](WELCOME.md) first.

## Prerequisites

1. [Visual Studio Code](https://code.visualstudio.com/)
1. [Docker](https://www.docker.com/)
1. [Node Version Manager](https://github.com/creationix/nvm#installation)
1. `nvm install 8.11.1`
1. `nvm alias default 8.11.1`
1. `npm i -g yarn`

## Setup

We have a convenience function to get the entire stack built for you with all source code and test runners in Docker. Follow the steps below for this.

### Start the Docker Container

1. Download [this .pem file](https://drive.google.com/open?id=1yVRmO9eQJoLb1GjrumUzoSEPewi1-vSP) and save to the root of the repo -- this is a signing cert for the development Auth0 SAML IdP
1. Also download [this .pem file](https://drive.google.com/open?id=1Tw-DtoGHfIIfJOqhswfxMk8k_oOpTkka) and save to the root of the repo -- this is a signing cert for Stryker's ADFS instance
1. At the root of this repo, execute `docker-compose build --no-cache`
1. At the root of this repo, execute `docker-compose up` (optionally, `docker-compose -d` if you want to run as daemons in the background)
1. To stop all the code and infrastructure, press Ctrl + C from this terminal
1. To delete all of the infrastructure and start from scratch, at the root of this repo, execute `docker-compose down && ./docker_clean.sh && docker-compose up`

### Full Stack Startup

1. At the root of this repo, execute `docker-compose up` (optionally, `docker-compose -d` if you want to run as daemons in the background)
1. Start developing locally on VSCode

| Type  | Address |
| ------------- | ------------- |
| GraphQL Web API  | http://localhost:63002  |
| React SPA Dev Server  | http://localhost:63004  |


### GraphQL Web API

1. Open `http://localhost:63002/explorer` in a browser for the GraphiQL Explorer
   * **Note**: Any changes in `api` will reflect in your Docker container automatically thanks to Nodemon

### Swagger

`docker exec -i -t stryker_product_usage_web_api yarn swagger:edit`

## Features

This scaffold is completely containerized in Docker, meaning you do not have to worry about any local dependencies apart from Docker and VS Code.

We expose ports on the container to allow the best of both worlds: isolated and consistent container development with the convenience of local development.

### Adding New Dependencies

Example below of adding `lodash`:

`docker exec -i -t stryker_product_usage_web_api yarn add lodash`

### Prettier

This scaffold comes with a `prettier` precommit Git hook.  In other words, your JS can be in whatever style you want as you develop.  When you stage your commits to git, `prettier` will automatically format your code to an opinionated standard.

## Troubleshooting

### ENOSPC Issues With Docker

If you are doing heavy development in Docker and aren't actively removing volumes, you might run into an ENOSPC problem when you execute `docker-compose build --no-cache` or `docker-compose up`.  

To alleviate this, execute `./utils/docker_clean.sh` in a Terminal then attempt to do another `docker-compose build --no-cache` or `docker-compose up`.

This command deletes and "dangling" volumes and images -- that is, any volumes or images that are orphaned because of prior `docker-compose build` or container removals.

## Architecture

### Back-end (/src/api)

* [Express](https://www.npmjs.org/express): Web framework
* [Bluebird](https://www.npmjs.org/bluebird): Promise library
* [body-parser](https://www.npmjs.org/body-parser): Express plugin for parsing different types of content
* [cors](https://www.npmjs.org/cors): Express plugin for handling CORS requests
* [bcrypt](https://www.npmjs.org/bcrypt): Practical encryption for data at rest
* [jsonwebtoken](https://www.npmjs.org/jsonwebtoken): Creation and management of JWT's
* [passport](https://www.npmjs.org/passport): Authentication middleware for Express
* [passport-saml](https://www.npmjs.org/passport-saml): SAML plugin for Passport
* [passport-oauth](https://www.npmjs.org/passport-oauth): OAuth plugin for Passport
* [sequelize](https://www.npmjs.org/sequelize): Code-first ORM
* [knex](https://www.npmjs.org/knex): Query builder for databases
* [winston](https://www.npmjs.org/winston): Application logging
* [redis](https://www.npmjs.org/redis): Redis client
* [pg](https://www.npmjs.org/pg): Postgres client
* [mongoose](https://www.npmjs.org/mongoose): MongoDB client

### Common

* [moment](https://www.npmjs.org/moment): Date parsing and formatting library
* [dotenv](https://www.npmjs.org/dotenv): .env file support

### Unit Testing, Code Quality, and DevOps

* [prettier](https://www.npmjs.org/prettier): Opinionated JavaScript code styling
* [husky](https://www.npmjs.org/husky): Pre-commit Git Hooks
* [lint-staged](https://www.npmjs.org/lint-staged): Runs prettier on every staged commit
* [jest](https://www.npmjs.org/jest): Unit testing framework
* [enzyme](https://www.npmjs.org/enzyme): React.js testing utilities
* [react-test-renderer](https://www.npmjs.org/react-test-renderer): React.js testing helpers


