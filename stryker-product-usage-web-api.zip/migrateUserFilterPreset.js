const mongoose = require('./api/services/mongoose');
const { herokuConnectClient } = require('./api/services/knex');

var Schema = mongoose.Schema;

const roleValues = {
  'My Cases': 1,
  'Covering Cases': 2,
  'Team Cases': 3,
  'Branch Cases': 4
};

const UserFilter = mongoose.model(
  'UserFilterBackup',
  Schema({
    user_sfid: { type: String },
    name: { type: String },
    definition: { type: mongoose.Schema.Types.Mixed }
  })
);

// get sfid for the specific value from db
const getSfidFromDb = async (
  column,
  table,
  conditionColumn,
  value,
  conditionColumn2,
  value2
) => {
  const query = herokuConnectClient
    .withSchema('salesforce')
    .select(column)
    .from(table)
    .where(conditionColumn, value);
  if (conditionColumn2 && value2) {
    query.where(conditionColumn2, value2);
  }
  const data = await query;
  if (data.length === 1) {
    return data[0].sfid;
  } else {
    return '-1';
  }
};

// get preset data and update mongo collection
const getData = async () => {
  const userFilterData = await UserFilter.find();
  for (let data in userFilterData) {
    const { definition, _id, user_sfid } = userFilterData[data];
    const toBeTransformed = Object.values(definition).some(
      item => item === null
    );
    let updatedData = Object.assign(definition);
    if (toBeTransformed) {
      for (let key in updatedData) {
        if (!updatedData[key]) {
          delete updatedData[key];
        } else if (key === 'startDate' || key === 'endDate') {
          updatedData[key] = JSON.stringify(updatedData[key]);
        } else if (key === 'filterSalesTeam') {
          const [keyData, valueData] = updatedData[key].split('-');
          updatedData[key] = JSON.stringify({
            value: valueData,
            label: keyData
          });
        } else if (key === 'role') {
          updatedData[key] = JSON.stringify({
            value: roleValues[updatedData[key]],
            label: updatedData[key]
          });
        } else {
          let data = updatedData[key];
          if (key === 'filterBranch') {
            data = await getSfidFromDb(
              'sfid',
              'branch__c',
              'name',
              updatedData[key]
            );
          } else if (key === 'filterSalesRep') {
            data = await getSfidFromDb(
              'sfid',
              'user',
              'name',
              updatedData[key]
            );
          } else if (key === 'filterHospital') {
            const [keyData, valueData] = updatedData[key].split('-');
            data = await getSfidFromDb(
              'sfid',
              'account',
              'name',
              valueData.trim(),
              'accountnumber',
              keyData.trim()
            );
          } else if (key === 'filterSurgeon') {
            const [keyData, valueData] = updatedData[key].split('-');
            data = await getSfidFromDb(
              'sfid',
              'contact',
              'name',
              valueData.trim(),
              'surgeon_erp_code__c',
              keyData.trim()
            );
          } else if (key === 'procedure') {
            data = await getSfidFromDb(
              'sfid',
              'procedure__c',
              'name',
              updatedData[key]
            );
          }
          updatedData[key] = JSON.stringify({
            value: data,
            label: updatedData[key]
          });
        }
      }
    }
    await UserFilter.update(
      {
        _id: _id
      },
      {
        $set: {
          definition: updatedData
        }
      },
      {
        multi: false, // update only one document
        upsert: false // insert a new document, if no existing document match the query
      }
    );
  }
  console.log('User filterPreset data updated');
};

getData();
