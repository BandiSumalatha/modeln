echo "Starting container rebuild"

# Remove node_modules first, they get a little wonky when you rebuild the container
# and will force a yarn install on first run of client or server
docker exec -d stryker_product_usage_web_api rm -rf /app/node_modules

# Take down the container
docker-compose down

# Rebuild the image
docker-compose build

echo "Container successfully rebuilt, starting back up"

# Start back up
docker-compose up


