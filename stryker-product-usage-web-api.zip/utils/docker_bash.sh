docker exec -i -t stryker_product_usage_web_api /bin/bash
