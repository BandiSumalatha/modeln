require('dotenv/config');
const { herokuConnectClient } = require('../api/services/knex');

async function fixErrors() {
    try {
        const waitingSets = await herokuConnectClient.raw(`
            with cases as (
                select 
                    sfid 
                from salesforce.cases__c 
                where 
                    status__c = 'Requested' 
                    and not erp_order_type__c='Info Only' 
                    and webops_case_status__c='Reconciled'
                    and not lower(webops_requested_status__c) like 'failed%'
                    and not lower(webops_create_status__c) like 'failed%'
                    and sfid is not null
                    and systemmodstamp < CURRENT_TIMESTAMP - INTERVAL '10 minutes'
            ),
            webopsCreate as (
                select 
                    parentid, 
                    min(createddate) as webops_create_date
                from 
                    salesforce.cases__history
                where 
                    lower(field)='webops_id__c' 
                    and parentid in (select sfid from cases)                    
                group by parentid
            ),
            webopsRequest as (
                select 
                    parentid, 
                    min(createddate) as webops_request_date
                from 
                    salesforce.cases__history
                where 
                    lower(field)='status__c' 
                    and newvalue='Requested' 
                    and parentid in (select sfid from cases)                    
                group by parentid
            ),
            webopsRequeued as (
                select 
                    parentid, 
                    max(createddate) as webops_requeued_date
                from 
                    salesforce.cases__history
                where 
                    lower(field)='webops_requested_status__c' 
                    and newvalue like 'Queued%' 
                    and parentid in (select sfid from cases)                    
                group by parentid
            ),
            timeComparison as (
                select * from cases
                left join webopsCreate on webopsCreate.parentid = sfid
                left join webopsRequest on webopsRequest.parentid = sfid
                left join webopsRequeued on webopsRequeued.parentid = sfid
            )
            select 
                sfid
            from timeComparison 
            where 
                webops_request_date <= webops_create_date 
                and webops_request_date > '2021-03-01 02:00:00'
                and (webops_requeued_date is null or webops_requeued_date <= webops_create_date)
                and webops_create_date is not null
                and webops_request_date is not null
        `);
        for(const waitingSet of waitingSets.rows) {
            if (!waitingSet || !waitingSet.sfid) continue;            
            const updateObj = {
                webops_requested_status__c: null
            }
            try {
                await herokuConnectClient('cases__c')
                    .withSchema('salesforce')
                    .where('sfid', waitingSet.sfid)
                    .update(updateObj);
                
                console.log(`Cleared request status for ${waitingSet.sfid}`);
            }
            catch (e) {
                console.log(`Failed to clear request status for ${waitingSet.sfid}.`, e);                
            }
        }

        for(const waitingSet of waitingSets.rows) {
            if (!waitingSet || !waitingSet.sfid) continue;            
            const updateObj = {
                webops_requested_status__c: `Requeued : ${(new Date()).toISOString()}`
            }
            try {
                await herokuConnectClient('cases__c')
                    .withSchema('salesforce')
                    .where('sfid', waitingSet.sfid)
                    .update(updateObj);
                
                console.log(`Requeued sets for ${waitingSet.sfid}`);
            }
            catch (e) {
                console.log(`Failed to requeue sets for ${waitingSet.sfid}.`, e);                
            }
        }
    } catch (e) {
        console.log(`Failed to requeue sets.`, e);
    }
}

fixErrors();