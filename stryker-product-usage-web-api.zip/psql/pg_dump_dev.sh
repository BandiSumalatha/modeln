#!/usr/bin/env bash

## NOTE: To avoid having to key in the password everytime, create a .pgpass file in your home directory
## touch ~/.pgpass
## chmod 0600 ~/.pgpass
## nano ~/.pgpass

## Each line of the file should follow this format:
## host:port:database:username:password

## [HEROKU CONNECT] Dump schema and data
pg_dump --no-owner -C -c -v -h ec2-35-153-29-97.compute-1.amazonaws.com -p 5432 -U uf098akffkb7s8 -d de96735rj0t3st --exclude-table-data=salesforce._trigger_* -f syk_dev_hc.sql

## Restore the database
psql -h localhost -U postgres -p 63000 -f syk_dev_hc.sql

## Cleanup
rm syk_*.sql

